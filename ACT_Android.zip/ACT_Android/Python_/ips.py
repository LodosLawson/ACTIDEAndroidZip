import socket

def get_local_ips():
    """Local ağdaki tüm IP adreslerini getirir"""
    ips = []
    hostname = socket.gethostname()
    for address in socket.getaddrinfo(hostname, None):
        ips.append(address[-1][0])
    return ips

print(get_local_ips())
