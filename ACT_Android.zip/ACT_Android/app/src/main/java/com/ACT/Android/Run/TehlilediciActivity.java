package com.ACT.Android.Run;
import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import com.ACT.Android.*;
import com.ACT.Android.Tool.*;

public class TehlilediciActivity extends Activity
{
	//public static TextView OutPutData;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tehliledicistructur);
		
		
		//xconcolactivity.XConsolOutPutDispleyObject = findViewById(R.id.XConsolDispley);
		//Intent intents1 = new Intent(TehlilediciActivity.this, xconcolactivity.class);
		//startActivity(intents1);
		
		//MainActivity.actehliledici.RunTehliledici(SecondActivity.SelectFile,SecondActivity.SelwctFilePath);
		/*try
		{
			//Tehliledici.Tool.ChatGPTConnect.ChatGPT.CGPT();
		}
		catch (IOException e)
		{}*/
	}
}
