package Tehliledici.Tool;

import Tehliledici.ACTehliledici;
import Tehliledici.Elaveler;

public class ArithmeticLogic {
    
    public int ALU(String Value){
        
        if(Value.length() >= 1){
            
            if(Value.length() <= 1){
                //System.out.println(Value);
                return Integer.parseInt(Value);
            }
            if(!Elaveler.isStringInt(String.valueOf(Value.charAt(1)))){
                int[] Ic_Indexac = ACTehliledici.MultiAxtarici(Value, "(","USTGLOBALOZEL");
                int[] Ic_Indexbag = ACTehliledici.MultiAxtarici(Value, ")","USTGLOBALOZEL");

                int Ic_Ilk = Ic_Indexac[0];	
                int Ic_Son = Ic_Indexbag[1];	

                int MathPositionStart = ACTehliledici.MetinAxtarici(Value, "(");
                int MathPositionEnd = ACTehliledici.MetinAxtarici(Value, ")");

                if(MathPositionStart != -1 && MathPositionEnd != -1){
                    if(Ic_Ilk != -1 && Ic_Son != -1){

                        if(Ic_Ilk < Ic_Son){
							
                            /*System.out.println*/Elaveler.YazdirSpesial("<>>"+Value.substring(1+Ic_Ilk, --Ic_Son));
                            ALU(Value.substring(1+Ic_Ilk, --Ic_Son));
                        }
                    }
                }
            }else{
                int[] Ic_Indexac = ACTehliledici.MultiAxtarici(Value, "(","USTGLOBALOZEL");
                int[] Ic_Indexbag = ACTehliledici.MultiAxtarici(Value, ")","USTGLOBALOZEL");
                
                if(Ic_Indexac[0] < Ic_Indexbag[0]){
                    if(Ic_Indexac[0] != -1 && Ic_Indexbag[0] != -1){
                        
                        //String ValueOld = ""+ALU(Value.substring(1+Ic_Indexac[1], --Ic_Indexbag[0]));
                        //ALU(ValueOld);
                        /*System.out.println*/Elaveler.YazdirSpesial(Value.substring(Ic_Indexac[1], Ic_Indexbag[0]));
                        String ValueNew = Value.substring(0, Ic_Indexac[1]) + (ALU(Value.substring(1+Ic_Indexac[1], --Ic_Indexbag[0]))) + Value.substring(++Ic_Indexbag[0], Value.length());
						/* System.out.println*/Elaveler.YazdirSpesial(ValueNew);
                            int MathPositionStart = ACTehliledici.MetinAxtarici(ValueNew, "(");
                        if(MathPositionStart != -1 ){
                            if(String.valueOf(ValueNew.charAt(MathPositionStart)).equals("(")){
                                
                                 
                                /*System.out.println*/Elaveler.YazdirSpesial(">"+ValueNew.substring(MathPositionStart, ValueNew.length()));
                                ALU(ValueNew.substring(2-MathPositionStart, ValueNew.length()));
                            }else{
                                /*System.out.println*/Elaveler.YazdirSpesial(""+ALU(Value.substring(1+Ic_Indexac[1], --Ic_Indexbag[0])));
                                
                                //ALU(Value.substring(Value.substring(1+Ic_Indexac[1], --Ic_Indexbag[0])));
                            }
                        }else{
                            ALU(ValueNew);
                        }
                        
                        //System.out.println(ALU(Value.substring(1+Ic_Indexac[1]) + Value.substring(Value.substring1+Ic_Indexac[1], --Ic_Indexbag[0]) + Value.substring(--Ic_Indexbag[0], Value.length())));
                        //System.out.println(ALU(Value.substring(Ic_Indexac[1], Ic_Indexbag[0])));
                    }
                }
            }
        }
        return -1;
    }
    //public String ALU(String Value){
    //    return "";
    //}
    //public boolean ALU(String Value){
    //    return false;
    //}
}
