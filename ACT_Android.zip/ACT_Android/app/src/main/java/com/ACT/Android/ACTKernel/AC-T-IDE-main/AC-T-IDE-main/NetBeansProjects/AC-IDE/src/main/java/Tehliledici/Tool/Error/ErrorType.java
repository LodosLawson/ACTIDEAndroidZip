package Tehliledici.Tool.Error;

import ac.acYazdir;

public class ErrorType {

    private final acYazdir YAZDIRICI;
    
    private String errortype;
    private String errorname;
    private String errorline;
    private String errordescription;
    private String errorvalue;

//    private Object error
//    private 
    private int ErrorID;
    
    public ErrorType(String errortype, String errorname, String errorline,  String errorvalue, String errordecription, int errorid){
        this.YAZDIRICI = new acYazdir();
        this.errortype = errortype;
        this.errorname = errorname;
        this.errordescription = errordecription;
        this.ErrorID = errorid;
        this.errorline = errorline;
        this.errorvalue = errorvalue;
    }
    
    public void ErrorYazdir(String ERROR){ this.YAZDIRICI.YAZDIR(ERROR); this.YAZDIRICI.Yazdir(); this.YAZDIRICI.dafult();}
    public String getErrortype() { return errortype; }
    public void setErrortype(String errortype) { this.errortype = errortype; }
    public String getErrorname() { return errorname; }
    public void setErrorname(String errorname) { this.errorname = errorname; }
    public Object getErrordescription() { return errordescription; }
    public void setErrordescription(String errordescription) { this.errordescription = errordescription; }
    public int getErrorID() { return ErrorID; }
    public void setErrorID(int ErrorID) { this.ErrorID = ErrorID; }
    public String getErrorline() { return errorline; }
    public void setErrorline(String errorline) { this.errorline = errorline; }
    public String getErrorvalue() { return errorvalue; }
    public void setErrorvalue(String errorvalue) { this.errorvalue = errorvalue; }
    
}
