package GUI.IDE.BackEnd;
/*
import GUI.IDE.IDE;
import backend.KodIsleyici;
import backend.OzelJSCroll;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class IdeBE extends IDE{
    
    //Veriables // Deyisgenler
        //String 
            public static String IDELD;
            
    //Public Static Funksiyalar
    public static void MelumatPaneli(JPanel panel, JLabel text, String Text){
        panel.setVisible(true);
        text.setText(Text);
        new java.util.Timer().schedule(new java.util.TimerTask() {
            @Override
            public void run() {
                java.awt.EventQueue.invokeLater(() -> {
                    panel.setVisible(false);
                });
            }
        },
                5000
        );
    }
   
}*/
