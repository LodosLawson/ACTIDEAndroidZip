
package GUI.KomekHelp.BackEnd;

public class HKItem {
    
    private String Name;
    private String Code;
    private String Description;

    public HKItem(String Name, String Code, String Description) {
        this.Name = Name;
        this.Code = Code;
        this.Description = Description;
    }
    
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String Code) {
        this.Code = Code;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }
    
    
}
