package com.ACT.Android.Tool;

import android.util.*;
import android.view.*;
import com.ACT.Android.*;

public class TouchListener implements View.OnTouchListener
 {

	
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            
            case MotionEvent.ACTION_MOVE:
                // Parmak ekran üzerindeyken hareket ettirildiğinde yapılacak işlemler
                Log.d("TouchListener", "Move");
               
				break;
        }
        return true;
    }
}

