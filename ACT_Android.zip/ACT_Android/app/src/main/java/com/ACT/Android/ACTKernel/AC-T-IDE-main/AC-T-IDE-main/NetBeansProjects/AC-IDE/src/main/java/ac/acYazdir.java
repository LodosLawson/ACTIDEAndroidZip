package ac;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import Tehliledici.Elaveler;
import com.ACT.Android.*;

/*
 * BU CLASS DA OKUNAN MELUMATIN ANALIZI VE OZEL KARAKTERLERIN EKLENMESI GEREKIYOR 
 */
public class acYazdir extends Elaveler {
	
	private String TOPLANAN_MELUMAT = "";
	//private String TOPLANAN_MELUMAT_FAYIL = "";
	
	//YZDIR FONKSIYONUN FAYIL AYAZDIR HISESININ DEYISGEN VE OBJELERIDIR
	private File YAZILACAQ_FAYIL;
	private boolean FAYIL_BILDIRICI_BILDIRIMI; 
	private boolean YAZDIRIM_OZEL_BILDIRIM = true;
	
	public void dafult(){
		TOPLANAN_MELUMAT = "";
		YAZILACAQ_FAYIL = null;
		FAYIL_BILDIRICI_BILDIRIMI = false; 
		YAZDIRIM_OZEL_BILDIRIM = true;
	
		//TOPLANAN_MELUMAT_FAYIL = "";
	}
	public void YAZDIR(String MELUMAT){
		//BURADA ELAVELERIN YAZDIRINAN ISTIFADE EDILMELIDIR VE CONSOLA YAZDIRMA EDILMELIDIR
		//if(!FAYIL_BILDIRICI_BILDIRIMI){
			TOPLANAN_MELUMAT += MELUMAT;
		//}else{
			//TOPLANAN_MELUMAT_FAYIL += MELUMAT;
		//}
	}
	public void YAZDIR(String FAYIL, boolean BILDIRIM){
		//BURADA IYSE OZEL OLARAQ FAYIL YENI ELAVELERIN DOSYA YAZ DIR HISESI CAGRILMLAIDIR 
		Elaveler.YazdirSpesial("------"+FAYIL);
		YAZILACAQ_FAYIL = new File(FAYIL);
		FAYIL_BILDIRICI_BILDIRIMI = BILDIRIM;
	}
	public void YAZDIR(String FAYIL, boolean BILDIRIM, boolean YAZDIR_BILDIRIMI){
		//BURADA IYSE OZEL OLARAQ FAYIL YENI ELAVELERIN DOSYA YAZ DIR HISESI CAGRILMLAIDIR 
		Elaveler.YazdirSpesial("------"+FAYIL);
		YAZILACAQ_FAYIL = new File(FAYIL);
		Elaveler.YazdirSpesial("==="+YAZILACAQ_FAYIL.getAbsoluteFile());
		
		FAYIL_BILDIRICI_BILDIRIMI = BILDIRIM;
		YAZDIRIM_OZEL_BILDIRIM = YAZDIR_BILDIRIMI;	
	}
	public void YAZDIR(){	
            //SIMDILIK BOSDUR 		
	}
	public void Yazdir() {
            if(YAZDIRIM_OZEL_BILDIRIM == true) {
                Yazdir(TOPLANAN_MELUMAT);
            }else {
                //System.out.println("FAYILA YAZILACAQ MELUMAT VE FAYIL : \""+TOPLANAN_MELUMAT+"\""+" : MELUMAT :"+YAZILACAQ_FAYIL.getPath());
                try {
                    Dosya_yaz(TOPLANAN_MELUMAT, YAZILACAQ_FAYIL.getAbsolutePath(), FAYIL_BILDIRICI_BILDIRIMI);
              		
					//TOPLANAN_MELUMAT="";
					Elaveler.YazdirSpesial("==="+YAZILACAQ_FAYIL.getAbsolutePath());
				} catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }	
            }
	}
	
	//ELAVELERIN FONKSIYONLARININ OZLE OLARAK YAZILAMSI 
	//Dosya Islemleri Ucun Yazilan Methodleri
        private void Dosya_yaz(String MELUMAT, String Dosya_Yolu_Dosya, boolean OZEL_BLDIRIM) throws IOException {
            BufferedWriter Yazici = null;
            try { Yazici = new BufferedWriter(new FileWriter(Dosya_Yolu_Dosya, OZEL_BLDIRIM)); } catch (IOException e) { Yazdir("\n PROBLEM VAR <<< Dosya_yaz.Elaveler XETA "); }
            Yazici.write(MELUMAT);   		     
            Yazici.close();
			//TOPLANAN_MELUMAT = "";
			//dafult();
        }
	//
}
