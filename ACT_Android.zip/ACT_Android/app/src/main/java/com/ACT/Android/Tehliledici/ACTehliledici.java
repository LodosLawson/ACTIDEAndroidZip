package com.ACT.Android.Tehliledici;

import android.widget.*;
import com.ACT.Android.Tehliledici.ACTools.*;
import com.ACT.Android.Tehliledici.Tools.*;
import java.util.*;
import com.ACT.Android.*;

public class ACTehliledici extends Elaveler{
	
	//public static TextView OutPutData;
	public static String GlobalOutPut;
	/*
	public ACTehliledici(){
		
	}
	*/
	public static void RunTehliledici(String ACFileName, String ACFilePath){
		Elaveler.DefAcFileName = ACFileName; Elaveler.DefAcFilePath = ACFilePath;
		
		Tehliledici.ACTehliledici ACTKerner = new Tehliledici.ACTehliledici(ACFilePath, ACFileName);
			//Tehliledici.ACTehliledici.mainq(ACFilePath, ACFileName);
		
		
		//FileReadDetectCompilee();
		//Elaveler.OutPut("Hello World\n"+ACFileName+ACFilePath);
	}
	
	public static void FileReadDetectCompilee(){
		String Content = Elaveler.ReadAcFile();
		Scanner scanner = new Scanner(Content);
		int Line = 0;
		
			while (scanner.hasNextLine()) {
				Line += 1;
				if(KeyTyps.TypeDetect(scanner.nextLine())){
					OutPut("true");
				}else{
					
				}
				//ReList.add(r);
				//System.out.println(r);
			}
			scanner.close();
	
	}
}
