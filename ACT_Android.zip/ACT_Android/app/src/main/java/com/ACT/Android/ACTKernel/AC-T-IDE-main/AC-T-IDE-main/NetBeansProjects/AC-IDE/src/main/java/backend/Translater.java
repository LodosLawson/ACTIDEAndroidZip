package backend;
/*
import GUI.IDE.BackEnd.IdeBE;

public class Translater {
    public static String Translater(String EN, String AZ){
       if(IdeBE.IDELD.replaceAll("\\s", "").equals("English")){ return EN; }
       else if(IdeBE.IDELD.replaceAll("\\s", "").equals("Azerbaijan")){ return AZ; }
       return  IdeBE.IDELD;
    }
}*/
