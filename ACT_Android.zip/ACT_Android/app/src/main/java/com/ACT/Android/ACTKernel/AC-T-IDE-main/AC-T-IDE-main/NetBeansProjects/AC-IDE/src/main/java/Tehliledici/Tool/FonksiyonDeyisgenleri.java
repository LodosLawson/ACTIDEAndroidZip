package Tehliledici.Tool;

import Tehliledici.Elaveler;
import Tehliledici.Cesitler.AcarSozler;

public class FonksiyonDeyisgenleri extends Elaveler{

    private String DEYISGENISMI = "";
    private String DEYISGENTIPI = "";
    private String DEYISGENICERIGI = "";

    public FonksiyonDeyisgenleri(String DEYISGENISMI){
        this.DEYISGENISMI = DEYISGENISMI;
    }
    
    public String getDEYISGENISMI(){
        return this.DEYISGENISMI;
    }

    public String getDEYISGENTIPI(){
        return this.DEYISGENTIPI;
    }
    
    public String getDEYISGENICERIGI(){
        return this.DEYISGENICERIGI;
    }
    
    public void setDEYISGETIPI(String DEYISGENTIPI){
        this.DEYISGENTIPI = DEYISGENTIPI;
    }

    public void setDEYISGENICERIGI(String DEYISGENICERIGI){
        this.DEYISGENICERIGI = DEYISGENICERIGI;
    }

    public void DeyisgenTanimi(String Setir, Fonksiyon fonksiyon){
        
        int SH_Index = Elaveler.MetinAxtarici(Setir, "\"");

        if(SH_Index != -1){
            Deyisgen.ACDeyisgenTanimi("herif "+(fonksiyon.getFONKSIYON_UID()+this.DEYISGENISMI+" = "+Setir+";"), "DEF");
        }else{
            if(isStringInt(Setir)){
                //DEYISGENI KONTROL ET VARSA SAYED ICINI DEGIS
                //String Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(this.DEYISGENISMI);
                //if(Deysigen_Icerik.equals("")){	
                    //Deyisgen.ACDeyisgenIcerigDeyisici(this.DEYISGENISMI.replaceAll("\\s",""), Setir);
                    AcarSozler.AS_DIF(fonksiyon.getFONKSIYON_UID()+this.DEYISGENISMI+" = "+Setir+";", "Fonksiyon", true, fonksiyon);                    
                    //Deyisgen.ACDeyisgenVarligi(Setir);
                    //Deyisgen.ACDeyisgenlerStatus();

                //}else{
                   // Deyisgen.ACDeyisgenIcerigDeyisici(this.DEYISGENISMI, Deysigen_Icerik);
                    //System.out.println("\n FONKSIYON DEYISGENLERI >>"+fonksiyon.getFONKSIYON_UID()+this.DEYISGENISMI+Setir);
                //}
            }else {
                String Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(Setir);
                if(Deysigen_Icerik.equals("")){	
                    //Deyisgen.ACDeyisgenIcerigDeyisici(this.DEYISGENISMI.replaceAll("\\s",""), Setir);
                    AcarSozler.AS_DIF(fonksiyon.getFONKSIYON_UID()+this.DEYISGENISMI+" = "+Setir+";", "Fonksiyon", true, fonksiyon);         
                    //Deyisgen.ACDeyisgenVarligi(Setir);
                }else{
                    Deyisgen.ACDeyisgenIcerigDeyisici(this.DEYISGENISMI, Deysigen_Icerik);
                    AcarSozler.AS_DIF(fonksiyon.getFONKSIYON_UID()+this.DEYISGENISMI+" = "+Deysigen_Icerik+";", "Fonksiyon", true, fonksiyon);                    

                    //System.out.println("\n FONKSIYON DEYISGENLERI >>"+fonksiyon.getFONKSIYON_UID()+this.DEYISGENISMI+Setir);
                      
                }
                //System.out.println("sd23");
                //this.DEYISGENICERIGI = Deyisgen.ACDeyisgenDondurucu(Setir);
               // Deyisgen.ACDeyisgenIcerigDeyisici(this.DEYISGENISMI, Setir);

            }
        }
    }
}
