package  Tehliledici.Tool;

import Tehliledici.ACT;
import Tehliledici.Elaveler;
import java.io.File;
import java.io.IOException;

public class Deyisgen extends Elaveler{
	
    //DEYISMEYEN DEYISGEN SAYI LIMITI
    //  int DEYISGENLIMITI = 100000; 

    //DEYISGEN 
    public static int x = 0;
    
    //public static int y = 2;
    public static String AC_Deyisgenler[][] = new String[20][3];
    public static String AC_Fonksiyon_Deyisgenleri[][] = new String[20][3];

    public static boolean gonderilecek_deyer = false;
	
    //UST_GLOBAL_LIST Ucun yaradilmis sayac list sayisini tutar 
    public static int UGL_Sayac = 1;		

    public static void deyigendefault(){
        AC_Deyisgenler = new String[20][3];
        gonderilecek_deyer = false;
        UGL_Sayac = 1;
        x = 0;
    }
    
    public static void ACDeyisgenlerStatus(){
        /*System.out.println*/Elaveler.YazdirSpesial("---------.----------");
        int x = 0;	
        for(int i = 0; i <= 1000; i++) {	
            int y = 1; 
            if(Deyisgen.AC_Deyisgenler[x][y] != null){
                try {    // [x]y[] == nnull
                    /*System.out.println*/Elaveler.YazdirSpesial("Deyisgen Ismi - "+Deyisgen.AC_Deyisgenler[x][y]);
					/* System.out.println*/Elaveler.YazdirSpesial("Deyisgen Icerig - "+Deyisgen.AC_Deyisgenler[x][++y]);

                    ++x;  		
                } catch(NullPointerException e) {
					Elaveler.YazdirSpesial(e);
                    break;
                }
            }else{
				
				Elaveler.YazdirSpesial("Not dfn Deyisgen");
				break;
			}
        }
    }
    public static boolean ACDeyisgenVarligYoxlayici(String Deyisgen_Adi){
        int x = 0;	
        for(int i = 0; i <= 1000; i++) {	
            int y = 1; 
            try {    // [x]y[] == nnull
                if(Deyisgen.AC_Deyisgenler[x][y] == null) {	    	
                    break;    	
                }    	
                if(Deyisgen.AC_Deyisgenler[x][y].equals(Deyisgen_Adi)) {    	
                    return true;
                }	    	
                ++x;  		
            } catch(NullPointerException e) {
				Elaveler.YazdirSpesial(e);
                break;
            }
        }

        return false;
    }
    public static boolean ACFonksiyonDeyisgenVarligYoxlayici(String Deyisgen_Adi){
        int x = 0;	
        for(int i = 0; i <= 1000; i++) {	
            int y = 1; 
            try {    // [x]y[] == nnull
                if(Deyisgen.AC_Fonksiyon_Deyisgenleri[x][y] == null) {	    	
                    break;    	
                }    	
                if(Deyisgen.AC_Fonksiyon_Deyisgenleri[x][y].equals(Deyisgen_Adi)) {    	
                    return true;
                }	    	
                ++x;  		
            } catch(NullPointerException e) {
				Elaveler.YazdirSpesial(e);
                break;
            }
        }

        return false;
    }
    public static void ACDeyisgenIcerigDeyisici(String Deyisgen_adi, String io){
        int x = 0;	
        for(int i = 0; i <= 1000; i++) {	
            int y = 1; 
            try {    // [x]y[] == nnull
                if(Deyisgen.AC_Deyisgenler[x][y] == null) {	    	
                    break;    	
                }    	
                if(Deyisgen.AC_Deyisgenler[x][y].equals(Deyisgen_adi)) {    	
                    Deyisgen.AC_Deyisgenler[x][++y] = io;
                }	    	
                ++x;  		
            } catch(NullPointerException e) {
				Elaveler.YazdirSpesial(e);
                break;
            }
        }
    }

    public static String ACDeyisgenDondurucu(String Deyisgen_adi) {
        String Geri_Dondurulen_Deyisgen = "";
        int x = 0;	
        for(int i = 0; i <= 1000; i++) {	
            int y = 1; 
            try {    // [x]y[] == nnull
                if(Deyisgen.AC_Deyisgenler[x][y] == null) {	    	
                    break;    	
                }    	
                if(Deyisgen.AC_Deyisgenler[x][y].equals(Deyisgen_adi)) {    	
                    Geri_Dondurulen_Deyisgen = Deyisgen.AC_Deyisgenler[x][++y];
                }	    	
                ++x;  		
            } catch(NullPointerException e) {
				Elaveler.YazdirSpesial(e);
                break;
            }
        }
        return Geri_Dondurulen_Deyisgen;
    }
    
    public static String ACDeyisegnYoxlayici(String Yoxlanan, String Yoxlayici, String mod) {
    	String Bildirici = "";
    	/*
    	 * BU RADA ILK OLARAK HERIFI AL DAHA SONRA 
    	 * TIPINI SEC VE DAHA SONRA ISMINI DAHA SONRADA IYSE ICERIGI OKU
    	 */
    	
    	//BURADA ILK OLARAK SIFIRDAN = KADAR OKUNUR VE DIGER BOS HISELR SILIRIN VE ILK OLARAK 5 DEN VEE = BUA KADARLIK
    	//KISIMI ISMI OLARAK ALINIR VE DAHA SONRA TIPINI ALIR 
    	int ILK_INDEK =  MetinAxtarici(Yoxlanan, "=");
    	int IKINCI_INDEX = MetinAxtarici(Yoxlanan, ";");
    			
    	String O = Yoxlanan.substring(0, ILK_INDEK).replaceAll("\\s", "");
    	String ilkalici = O.substring(0, 5);
        String DefaultYoxlayici = Yoxlanan.substring(ILK_INDEK, IKINCI_INDEX).replaceAll("\\s", "");

    	String ikincialici = O.substring(5, O.length()).replaceAll("\\s", "");
    	try{
            if(ilkalici.equals("herif")) {    	
                Yoxlayici = ilkalici;        
                
                int[] Ic_Index = MultiAxtarici(DefaultYoxlayici, "\"","USTGLOBALOZEL");  
                int Ic_Ilk = Ic_Index[0];
                int Ic_Son = Ic_Index[1];

                //int i = ACTehliledici.MetinAxtarici(DefaultYoxlayici, ";");
                
                //int[] Ic_Index_Son = ACTehliledici.MultiAxtarici(DefaultYoxlayici, ";");	

                //Yazdir("\n>>>"+--Ic_Index_Son[1]);
                //Yazdir("\n>>>"+Ic_Son);

                //Yazdir("\n\n\n>>"+Ic_Ilk+" = "+Ic_Son+"\n\n\n >>>"+DefaultYoxlayici.length());
                //Yazdir(DefaultYoxlayici.substring(Ic_Ilk, Ic_Son));

                if(1+Ic_Son == DefaultYoxlayici.length()){             
                    if(Ic_Ilk != -1 && Ic_Son != -1) {
                        String ucuncualici = DefaultYoxlayici.substring(Ic_Ilk, Ic_Son);
                        if(ilkalici.equals(Yoxlayici)) {		    	
                            if(ikincialici.equals("") || ucuncualici.equals("")) {	    	
                                Yazdir("Deyisgenlerde bir problem var deyiusgen tanimi zamani bir problem oldu");	    	
                            } else {	    	
                                if(ikincialici.equals("")) {	    	
                                    Yazdir("\nBOSDUR ");	    		
                                }	    	
                            if(mod.equalsIgnoreCase("ustglobal")) {	    						    	
                                
                                int y = 1;	    		
                                AC_Deyisgenler[x][y] = ikincialici;	    		
                                AC_Deyisgenler[x][++y] = ucuncualici;	    		
                                if(gonderilecek_deyer == false) {		    		
                                    File dosya_javasc = new File(ACT.Dosya_Yolu+"DE");	    		
                                    if (!dosya_javasc.exists()) {	    		
                                        if (dosya_javasc.mkdir()) {	    			
                                            Yazdir("\nUSTGLOBAL ucun deyisgenler tanimlandi.");
                                            gonderilecek_deyer = true;	    			    
                                        } else { Yazdir("/nQovluq Yaradildiqi Zaman Xeta Basverdi <<< DosyaYazici XETA"); }	    			
                                    } else { gonderilecek_deyer = false; }
                                }		    		
                                // <<< BU KOD SAYESINDE USTGLOBAL DEYISGENLERINI LISTELEYE BILECIYIK	    		
                                try { Dosya_yaz(ucuncualici, ACT.Dosya_Yolu+"DE"+ACT.sla+(ACT.Ust_Global_List[UGL_Sayac] = AC_Deyisgenler[x][--y]+".de")); } catch (IOException e) {}	    		
                                UGL_Sayac++;	    		
                                ++x;	    		
                            } else {   	
                                if(ikincialici.equals("") || ucuncualici.equals("")) {   		
                                    Yazdir("Deyisgenlerde bir problem var deyiusgen tanimi zamani bir problem oldu");	   
                                } else {				    		
                                    int y = 1;	    		
                                    AC_Deyisgenler[x][y] = ikincialici;	    		
                                    AC_Deyisgenler[x][++y] = ucuncualici;	    		
                                    ++x;	    		
                                }	    		
                            }		    	
                        }		    	
                    } else {	    
                        if(ilkalici.equals("")) {	    	
                            Yazdir("Deyisgen Tanimi zamani XETA basverdi");    	
                            return "XETA";	    	
                        }	    	
                    }  	          
                }else { 	
                    System.out.println("HERIF Xeta");
					Elaveler.YazdirSpesial("HERİF XETA");
                }
            }
            return "HERIF";	
        }else if(ilkalici.equals("reqem")){    	
                Yoxlayici = ilkalici;
                String ucuncualici = Yoxlanan.substring(++ILK_INDEK, IKINCI_INDEX).replaceAll("\\s", "");
                int BILDIRICI = MetinAxtarici(ucuncualici, '\"');            
                if(BILDIRICI == -1) {
                    if(IC(ucuncualici) != false) {
                        if(ilkalici.equals(Yoxlayici)) {              
                            if(ikincialici.equals("") || ucuncualici.equals("")) {		    		
                                Yazdir("Deyisgenlerde bir problem var deyiusgen tanimi zamani bir problem oldu");		    	
                            } else {		    
                                if(ikincialici.equals("")) {		    	
                                    Yazdir("\nBOSDUR ");		    	
                                }		    	
                                if(mod.equalsIgnoreCase("ustglobal")) {
                                    int y = 1;		    	
                                    AC_Deyisgenler[x][y] = ikincialici;		    	
                                    AC_Deyisgenler[x][++y] = ucuncualici;		
                                    if(gonderilecek_deyer == false) {			    	
                                        File dosya_javasc = new File(ACT.Dosya_Yolu+"DE");		    		
                                        if (!dosya_javasc.exists()) {		    		
                                            if (dosya_javasc.mkdir()) {		    		                                        
                                                Yazdir("\nUSTGLOBAL ucun deyisgenler tanimlandi.");		    			
                                                gonderilecek_deyer = true;
                                            } else { Yazdir("/nQovluq Yaradildiqi Zaman Xeta Basverdi <<< DosyaYazici XETA"); }
                                        } else { gonderilecek_deyer = false; }		    		                               
                                    }			    	
                                    // <<< BU KOD SAYESINDE USTGLOBAL DEYISGENLERINI LISTELEYE BILECIYIK
                                    try { Dosya_yaz(ucuncualici, ACT.Dosya_Yolu+"DE"+ACT.sla+(ACT.Ust_Global_List[UGL_Sayac] = AC_Deyisgenler[x][--y]+".de")); } catch (IOException e) { e.printStackTrace(); }
                                    UGL_Sayac++;
                                    ++x;
                                } else {	
                                    if(ikincialici.equals("") || ucuncualici.equals("")) {		    	
                                        Yazdir("Deyisgenlerde bir problem var deyiusgen tanimi zamani bir problem oldu");		    		
                                    } else {					    	
                                        int y =1;		    		
                                        AC_Deyisgenler[x][y] = ikincialici;		    		
                                        AC_Deyisgenler[x][++y] = ucuncualici;		    		
                                        ++x;		    		
                                    }		    	
                                }   			    	
                            }			    
                        } else {		
                            if(ilkalici.equals("")) {
                                Yazdir("Deyisgen Tanimi zamani XETA basverdi");		    	
                                return "XETA";		    	
                            }		    
                        }
                        return "REQEM";
                    } else {
                        Yazdir("\nBURDA HEC BIR DEYISEGN YOXDU ");	          
                    }
                }else {
                    Yazdir("\nXETA REQEM DUZGUN DEYISGEN DAXIL ETMEYINIZ LAZIMDIR");
                }
            }else {
                Yazdir("\nXETA BIR reqem Daxil Etmeniz Gerk  ");
            }
        } catch(Exception e){
            e.printStackTrace();
			Elaveler.YazdirSpesial(e);
        }
        //return gonderilecek_deyer;
        return "BOSDUR";
    }    
    public static boolean ACDeyisgenTanimi(String setir, String mod) {
        
        //String Setir = setir.replace(" ", "");
        //String ilkalici = Setir.substring(0,  5);
        //String ikincialici = "";
        //String ucuncualici = "";
        String DURUM = ACDeyisegnYoxlayici(setir, "reqem", mod);
	
        if(DURUM.equals("HERIF")) {
            //Yazdir("\nHERIF DEYISEGNI ISLEYIR ");
        } else if (DURUM.equals("REQEM")) {
            //Yazdir("\nREQEM DEYISGENI ILSEYIR");
        } else if(DURUM.equals("XETA")){
            //Yazdir("\nXETA BAS VERDI <<< ACDeyisgenTanimi");
        } else if (DURUM.equals("BOSDUR")){
            //Yazdir("\nBOSDUR ");
        }else {
            Yazdir("\nBURDA HEC BNIR DEYISEGN YOXDU ");
        }
        return true;	
    }
}
