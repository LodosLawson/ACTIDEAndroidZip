
package backend;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
//import javax.swing.JLabel;
//import javax.swing.JPanel;


public class Elaveler {
    
    String Geri_Dondurulecek = "";
    
    public void Yazdir(String Melumat){ System.out.println(""+Melumat);}
    
    public String Dosya_oxu(String Dosya_yolu){
        File Dosya_Ac	= new File(Dosya_yolu);
	FileReader Dosya_oxuyar = null;
	try { Dosya_oxuyar = new FileReader(Dosya_Ac); } catch (FileNotFoundException e1) { e1.printStackTrace(); } 
	char[] String_Donusdurucu = new char[(int) Dosya_Ac.length()];
	try { Dosya_oxuyar.read(String_Donusdurucu); Dosya_oxuyar.close(); } catch (IOException e ) { Yazdir("\n PROBLEM VAR <<< Dosya_oxu.Elaveler XETA "); }	
	Geri_Dondurulecek = new String(String_Donusdurucu);
    	return Geri_Dondurulecek;
    }
    public String Dosya_oxu(File Dosya_yolu){
        File Dosya_Ac	= Dosya_yolu;
	FileReader Dosya_oxuyar = null;
	try { Dosya_oxuyar = new FileReader(Dosya_Ac); } catch (FileNotFoundException e1) { e1.printStackTrace(); } 
	char[] String_Donusdurucu = new char[(int) Dosya_Ac.length()];
	try { Dosya_oxuyar.read(String_Donusdurucu); Dosya_oxuyar.close(); } catch (IOException e ) { Yazdir("\n PROBLEM VAR <<< Dosya_oxu.Elaveler XETA "); }	
	Geri_Dondurulecek = new String(String_Donusdurucu);
    	return Geri_Dondurulecek;
    }
    public void Dosya_yaz(String Dosya_yolu, String Melumat) throws IOException{
        BufferedWriter Yazici = null;
	try { Yazici = new BufferedWriter(new FileWriter(Dosya_yolu)); } catch (IOException e) { Yazdir("\n PROBLEM VAR <<< Dosya_yaz.Elaveler XETA "); }
	Yazici.write(Melumat);   		     
	Yazici.close();
    }
    
    
}
