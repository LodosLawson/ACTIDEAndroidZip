package com.ACT.Android.BlockChainACEcoSystem;

// Zincir sınıfı
import java.util.*;
import org.apache.http.protocol.*;

public class BlockChain
 {
    private ArrayList<Block> chain;

    public BlockChain() {
        this.chain = new ArrayList<>();
        // İlk bloğu oluşturun ve zincire ekleyin
        addBlock(new Block(0, "Genesis Block", "0"));
    }

    public void addBlock(Block newBlock) {
        chain.add(newBlock);
    }

    public Block getLatestBlock() {
        return chain.get(chain.size() - 1);
    }
	
	public ArrayList<Block> getChain(){
		return chain;
	}

    // Zincirin geçerliliğini kontrol etmek için bir metot eklenebilir
    // ...
	
    public  Block getPreviousBlock(int currentIndex) {
        return chain.get(currentIndex - 1);
    }
	public boolean isValidChain() {
        for (int i = 1; i < chain.size(); i++) {
            Block currentBlock = chain.get(i);
            if (!currentBlock.isValid()) {
                return false;
            }
        }
        return true;
    }
    // Diğer metotlar burada...
    // Zincirin içeriğini görüntülemek için bir metot eklenebilir
    // ...
}
