package com.ACT.Android;


import android.*;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class SecondActivity extends Activity implements dialog.ExampleDialogListener {
	
	//File Data
	public static String SelectFile;
	public static String SelwctFilePath;
	public static int SelectPosition;
	public static TextView selectedpath;
	//public static ListView listView;
	public static List itemList;
	public static ArrayAdapter<String> adapter;
	public static String a = "";
	
	private static ListView listView1;
   // private CustomListAdapter adapter1;
    //private List<String> items = new ArrayList<>();
	
	@Override
    public void onBackPressed() {
        // Geri tuşuna basıldığında ne yapılacağını belirtin
        // Örneğin, geri dönme işlemini iptal edebilirsiniz.
        // Bu durumda, boş bir yöntem kullanarak geri dönme işlemini iptal edebilirsiniz.
    	//TextView sftv = findViewById(R.id.selectedfilenameview);
		//sftv.setText(MainActivity.fm.getdirfull(MainActivity.secilenitempoai));
		//a = MainActivity.fm.getdirfull(MainActivity.secilenitempoai);
		super.onBackPressed();
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.layout.mensec, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {
			
			
			case R.id.chatgpt:
				openchtgpt();
				return true;
			case R.id.savefile:
				newGame();
				return true;
			case R.id.openselecfile:
				MainActivity.open();
				
				onBackPressed();
				return true;
			case R.id.seldelfilr:
				opendeleteselfile();
				return true;
			case R.id.deletefile:
				//MainActivity.fm.deleteFile(SelectFile);
				for(int i = 0; i < MainActivity.fm.getdelectedfileobj().getlissizd(); i++){
					MainActivity.fm.deleteFile((String)MainActivity.fm.getpath().get(MainActivity.fm.getdelectedfileobj().getitem(i))+
																		(String)MainActivity.fm.getlist().get(MainActivity.fm.getdelectedfileobj().getitem(i)));
					Toast.makeText(this, ":"+(String) MainActivity.fm.getpath().get(MainActivity.fm.getdelectedfileobj().getitem(i)),3).show();
				}
				uodate();
				
				recreate();
				return true;
			case R.id.createfile:
				//MainActivity.fm.createFile();
				//dialog a = new dialog();
				//a.show(this.getFragmentManager(), "test");
				/*showInputDialog(this, "Başlık", "Mesaj", new InputDialogCallback() {
						@Override
						public void onInputEntered(String input, String inputik) {
							// Girilen veriyi kullan
							MainActivity.fm.createFile(input);
							uodate();
							recreate();
						}

						@Override
						public void onInputCancelled() {
							// Kullanıcının iptal ettiği durumda yapılacak işlemler
						}
					});
					*/
					openDialog();
					
					
				return true;
			
			case R.id.group_delete:
		
				if (item.isChecked()) item.setChecked(false);
				else item.setChecked(true);
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	public static void newGame(){
		System.out.println("fff");
	}
	
	public static void uodate(){
		
		MainActivity.fm = new FileManager(MainActivity.fm.getcontext());
		itemList = MainActivity.fm.getlist();
		// Create an ArrayAdapter to bind the list of strings to the ListView
		adapter = new AdapertCus<>(listView1.getContext(), itemList);
		listView1.setAdapter(adapter);
	}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
		
		// ArrayAdapter örneği oluşturun
		
		//ListView bileşenine ArrayAdapter'ı ayarlayın
		listView1 = findViewById(R.id.listviv);
		final List itemList = MainActivity.fm.getlist();
		//CustomListAdapter adapter = new CustomListAdapter(this, itemList);
       // Adapter adapter = new Adapter(this, itemList);
		ArrayAdapter<String> adapter = new AdapertCus<>(this, itemList);
		
	   listView1.setAdapter(adapter);
	   selectedpath = findViewById(R.id.selectedpath);
		//listView1.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
		/*listView1 = findViewById(R.id.listviv);
		// Get reference to the ListView from the layout file
		//listView = findViewById(R.id.listviv);
		final TextView selpath = findViewById(R.id.selectedpath);
		// Create an array of strings to display in the ListView
		items = MainActivity.fm.getlist();
		// Create an ArrayAdapter to bind the list of strings to the ListView
		//adapter = new ArrayAdapter<>(listView.getContext(), android.R.layout.simple_list_item_1, items);
		adapter1 = new ListViewWithCheckBoxsusu(this,  items);
		listView1.setAdapter(adapter1);
		//listView1.refreshDrawableState();
		*/
		/*listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
					CheckBox checkBox = view.findViewById(android.R.id.checkbox);
					if (checkBox.isChecked()) {
						checkBox.setChecked(false);
						Toast.makeText(listView1.getContext(), "Unchecked item " + i, Toast.LENGTH_SHORT).show();
					} else {
						checkBox.setChecked(true);
						Toast.makeText(listView1.getContext(), "Checked item " + i, Toast.LENGTH_SHORT).show();
					}
				}
			});*/
		// Set the ArrayAdapter as the adapter for the ListView
		//listView.setAdapter(adapter);
		//ListView listviv = findViewById(R.id.listviv);
		// ListView öğelerine tıklama olayı ekle
		
		/*
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					//adapter.toggleSelection(position);
					SelectFile = itemList.get(position).toString();
					SelwctFilePath = MainActivity.fm.getdirfull(position);
					SelectPosition = position;
				
					TextView selectpath = findViewById(R.id.selectedpath);
					selectpath.setText(SelwctFilePath);
					Toast.makeText(listView1.getContext(), "fkfkfk", 3).show();
				}
			});
		
		//ListView listView = findViewById(R.id.listviv); // listView'i layout dosyanızdaki ID ile bağlayın
		/*listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
					CheckBox checkBox = view.findViewById(R.id.checkbox); // CheckBox'ı liste öğesinden alın
					checkBox.setChecked(!checkBox.isChecked()); // CheckBox'ın durumunu tersine çevirin
					Toast.makeText(getApplicationContext(),  " tıklandı.\n"+a, Toast.LENGTH_SHORT).show();
				}
			});
			*/
		/*listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
					// burada tıklanılan öğenin pozisyonunu alabilirsiniz
					// ve istediğiniz işlemi yapabilirsiniz
					String item = (String) adapterView.getItemAtPosition(position);
					//String selectedValue = (String) adapterView.getItemAtPosition(position);
					//Toast.makeText(listView.getContext(), selectedValue, 3);
					//editText.setText(fm.readFile((secilenacdosya)));
					//sftv.setText(MainActivity.fm.getdirfull(MainActivity.secilenitempoai));
					//a = MainActivity.fm.getdirfull(0);
					Toast.makeText(getApplicationContext(), item + " tıklandı.\n"+a, Toast.LENGTH_SHORT).show();
					MainActivity.secilenacdosya = item;
					MainActivity.secilenitempoai = position;
					selpath.setText(MainActivity.fm.getdirfull(position));
					//a();mainactivity

					//super.onCreate(savedInstanceState);
					//setContentView(R.layout.main);
					//EditText editText = findViewById(R.id.filedit);
					//editText.setText(MainActivity.fm.readFile((item.toString())));
				}
			});
			*/
		// TextView textView = findViewById(R.id.textView);
		//  textView.setText("Bu ikinci aktivitenin içeriğidir.");
		
		
		
    }
	
	public void open(){
		EditText editText = findViewById(R.id.editText);
		TextView txv = findViewById(R.id.selectedfilenameview);
		txv.setText(MainActivity.fm.getdirfull(SelectPosition));
		//Toast.makeText(getApplicationContext(), "acildi"+SelectFile+SelectPosition, 3).show();
		editText.setText(MainActivity.fm.readFile(MainActivity.fm.getdirfull(SelectPosition),SelectFile));
		
		//super.onBackPressed();
	}
	private final void back(){
		//MainActivity.open();
		super.onBackPressed();
	}
	public void opendeleteselfile(){
		Intent intents = new Intent(this, FileDetectManager.class );
		startActivity(intents);
	
	}
	public void openchtgpt(){
		Intent intent = new Intent(this, chtgpt.class);
		startActivity(intent);
	}
	public void openDialog() {
        dialog exampleDialog = new dialog();
        exampleDialog.show(getFragmentManager(), "test");// show(getSupportFragmentManager(), "example dialog");
    }

	@Override
    public void applyTexts(String FolderName, String FileName) {
       // textViewUsername.setText(username);
      //  textViewPassword.setText(password);
	  if(!FolderName.equals("")){
		Toast.makeText(this, FolderName, 3).show();
	  	MainActivity.fm.createSubFolder(FolderName);
		MainActivity.fm.createFile(FolderName+"/"+FileName);
	  }else{
		  MainActivity.fm.createFile(FileName);
	  }
	  
    }
	public void showInputDialog(Context context, String title, String message, final InputDialogCallback callback) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(title);
		builder.setMessage(message);

		final EditText editText = new EditText(builder.getContext());
	    final EditText edittext = new EditText(builder.getContext());
		
		
		builder.setView(edittext);
		builder.setView(edittext);

		builder.setPositiveButton("Tamam", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					String veri = editText.getText().toString();
					String veriiki = edittext.getText().toString();
					callback.onInputEntered(veri, veriiki);
					
				}
			});

		builder.setNegativeButton("İpta66l", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.cancel();
					callback.onInputCancelled();
				}
			});

		AlertDialog dialog = builder.create();
		dialog.show();
	}

	public interface InputDialogCallback {
		void onInputEntered(String input, String inputiki);
		void onInputCancelled();
	}
	
}
