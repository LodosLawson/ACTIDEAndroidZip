/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend;
/*
import GUI.IDE.IDE;
/**
 *
 * @author mehemmed
 */
/*
public class KodIsleyici {
    
    //private OzelJSCroll JSCP;
    private String DosyaAdi;
    private String DosyaYolu;
    private int ID;
    
    //private static OzelJSCroll[] AS = new OzelJSCroll[100];
    //private static int sayac = 0;
  
    
    public KodIsleyici(){
        //JSCP = new OzelJSCroll();
        //KodIsleyici.AS[KodIsleyici.sayac] = JSCP;
    }
    public void MelumatYaz(String MELUMAT, int in){
        IDE.SCP[in].Yazdir(MELUMAT);
    }
    public String MelumatAl(int in){
        return IDE.SCP[in].MelumatAL();
    }
    public void KIQur(/*String DosyaAdi, String DosyaYolu, int ID*///){
        /*this.DosyaAdi = DosyaAdi;
        this.DosyaYolu = DosyaYolu;
        this.ID = ID;*/
		/*
        IDE.KI[IDE.SAYACKI] = this;
        IDE.SAYACKI++;
    }
    public void getPANEL(){
        //System.out.println(""+IDE.SAYACSCP);
        IDE.SCP[IDE.SAYACSCP] = (OzelJSCroll) new OzelJSCroll(IDE.keyboard).OzelJSCroll();
       
        //IDE.SCP[IDE.SAYACSCP] = this.JSCP;
       // IDE.SAYACSCP++;
        //return KodIsleyici.AS[KodIsleyici.sayac].OzelJSCroll();
    }

    public void setDosyaAdi(String DosyaAdi) { this.DosyaAdi = DosyaAdi; }

    public void setDosyaYolu(String DosyaYolu) { this.DosyaYolu = DosyaYolu; }

    public void setID(int ID) { this.ID = ID; }

    public String getDosyaAdi() { return DosyaAdi; }

    public String getDosyaYolu() { return DosyaYolu; }

    public int getID() { return ID; }
    
    /*
    //public static JTextPane ui;
    //public static int Sayac = 0;
    //public static int IDKODEISLEYICI;
    //public static String DosyaAdi = "";
    //public static String DosyaYolu = "";
    //private String DosyaAdiID;
    //private String DosyaYoluID;
    //private int ID;
    //public String getDosyaAdiID() {
    return DosyaAdiID;
    }
    public String getDosyaYoluID() {
    return DosyaYoluID;
    }
    public int getID() {
    return ID;
    }
    public KodIsleyici(){
    //IDE.kio[I  KodIsleyici.IDKODEISLEYICI = IDE.sayac;DE.sayac] = this;
    ui = new JTextPane();
    //Document doc = jTextPane1.getDocument();
    }
    public void Yazdir(String Melumat){
    ui.setText(Melumat);
    }
    public String MelumatAL(){
    Yazdir(ui.getText());
    return ui.getText();
    }
    public void qur(String Yol, String Ad, int ID){
    this.DosyaAdiID = Ad;
    this.DosyaYoluID = Yol;
    this.ID = ID;
    IDE.kio[IDE.sayac] = this;
    IDE.sayac++;
    }
    public JScrollPane KodIsleyici(){
    LineNumberPanea lineNumber = new LineNumberPanea( ui );
    //lineNumber.setPreferredSize(99999);
    ((AbstractDocument) ui.getDocument()).setDocumentFilter(new CustomDocumentFilter(ui));
    this.setRowHeaderView( lineNumber );
    this.setViewportView(ui);
    return  this;
    }
     */
   /* 
}*/
