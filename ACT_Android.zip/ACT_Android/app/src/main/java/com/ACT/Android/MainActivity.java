package com.ACT.Android;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import com.ACT.Android.BlockChainACEcoSystem.*;
import com.ACT.Android.Tehliledici.*;
import com.ACT.Android.Tool.*;
import java.util.*;
import javax.sql.*;
public class MainActivity extends Activity
{
	///popup windows output wind
	private Button RunStartButton, closePopupBtn, ImportFilesTrash, Exbt;
    private PopupWindow popupWindow;
    private LinearLayout popupLayout;
    private int xDelta, yDelta;
	public static TextView OutPutTextShow;
	private ListView ShowImportFiles;
	private Button OpenFolderButton;
	////
	
	//Tehliledici Object
	public static ACTehliledici actehliledici;
	
	//
	public static ArrayList<String> ImportSelectFiles = new ArrayList<String>(5);
	public static ArrayList<String> ImportSelectPaths = new ArrayList<String>(5);
	public static ArrayList<Integer> ImportSelectposition = new ArrayList<Integer>(5);
	
	//TextCodeEditor
	private TextView lineCounter;
	// EditText bileşeni tanımlama
	public static EditText editText;
	public static TextView txv, txv2;
	public static ScrollView MainScrollView;
	
	/////
	public static TextView ShowTextView;
	
	//
	Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
   	//public static String secilenacdosya = "";
	//public static int secilenitempoai = 0;
	
	//FileManager Object
	public static FileManager fm;

	public void block()
	{
		// TODO: Implement this method
	}
	
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		//AC T Compiler Install
		actehliledici = new ACTehliledici();
		
		//Logo Install
		getActionBar().setIcon(R.mipmap.ic_launcher);
		
		ShowTextView = findViewById(R.id.ShowText);
		MainScrollView = findViewById(R.id.mainScrollView1);
		//PopOutPut();
		
		//pop
		
		// Inflate the popup_layout.xml
		popupLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.popoutput, null);
		// Initialize the popup window
        popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
		//Run and PopOutPut Button 
		RunStartButton = findViewById(R.id.but);
		//Button Onclick Listener
		RunStartButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					
					// Inflate the popup_layout.xml
					popupLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.popoutput, null);
					// Initialize the popup window
					popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
					
					//PopUp Close Button Tanm
					closePopupBtn = popupLayout.findViewById(R.id.close_button);

					closePopupBtn.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								// Dismiss the popup window
								popupWindow.dismiss();
							}
						});
					// Show the popup window
					//Global OutPut Data Reset and Clear
					ACTehliledici.GlobalOutPut = "";
					//Popup window OutPut Show
					popupWindow.showAsDropDown(v, 0, 0);
					popmove(popupLayout);
					//Run AC File And Compiler (Tehliledici)
					MainActivity.actehliledici.RunTehliledici(SecondActivity.SelectFile,SecondActivity.SelwctFilePath);
					
					block(ACTehliledici.GlobalOutPut);
					
					//Set Global OutPut Text 
					OutPutTextShow = popupLayout.findViewById(R.id.PopConsolOutPut);
					OutPutTextShow.setText(ACTehliledici.GlobalOutPut);
					
				}
			});
		
		Exbt = findViewById(R.id.lis);
		Exbt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v){
				// Inflate the popup_layout.xml
				popupLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.importfiles, null);
				// Initialize the popup window
				popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				popupWindow.showAsDropDown(v, 0, 0);
				popmove(popupLayout);
				ShowImportFiles = popupLayout.findViewById(R.id.selectimportfiles);
				showimportfiles(ShowImportFiles);
				
				ImportFilesTrash = popupLayout.findViewById(R.id.ClearImportButton);
				ImportFilesTrash.setOnClickListener(new View.OnClickListener(){
					public void onClick(View v){
						ImportSelectPaths.clear();
						ImportSelectFiles.clear();
						ImportSelectposition.clear();
						popupWindow.dismiss();
					}
				});
			}
		});
		
		//////////
		
		OpenFolderButton = findViewById(R.id.openfoldeebut);
		OpenFolderButton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				openfile();
			}
		});
		
		
		//getActionBar().setBackgroundDrawable());
		//getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
		
		//SelectFile Show 
		txv = findViewById(R.id.selectedfilenameview);
		txv2 = findViewById(R.id.selectfile);
		//FileManager Install
		fm = new FileManager(this);
		
		//folder()
		//ListView listvie = findViewById(R.id.listfil);
		
		//Text Code Editor Install
		editText = findViewById(R.id.editText);
		
		//editText = findViewById(R.id.filedit);
		//List dirall = fm.listAllFiles();
		//ListView lv = findViewById(R.id.faillist);
		for(int i = 0; i > fm.getlist().size(); i++){
			editText.setText(fm.getlist().get(i));
		}
		/*listvie.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
					// burada tıklanılan öğenin pozisyonunu alabilirsiniz
					// ve istediğiniz işlemi yapabilirsiniz
					String item = (String) adapterView.getItemAtPosition(position);
					Toast.makeText(getApplicationContext(), item + " tıklandı.", Toast.LENGTH_SHORT).show();
					secilenacdosya = item;
					secilenitempoai = position;
				}
			});
		*/
		
		
		
        lineCounter = findViewById(R.id.lineNumberView);

        // EditText içerisine her karakter girildiğinde çağrılan TextWatcher
        editText.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
					// samma
					updateLineCounter();
					
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					// yeni satır eklendiğinde satır numarasını güncelle
					if (before == 0 && count == 1 && s.charAt(start) == '\n') {
						updateLineCounter();
					}
				}

				@Override
				public void afterTextChanged(Editable s) {
					// samma
					updateLineCounter();
				}
			});

        // EditText kaydırıldığında çağrılan OnScrollChangeListener
        editText.setOnScrollChangeListener(new View.OnScrollChangeListener() {
				@Override
				public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
					// satır numarasını güncelle
					updateLineCounter();
				}
			});
	}
	public void popmove(LinearLayout popupLayoutx){
		// Add touch listener to the popup window
        popupLayoutx.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							// Get the current touch location of the popup window
							int[] location = new int[2];
							popupLayout.getLocationOnScreen(location);
							int x = location[0];
							int y = location[1];

							// Save the initial touch point of the popup window
							xDelta = (int) (event.getRawX() - x);
							yDelta = (int) (event.getRawY() - y);
							break;
						case MotionEvent.ACTION_MOVE:
							// Get the screen size
							Display display = getWindowManager().getDefaultDisplay();
							Point size = new Point();
							display.getSize(size);
							int screenWidth = size.x;
							int screenHeight = size.y;

							// Calculate the new position of the popup window
							int newX = (int) event.getRawX() - xDelta;
							int newY = (int) event.getRawY() - yDelta;

							// Restrict the popup window's position within the screen
							if (newX < 0) newX = 0;
							if (newY < 0) newY = 0;
							if (newX > screenWidth - popupWindow.getWidth()) newX = screenWidth - popupWindow.getWidth();
							if (newY > screenHeight - popupWindow.getHeight()) newY = screenHeight - popupWindow.getHeight();

							// Update the position of the popup window
							popupWindow.update(newX, newY, -1, -1);
							break;
					}
					return true;
				}
			}
		);
	}
	// satır numarasını güncellemek için kullanılan yardımcı fonksiyon
    private void updateLineCounter() {
        int lines = editText.getLineCount();
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append(i);
            sb.append("\n");
        }
        lineCounter.setText(sb.toString());
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.layout.men, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {
			
			case R.id.xconsolm:
				RunConsolX();
				return true;
			case R.id.xconsol:
				//runtehliledici();
				RunConsolX();
				return true;
			case R.id.chatgpt1:
				xsc();
				//openchtgpt();
				return true;
			case R.id.save:
				save();
				return true;
			case R.id.openfile:
				openfile();
				return true;
			case R.id.acbrowser:
				connectrtps();
				return true;
			case R.id.savefile:
				newGame();
				return true;
		
			case R.id.group_delete1:

				if (item.isChecked()) item.setChecked(false);
				else item.setChecked(true);
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	public static void newGame(){
		System.out.println("fff");
	}
	
	public void openfile(){
		Intent intents = new Intent(MainActivity.this, SecondActivity.class);
		startActivity(intents);
	}
	public void openchtgpt(){
		Intent intents = new Intent(MainActivity.this, chtgpt.class);
		startActivity(intents);
	}
	public void save(){
		EditText editText1 = findViewById(R.id.editText);
		boolean a = fm.saveFile(SecondActivity.SelwctFilePath ,SecondActivity.SelectFile, editText1.getText().toString());
		if(a){
			Toast.makeText(getApplicationContext(), "kaydedildi Save", 3).show();
		}else{
			Toast.makeText(getApplicationContext(), "Error Save", 4).show();
		}
	}
	public void connectrtps(){
		Intent intents = new Intent(MainActivity.this, ACBrow.class);
		startActivity(intents);
	}
	public static void open(){
		
		//true visibliy 
		MainScrollView.setVisibility(1);
		ShowTextView.setVisibility(-1);
		txv.setText(MainActivity.fm.getdirfull(SecondActivity.SelectPosition));
		txv2.setText(MainActivity.fm.getlist().get(SecondActivity.SelectPosition).toString());
		//Toast.makeText(getApplicationContext(), "acildi"+secilenacdosya+secilenitempoai, 3).show();
		editText.setText(MainActivity.fm.readFile(SecondActivity.SelwctFilePath, SecondActivity.SelectFile));
		
		if(ImportSelectPaths.contains(SecondActivity.SelwctFilePath) &&
			ImportSelectFiles.contains(SecondActivity.SelectFile) &&
		   		ImportSelectFiles.contains(SecondActivity.SelectFile)){
			}else{
				ImportSelectposition.add(SecondActivity.SelectPosition);
				ImportSelectFiles.add(SecondActivity.SelectFile);
				ImportSelectPaths.add(SecondActivity.SelwctFilePath);
		}
	}
	public void InterOpenSelectImportFiles(int position, String selectpath, String selectfile){
		//save();
		txv.setText(MainActivity.fm.getdirfull(position));
		txv2.setText(MainActivity.fm.getlist().get(position).toString());
		
		//Toast.makeText(getApplicationContext(), "acildi"+secilenacdosya+secilenitempoai, 3).show();
		editText.setText(MainActivity.fm.readFile(selectpath, selectfile));
		
	}
	public void runtehliledici(){
		/*Intent intents = new Intent(MainActivity.this, TehlilediciActivity.class);
		startActivity(intents);*/
	}
	public void xsc(){
		Intent intent = new Intent(MainActivity.this, chtgpt.class);
		startActivity(intent);
	}
	public void RunConsolX(){
		Intent intent = new Intent(MainActivity.this, xconcolactivity.class);
		startActivity(intent);
	}
	
	
	public void showimportfiles(ListView Lv){
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ImportSelectFiles);
		//ListView listView = (ListView) findViewById(R.id.listview);
		Lv.setAdapter(adapter);
		Lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					save();
					// Tıklanan öğeyi alın
					String selectedItem = ImportSelectFiles.get(position);
					String selectpath = ImportSelectPaths.get(position);
					int selectposition = ImportSelectposition.get(position);
					SecondActivity.SelwctFilePath = selectpath;
					SecondActivity.SelectFile = selectedItem;
					SecondActivity.SelectPosition = selectposition;
					// Yapılacak işlemi burada belirleyin
					//Toast.makeText(getApplicationContext(), "Tıklandı: " + selectedItem+":"+selectpath, Toast.LENGTH_SHORT).show();
					InterOpenSelectImportFiles(position, selectpath, selectedItem);
				}
			});
		/*
		for(int i = 0; i > ImportSelectFiles.size(); i++){
			if(ImportSelectFiles.get(i) != null){
				
			}
		}*/
	}
	
	//POP
	/*
	public void PopOutPut(){
		showPopupBtn = findViewById(R.id.but);
		showPopupBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Show the popup window
					popupWindow.showAsDropDown(v, 0, 0);
				}
			});
		// Inflate the popup_layout.xml
        popupLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.importfiles, null);

        // Initialize the popup window
        popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
		//popupWindow.showAsDropDown(v, 0, 0);
		
        // Add touch listener to the popup window
        popupLayout.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							// Get the current touch location of the popup window
							int[] location = new int[2];
							popupLayout.getLocationOnScreen(location);
							int x = location[0];
							int y = location[1];

							// Save the initial touch point of the popup window
							xDelta = (int) (event.getRawX() - x);
							yDelta = (int) (event.getRawY() - y);
							break;
						case MotionEvent.ACTION_MOVE:
							// Get the screen size
							Display display = getWindowManager().getDefaultDisplay();
							Point size = new Point();
							display.getSize(size);
							int screenWidth = size.x;
							int screenHeight = size.y;

							// Calculate the new position of the popup window
							int newX = (int) event.getRawX() - xDelta;
							int newY = (int) event.getRawY() - yDelta;

							// Restrict the popup window's position within the screen
							if (newX < 0) newX = 0;
							if (newY < 0) newY = 0;
							if (newX > screenWidth - popupWindow.getWidth()) newX = screenWidth - popupWindow.getWidth();
							if (newY > screenHeight - popupWindow.getHeight()) newY = screenHeight - popupWindow.getHeight();

							// Update the position of the popup window
							popupWindow.update(newX, newY, -1, -1);
							break;
					}
					return true;
				}
			});

        // Add click listener to the button that shows the popup window
        
		
		
		
		 // Add click listener to the button inside the popup window that closes the popup window
		 closePopupBtn = popupLayout.findViewById(R.id.close_button);
		 closePopupBtn.setOnClickListener(new View.OnClickListener() {
		 @Override
		 public void onClick(View v) {
		 // Dismiss the popup window
		 popupWindow.dismiss();
		 }
		 });
		 
	}
	//////////*/
	
	private static int index = 0;
	public static BlockChain blockchain = new BlockChain();
	
	public final void block(String Data){
		// Blok zincirini oluşturun
        
		// Yeni bir blok ekleyin
        Block block1 = new Block(index, Data, blockchain.getLatestBlock().getHash());
        blockchain.addBlock(block1);
		
		index = index +1;
      

        /*// Yeni bir blok ekleyin
        Block block2 = new Block(2, "Data 2", blockchain.getLatestBlock().getHash());
        blockchain.addBlock(block2);*/

        // Zincirin içeriğini görüntüleyin
		String OutPutDat;
        for (Block block : blockchain.getChain()) {
			
            System.out.println("Block: " + block.getİndex());
            //System.out.println("Data: " + block.getData());
            System.out.println("Previous Hash: " + block.getPreviousHash());
            System.out.println("Hash: " + block.getHash());
            System.out.println("Okejj  "+block.isValid());
			System.out.println();
        }
	}
}
