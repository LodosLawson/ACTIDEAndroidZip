package Tehliledici.Tool.ChatGPTConnect;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import backend.*;
import Tehliledici.*;


public class ChatGPT {
    public static void CGPT() throws IOException {
        URL url = new URL("https://api.openai.com/v1/engine/davinci-codex/completions");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json");
        con.setRequestProperty("Authorization", "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");

        con.setDoOutput(true);
        String input = "{\"prompt\": \"Hello ChatGPT\", \"max_tokens\": 10}";
        con.getOutputStream().write(input.getBytes());

        BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String line;
        StringBuffer response = new StringBuffer();
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        Tehliledici.Elaveler.Yazdir(response.toString());
    }
}

