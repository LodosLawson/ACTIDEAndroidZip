
package backend;
/*
import GUI.IDE.BackEnd.IdeBE;
import GUI.IDE.IDE;
import GUI.KomekHelp.KomekHelp;

import java.awt.Color;
import java.awt.Rectangle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.text.TabSet;
import javax.swing.text.TabStop;
import javax.swing.text.View;

public class CustomDocumentFilter extends DocumentFilter {
    /**
   * Return a list containing of the number of wrapped lines of text and the wrapped line 
   * index at the caret posistion
   * @param component JTextArea
   * @return int[]
   */
   /*
  public static int[] getWrappedLines(JTextArea component) {
    int[] wrappedlines = new int[2];
    int y = 0;
    View view = component.getUI().getRootView(component).getView(0);
    int preferredHeight = (int) view.getPreferredSpan(View.Y_AXIS);
    try {
      Rectangle caretCoords = component.modelToView(component.
          getCaret().getDot());
      y = (int) caretCoords.getY();
    }
    catch (BadLocationException ex) {
    }

    int lineHeight = component.getFontMetrics(component.getFont()).getHeight();
    wrappedlines[0] = preferredHeight / lineHeight;
    wrappedlines[1] = (y / lineHeight) + 1;
    return wrappedlines;
  }
     
    JTextPane pane;
    String[] ALL_WORDS_THAT_YOU_WANT_TO_FIND = {"BASLANQIC", "SON AC", "USTGLOBAL", "JAVA", "C", "YAZDIR", "PRINT", "AC CODE", "DIF",
        "reqem", "herif", "EXIT", "CIXIS", "SAXLA", "SAVE", "MOD", "MODON", "MODOF", "RUN", "TEHLILET", "DOSYOL", "HELP"};
    
    /*
       CUBIKLER YASIL IYLE 
       ACAR SOZLER GOY IYLE 
       DIL TANIMLARI JAVA , C VE SAYR IYSE SARI IYLE 
       BUNLAR UZERINDE ISLEMEK OLAR HELIL BU NLARI QEYD EDEK 
    */
	/*
    public CustomDocumentFilter(JTextPane pane){
        this.styledDocument = pane.getStyledDocument();
        this.pane = pane;
    }
    private final StyledDocument styledDocument;

    private final StyleContext styleContext = StyleContext.getDefaultStyleContext();
    
    //TEXT COLOR STYLES 
    private final AttributeSet greenAttributeSet = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, Color.GREEN);
    private final AttributeSet redAttributeSet = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, Color.RED);
    private final AttributeSet blackAttributeSet = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, Color.BLACK);
    
    //AC CODE TANIMI UYCUN
    private final AttributeSet ACCODETANMIUYCUN = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, new java.awt.Color(43, 87, 84));
    
    private final AttributeSet BOZOZELRENG = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, new java.awt.Color(43, 87, 84));
    private final AttributeSet SARIOZELRENG = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, new java.awt.Color(255, 198, 37));
    private final AttributeSet GOYOZELRENG = styleContext.addAttribute(styleContext.getEmptySet(), StyleConstants.Foreground, new java.awt.Color(0, 29, 231));

    
// Use a regular expression to find the words you are looking for
    Pattern pattern = buildPattern();

    @Override
    public void insertString(FilterBypass fb, int offset, String text, AttributeSet attributeSet) throws BadLocationException {
        //text = text.replaceAll("\t", " ");
        TabSet tabs = new TabSet(new TabStop[] {new TabStop(20) });
        AttributeSet paraSet = styleContext.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.TabSet, tabs);
        this.pane.setParagraphAttributes(paraSet, false);
        super.insertString(fb, offset, text, attributeSet);
        
        handleTextChanged();
    }

    @Override
    public void remove(FilterBypass fb, int offset, int length) throws BadLocationException {
        super.remove(fb, offset, length);

        handleTextChanged();
    }

    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attributeSet) throws BadLocationException {
        TabSet tabs = new TabSet(new TabStop[] {new TabStop(20) });
        AttributeSet paraSet = styleContext.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.TabSet, tabs);
        this.pane.setParagraphAttributes(paraSet, false);
        super.replace(fb, offset, length, text, attributeSet);
        handleTextChanged();
    }

    /**
     * Runs your updates later, not during the event notification.
     */
	 /*
    private void handleTextChanged()
    {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                updateTextStyles();
            }
        });
    }

    /**
     * Build the regular expression that looks for the whole word of each word that you wish to find.  The "\\b" is the beginning or end of a word boundary.  The "|" is a regex "or" operator.
     * @return
     */
	 /*
    private Pattern buildPattern()
    {
        StringBuilder sb = new StringBuilder();
        for (String token : ALL_WORDS_THAT_YOU_WANT_TO_FIND) {
            sb.append("\\b"); // Start of word boundary 
            sb.append(token);
            sb.append("\\b|"); // End of word boundary and an or for the next word
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1); // Remove the trailing "|"
        }

        Pattern p = Pattern.compile(sb.toString());

        return p;
    }
    static boolean bayragdurumu = true;
    static boolean Bildiris = false;

    private void updateTextStyles()// throws BadLocationException
    {
          
        TabSet tabs = new TabSet(new TabStop[] {new TabStop(20) });
        AttributeSet paraSet = styleContext.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.TabSet, tabs);
        this.pane.setParagraphAttributes(paraSet, false);
        // Clear existing styles
        styledDocument.setCharacterAttributes(0, pane.getText().length(), blackAttributeSet, true);

        // Look for tokens and highlight them
        Matcher matcher = pattern.matcher(pane.getText());
        while (matcher.find()) {
            // Change the color of recognized tokens
            //BURADA BIR CLASS TANIMI OLUNARAQ ACTEHLILEDICI YE BAGLANARAQ OZEL DEYGENLERIN VE KEYWORDLERIN SECILEREK GERI KOD IYLE RENGLENMESI VE SORUNSUZ ISLEMENIN YARADILMASI
            //System.out.println((matcher.start()+matcher.end()));
            //System.out.println(matcher.group());
            //if(matcher.group().equals("salam")){
            //styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), redAttributeSet, false);
            //} else {
            //styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), greenAttributeSet, false);
            //}
            switch (matcher.group()) {
                case "SON AC":
                    styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), BOZOZELRENG, false);
                    break;
                case "JAVA":
                case "C":
                    styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), SARIOZELRENG, false);
                    break;
                case "YAZDIR":
                case "PRINT":
                case "DIF":
                case "USTGLOBAL":
                case "herif":
                case "reqem":
                case "BASLANQIC":
                    styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), GOYOZELRENG, false);
                    break;
                default:
                    break;
            }
            if(Bildiris == true){
                switch (matcher.group()) {
                    case "AC CODE":
                        styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), ACCODETANMIUYCUN, false);
                        try{             
                            pane.getDocument().insertString(matcher.end(), "v3.0", null);
                            pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));
                        }catch(BadLocationException e){
                        }   break;
                    case "SAVE":
                    case "SAXLA":
                        pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));
                        String Gelen_Deyer_Saxla = IDE.FayilSaxla();
                        if(Gelen_Deyer_Saxla.equals("SAVEFILE")){
                            IdeBE.MelumatPaneli(IDE.MelumatPaneli, IDE.MelumatPanelText, Translater.Translater("File Saveed", ".AC File Saveed."));
                        }else if(Gelen_Deyer_Saxla.equals("NONFILE")){
                            IdeBE.MelumatPaneli(IDE.MelumatPaneli, IDE.MelumatPanelText, Translater.Translater("Please open an .AC file.", "Zəhmət olmasa .AC faylını açın."));
                        }
                        
                        break;
                    case "RUN":
                    case "TEHLILET":
                        pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));
                        String Gelen_Deyer_Tehlil = IDE.Tehlilet();
                        if(Gelen_Deyer_Tehlil.equals("CHANGFILE")){
                            IdeBE.MelumatPaneli(IDE.MelumatPaneli, IDE.MelumatPanelText, Translater.Translater("Please save the .AC file.", "Zəhmət olmasa .AC faylını yadda saxlayın."));
                        }else if(Gelen_Deyer_Tehlil.equals("NONFILE")){
                            IdeBE.MelumatPaneli(IDE.MelumatPaneli, IDE.MelumatPanelText, Translater.Translater("Please open an .AC file.", "Zəhmət olmasa .AC faylını açın."));
                        }
                        break;
                    case "DOSYOL":
                        try{ pane.getDocument().insertString(matcher.end(), IDE.DOSYOL(), null); } catch(Exception e){}
                        pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));
                        break;
                    case "HELP":
                        pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));

                        //CustomDocumentFilter.Data data = new CustomDocumentFilter.Data();
                        //data.BK();

                        IDE.KH.main(ALL_WORDS_THAT_YOU_WANT_TO_FIND);  
                        //System.out.println(""+matcher.start());
                        //System.out.println(""+matcher.end());
                        KomekHelp.x = matcher.start();
                        KomekHelp.y = matcher.end();
                        KomekHelp.PANEL = this.pane;
                        //IDE.KH.UEE(matcher.start(), matcher.end(), (matcher.start()-matcher.end()), this.pane);
                        
                        /*
                        *Burda ozel olaraq bir fonksiyon cagrilacaq ve proqram qismen dayanacaq cunku o fonksiyonun geri dondurduyu string 
                        *deyeri geri yazilmaq uzre alinmalidir ve bunu uycun elave melumaty deye bir deyisenin yaradaraq ardindan fonksiyon ve fonksiyon 
                        *iceriyini yazmaq lazimdir.
                        */
						/*
                        break;
                    case "MODOF":
                    case "MODON":
                        pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));
                        Bildiris = Bildiris = !matcher.group().equals("MODOF");
                    default:
                        break;
                }
            }else{
                //styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), ACCODETANMIUYCUN, false);
                if(matcher.group().equals("MODOF") || matcher.group().equals("MODON")){
                    pane.setText(pane.getText().substring(0, matcher.start())+pane.getText().substring(matcher.end(), pane.getText().length()));
                    Bildiris = !matcher.group().equals("MODOF");
                }
            }
            
            
            
            /*
            if(Bildiris == true){
                if(matcher.group().equals("AC CODE")){
                    styledDocument.setCharacterAttributes(matcher.start(), matcher.end() - matcher.start(), ACCODETANMIUYCUN, false);
                    if(bayragdurumu == true){
                        bayragdurumu = false;

                        try{
                            //settext appended kimi 
                            pane.getDocument().insertString(pane.getText().subSequence(matcher.start(), matcher.end() - matcher.start()).length(), " V3.0 ", null);
                        }catch(BadLocationException e){

                        }
                    }else{
                        // bayragdurumu = true;
                    }
                    //IDE.ACOZELDAXILEDICI();
                }else if(matcher.group().equals("SAVE") || matcher.group().equals("SAXLA")){
                    //rmatcher.group("SAVA")
                    if(matcher.group().equals("SAVE") ){
                        pane.setText(pane.getText().substring(matcher.start(), matcher.end() - matcher.start()));
                    }else{
                        pane.setText(pane.getText().substring(matcher.start(), matcher.end() - matcher.start()));
                    }
                    IDE.FayilSaxla();

                } else if(matcher.group().equals("MODOF") || matcher.group().equals("MODON")){
                    Bildiris = !matcher.group().equals("MODOF");
                    

                }
                ///
            }else{
                if(matcher.group().equals("MODOF") || matcher.group().equals("MODON")){
                    Bildiris = !matcher.group().equals("MODOF");
                    pane.setText(pane.getText().substring(matcher.start(), matcher.end() - matcher.start()));

                    
                }
            }
            *//*
        }

    }
    //Deneme OLarq ELave edilen bir class ve bir nece fonksiyon yigini dir.
    public class Data {
        public void BK(){
            System.out.print("test0");
            try{
                Thread.sleep(4000);
            }
            catch(InterruptedException ex){
                Thread.currentThread().interrupt();
            }
            System.out.println("test1");
       }
    }
}
*/
