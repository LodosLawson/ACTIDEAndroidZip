package backend.KeyboardBack;
/*
import backend.OzelJSCroll;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.plaf.PanelUI;
import javax.swing.text.BadLocationException;
import javax.swing.text.Caret;

public class Keyboard {
    public KeyAdapter IDEKeyboard(JTextPane PANEL){
        return new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    try {PANEL.getDocument().insertString(PANEL.getCaretPosition(), "    ", null);}
                     catch (BadLocationException ex) {Logger.getLogger(OzelJSCroll.class.getName()).log(Level.SEVERE, null, ex);}
                }
                if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE){
                    try {PANEL.getDocument().remove(PANEL.getCaretPosition()-1, 1);} 
                    catch (BadLocationException ex) { Logger.getLogger(OzelJSCroll.class.getName()).log(Level.SEVERE, null, ex); }
                }
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    try{
                        PANEL.getDocument().insertString(PANEL.getCaretPosition(), "\n", null);
                    }catch(BadLocationException ex) { Logger.getLogger(OzelJSCroll.class.getName()).log(Level.SEVERE, null, ex); }
                }
                if(e.getKeyCode() == KeyEvent.VK_LEFT){
                    PANEL.setCaretPosition(PANEL.getCaretPosition()-1);
                    //insertString(PANEL.getCaretPosition(), "\n", null);
                }
                //Cursor Position
                if(e.getKeyCode() == KeyEvent.VK_RIGHT){
                    PANEL.setCaretPosition(PANEL.getCaretPosition()+1);
                    //insertString(PANEL.getCaretPosition(), "\n", null);
                }
                if(e.getKeyCode() == KeyEvent.VK_UP){
                   
                    //PANEL.getCaret().setDot(PANEL.getCaretPosition()+1));
                    //System.out.println(PANEL.getCaret().getMark());

                    //insertString(PANEL.getCaretPosition(), "\n", null);
                }
                if(e.getKeyCode() == KeyEvent.VK_DOWN){
                    if(PANEL.getHeight() != 0){
                        //PANEL.setCaretPosition(PANEL.getBaseline(3,PANEL.getCaretPosition()-1));
                        //insertString(PANEL.getCaretPosition(), "\n", null);
                    }
                   
                }
                e.consume();
            }
        };
    }
}
*/
