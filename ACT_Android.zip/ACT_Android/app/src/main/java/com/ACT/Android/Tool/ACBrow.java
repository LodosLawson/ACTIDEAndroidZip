package com.ACT.Android.Tool;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import com.ACT.Android.*;

public class ACBrow extends Activity {

		private WebView mWebView;
		private EditText mUrlEditText;
		private Button mGoButton, mTikTokButton;
		//WebView webView = findViewById(R.id.webView);
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.ipcam);

			mWebView = (WebView) findViewById(R.id.webview);
			mUrlEditText = (EditText) findViewById(R.id.url_edittext);
			mGoButton = (Button) findViewById(R.id.go_button);
			mTikTokButton = (Button) findViewById(R.id.TikTokButton);
			// WebView yapılandırması
			WebSettings webSettings = mWebView.getSettings();
			webSettings.setJavaScriptEnabled(true);
			webSettings.setDomStorageEnabled(true);
			webSettings.setSupportZoom(false);
			webSettings.setAllowFileAccessFromFileURLs(false);
			webSettings.setAllowUniversalAccessFromFileURLs(false);
			webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
			WebView webView = findViewById(R.id.webview);

			String htmlString = "<html><body><table border='1'><tr><th>Header 1</th><th>Header 2</th></tr><tr><td>Row 1, Column 1</td><td>Row 1, Column 2</td></tr><tr><td>Row 2, Column 1</td><td>Row 2, Column 2</td></tr></table></body></html>";
			
			webView.loadData(htmlString, "text/html", null);
			
			mWebView.setWebViewClient(new WebViewClient() {
					@Override
					public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
						view.loadUrl(request.getUrl().toString());
						return true;
					}
				});
			
			mTikTokButton.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
						mWebView.loadUrl("tiktok.com/@mehemmed_ac");
				}		
			});
			mGoButton.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						String url = mUrlEditText.getText().toString();
						if(url.contains("https://")||url.contains("http://")){
							mWebView.loadUrl(url);
						}else{
							mWebView.loadUrl("https://"+url+".com");
						}
					}
				});
			ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
				if (networkInfo != null && networkInfo.isConnected()) {
					webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
				} else {
					webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				}
			}
			
		}
		@Override
		public void onBackPressed() {
			WebView webView = findViewById(R.id.webview);
			if (webView.canGoBack()) {
				webView.goBack();
			} else {
				super.onBackPressed();
			}
		}
	}

