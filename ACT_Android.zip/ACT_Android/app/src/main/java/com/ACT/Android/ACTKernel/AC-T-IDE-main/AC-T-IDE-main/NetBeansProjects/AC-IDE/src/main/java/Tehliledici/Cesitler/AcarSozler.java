package Tehliledici.Cesitler;

import java.util.Scanner;

import Tehliledici.ACTehliledici;
import Tehliledici.Ayrici;
import Tehliledici.Tool.Deyisgen;
import Tehliledici.Elaveler;
import Tehliledici.Tool.Controller.Controller;
import Tehliledici.Tool.Fonksiyon;
import ac.acYazdir;

public class AcarSozler {
	
    //Ozel Nesneler
    public static acYazdir YAZDIRICI = new acYazdir();

    //PRIVATE OLAN HISE 
    private String DAXILI_ACARSOZ;
    
    //
    public static boolean icerik_flag = false;

    //Constructure olan hise
    public AcarSozler() {
		
    }	

    public static void acarsozlerdefault(){
        FONKSIYON_SAYAC = 1;
        FONKSIYONLAR = new Fonksiyon[1000];
        icerik_flag = false;
        YAZDIRICI.dafult();
        
        
    }
    //Constructure olan hise
	
    //PUBLIC STATIC OLAN HISE 

    //YAZDIR AS Icersinde Multi Fayil Yazdirimini Aktiv - Ve Deyaktif Etmek uycun Istifade Olunur
    public static boolean Fayil_Bildirim_Bayragi;
	
    //DEFAULT OLARAQ YAZILAN ACAR SOZLER
    public static String[] KEYWORD_AS = new String[] {"YAZDIR","PRINT","DIF","reqem","herif","int","string"};
    public static Fonksiyon[] FONKSIYONLAR = new Fonksiyon[1000];

    //OZEL OLARAK YAZILAN ACAR SOZ FONKSIYONLARI 
    
    //Int Values
    public static int FONKSIYON_SAYAC = 1;

    //3 DEF
    public static boolean AS_DIF(String Setir_ICERIKI, String Mod, boolean Alinan_Deger, Fonksiyon fonksi){
        //System.out.println("DIF SETIR>>"+Setir_ICERIKI);
        ///ON BILGI 
                //Bu kisimda ise fonksiyon yazilimini tanima ve onu kaydetme yer alinir DIF Keyword sayesinde buraya ulasila biliniyor ve bu sayede 
                //hafizada bir tane fonksiyon var oluyor burada fonksiyon deyisgenleri Fonksiyon Classi icersinde bir deyisgen tanima ArrayList kismina kaydedilir 
                //daha sonra ulasma ve kontrol daha kolay olur ve burada bir buyuk sorun sudurki 
                //SORUN ACIKLAMA SI ::::: Sorun sudurki Fonksiyon icinde tanimlanan deyisgenler fonkdiyon disinda cagrilamas ve bu fonksiynlar hem global hemde local olarak varlik gosderirler
                //Yani ki Fonksiyon icindeki deyisgenler yeni deyisgen classindan cagrilir ve bu deyisgenlerin default deyisgenlerle ve ustglobal deyisgenlerle bir alakasi olmaz, bu yapi tartisilir bir yapidir 
                //bu yapiyi farkli farkli bir kontrolerden gecirerek farkli frakli denemelerden ortaya en kolay ve en guvenli yontemi cikarmak gerekir
                
                ///ASAMA IKINCI 
                //Fonksiyon tanimi birden farkli oldugu icin burada bir kac tanim yer almakdadir ve bu tanimlar fonksiyon cagrimina tesir eder 
                //Tekli fonksiyon cagrimi sundan ibaretir fonksiyon herhangi bilgi almaz ve bir bilgi vermez 
                //Ikili Fonksiyon tanimi bundan ibaretir ki fonksiyon hem bir deger dondurur hemde birden fazla deger alir
                //Sol Fonksiyon tanimi bir deger dondururken baska bir deger qalmaz
                //Sag Fonksiyon tanimi birden fazla bilgi alir ve bir bilgi dondurmez
                //bu tanimlar sayesinde fonksiyonlar islemli hale gelir 
                


                //Burada DIF Tanimlayicidan yardim alarak bir fonksiton tanimi yapicaz ilk once bir fonksiton tanima ozeligi yaratmaliyiz
                /*
                * AC CODE LINE> DIF: 0<fonksiton_ismi>Deyisgen_isimi,deyisgen_ikinci_ismi{
                *
                *               } 
                * < default donen deger 
                */
                    

                //Elaveler.Yazdir("DIF <<<XETA>>> : 393989 :", "Consol");
            
                
                //System.out.println(FonksitonReturnValueDection);
                //System.out.println(FonksiyonEnteredValueDection);
                //System.out.println(Setir_ICERIKI);
        String MI = Setir_ICERIKI.substring(4).replaceAll("\\s", "");
        //if(Setir_ICERIKI.length() > 4){
           
        //}
        
        //System.out.println("l>"+MI+"<l\n\n");
        //System.out.println("l>>"+Setir_ICERIKI+"<<l\n\n");

        int Oturucu_Index = Elaveler.MetinAxtarici(MI, '=');
        int Sonu_Index = Elaveler.MetinAxtarici(MI, ';');
        
        int FonksitonReturnValueDection = -1;
        int FonksiyonEnteredValueDection = -1;

        if(icerik_flag == false){
            FonksitonReturnValueDection = Elaveler.MetinAxtarici(Setir_ICERIKI, '<');
            FonksiyonEnteredValueDection = Elaveler.MetinAxtarici(Setir_ICERIKI, '>');
        }

        int FonksiyonIcerikAliciBaslaniqc = Elaveler.MetinAxtarici(Setir_ICERIKI, '{');
        int FonksiyonIcerikAliciBitis = Elaveler.MetinAxtarici(Setir_ICERIKI, '}');
        
        int Fonksiyon_Parse = Elaveler.MetinAxtarici(Setir_ICERIKI, ':');


        //System.out.println(">>0"+index[0]+"\n>>1"+index[1]+"\nLine >>"+Setir_ICERIKI+"\nlINE Len >>"+Setir_ICERIKI.length());
        //System.out.println("<"+FonksitonReturnValueDection+"\n>"+FonksiyonEnteredValueDection+"\n{"+FonksiyonIcerikAliciBaslaniqc+"\n}"+FonksiyonIcerikAliciBitis);
        //System.out.println(Setir_ICERIKI);

        
        Scanner bolunen = new Scanner(Setir_ICERIKI);
        String Bolunen_Durumnu = bolunen.nextLine();

        if(ACTehliledici.MetinAxtarici(Bolunen_Durumnu, "\"") != -1){
            try{
                int[] index = ACTehliledici.MultiAxtarici(Bolunen_Durumnu, "\"", "DEF");

                int TUTUCU = index[1];
                String ICERIK_TUTUCU = Setir_ICERIKI.substring(index[1]);

                FonksitonReturnValueDection = Elaveler.MetinAxtarici(ICERIK_TUTUCU, '<');
                FonksiyonEnteredValueDection = Elaveler.MetinAxtarici(ICERIK_TUTUCU, '>');
                FonksiyonIcerikAliciBaslaniqc = Elaveler.MetinAxtarici(ICERIK_TUTUCU, '{');
                FonksiyonIcerikAliciBitis = Elaveler.MetinAxtarici(ICERIK_TUTUCU, '}');

                if(FonksitonReturnValueDection != -1){ FonksitonReturnValueDection += TUTUCU; }
                if(FonksiyonEnteredValueDection != -1){ FonksiyonEnteredValueDection += TUTUCU; }
                if(FonksiyonIcerikAliciBaslaniqc != -1){ FonksiyonIcerikAliciBaslaniqc += TUTUCU; }
                if(FonksiyonIcerikAliciBitis != -1){ FonksiyonIcerikAliciBitis += TUTUCU; }

            }catch(Exception e){
                e.printStackTrace();
            }

            //if(){

            //}            
        }else{
            FonksitonReturnValueDection = Elaveler.MetinAxtarici(Setir_ICERIKI, '<');
            FonksiyonEnteredValueDection = Elaveler.MetinAxtarici(Setir_ICERIKI, '>');
            FonksiyonIcerikAliciBaslaniqc = Elaveler.MetinAxtarici(Setir_ICERIKI, '{');
            FonksiyonIcerikAliciBitis = Elaveler.MetinAxtarici(Setir_ICERIKI, '}');
        }
        
        if(FonksitonReturnValueDection > FonksiyonIcerikAliciBaslaniqc || FonksiyonEnteredValueDection > FonksiyonIcerikAliciBaslaniqc){
            FonksitonReturnValueDection = -1;
            FonksiyonEnteredValueDection = -1;
        }
        if(Alinan_Deger){
            if(Oturucu_Index != -1 && Sonu_Index != -1){
                Ayrici.Controller = true;

                if(Mod.equals("Fonksiyon")){
                    //System.out.println("FONKISYON>>"+Setir_ICERIKI);
                    if(!Deyisgen.ACDeyisgenVarligYoxlayici(Setir_ICERIKI.substring(0, Oturucu_Index))){
                            
                        int SH_Index = Elaveler.MetinAxtarici(MI, "\"");
                        if(SH_Index != -1){
                            Deyisgen.ACDeyisgenTanimi("herif "+fonksi.getFONKSIYON_UID()+MI, "DEF");
                        }else{
                            if(Fonksiyon_Parse != -1){
                                Deyisgen.ACDeyisgenTanimi("reqem "+fonksi.getFONKSIYON_UID()+MI.substring(1), "DEF");
                            }
                            Deyisgen.ACDeyisgenTanimi("reqem "+fonksi.getFONKSIYON_UID()+MI.substring(0), "DEF");
                        }   
                    }else{
                        Elaveler.YazdirSpesial("<XETA> VAR OLAN DEYIGSEN TANIMI");
                    }
                }else{
                    if(!Deyisgen.ACDeyisgenVarligYoxlayici(Setir_ICERIKI.substring(0, Oturucu_Index))){
                            
                        int SH_Index = Elaveler.MetinAxtarici(MI, "\"");
                        if(SH_Index != -1){
                            Deyisgen.ACDeyisgenTanimi("herif "+MI, "DEF");
                        }else{
                            Deyisgen.ACDeyisgenTanimi("reqem "+MI, "DEF");
                        }   
                    }else{
                        Elaveler.YazdirSpesial("<XETA> VAR OLAN DEYIGSEN TANIMI");
                    }
                }
            }else {
                try{
                //System.out.println(Setir_ICERIKI+"< Birinci Deysmeyen Dondurucu>>"+FonksitonReturnValueDection);
                return Fonksiyon.FonksiyonTanimlayici(Setir_ICERIKI, Mod, Alinan_Deger, fonksi, Oturucu_Index, Sonu_Index,
                FonksitonReturnValueDection, FonksiyonEnteredValueDection, FonksiyonIcerikAliciBaslaniqc, FonksiyonIcerikAliciBitis, Fonksiyon_Parse);
                }catch(Exception e){
                    e.printStackTrace();
					Elaveler.YazdirSpesial(e);
                }
            }
        }else{        
            try{
            //System.out.println("Ikinici Deysmeyen Dondurucu>>"+FonksitonReturnValueDection);
            return Fonksiyon.FonksiyonTanimlayici(Setir_ICERIKI, Mod, Alinan_Deger, fonksi, Oturucu_Index, Sonu_Index,
            FonksitonReturnValueDection, FonksiyonEnteredValueDection, FonksiyonIcerikAliciBaslaniqc, FonksiyonIcerikAliciBitis, Fonksiyon_Parse);
        
            }catch(Exception e){
                e.printStackTrace();
				Elaveler.YazdirSpesial(e);
            }
        }
        
        return true;
    }
    
    //2 herif / string
    public static void AS_herif(String Setir_ICERIKI){
        Deyisgen.ACDeyisgenTanimi(Setir_ICERIKI, "DEF");
    }
    
    //1 reqem / int
    public static void AS_reqem(String Setir_ICERIKI){
        Deyisgen.ACDeyisgenTanimi(Setir_ICERIKI, "DEF");
    }
    
    //0 YAZDIR
    public static void AS_YAZDIR(String Setir_ICERIKI, String Mod, Fonksiyon fonksiyon) {
        Fayil_Bildirim_Bayragi = false;

        //int[] IcIndex;
        //Burada Bir Satir alinacaq ve o satirdan onemli kisimlar alinaraq bir verimi ve ya bir dosya verisimi 
        //deyisgeni ve ya bir baska obje mi kontroli yapilacaq 
        //burada ilk once Okunan AS In Dogru OLub olmadigi konrolu dur
        //ardindan ilk : bulunur daha sonra son daki : bulunun ve bunlarin ic kisimi kontrol edilir
        //System.out.println("\n\n ---- OZEL OLARAQ AS_YAZDIR FONKSIYONU ICERSINDEN KONTOL EDILMEKDEDIR ---- \n "+Satir_ICERIKI);
        //String[] BOLUNENLER = Satir_ICERIKI.split(":");	
        
        int[] index = ACTehliledici.MultiAxtarici(Setir_ICERIKI, ":","DEF");		
        int Ilk = index[0];	
        int Son = index[1];	
        //System.out.println("Ilk Baslanqic : "+Ilk+"\nSon Baslqnic : "+Son+"\nMelumat : "+Setir_ICERIKI+"\nBolunen ve alinan : "+Setir_ICERIKI.substring(--Ilk, Son));
        String ICERIK = Setir_ICERIKI.substring(--Ilk, Son);

        int Genel_Yoxlayici_Indeksi = ACTehliledici.MetinAxtarici(ICERIK, ',');	
        //int Fayil_Bildirimi_Indeksi = ACTehliledici.MetinAxtarici(ICERIK, '#');	
        int Melumat_Bildirim_Indeksi = ACTehliledici.MetinAxtarici(ICERIK, '\"');
        int Fonksiyon_Elave_Ediciler = ACTehliledici.MetinAxtarici(ICERIK, '<');
        if(Fonksiyon_Elave_Ediciler != -1){
            if(Genel_Yoxlayici_Indeksi != -1){
                
                
                int[] index_ic = ACTehliledici.MultiAxtarici(ICERIK, ":","DEF");		
                String Saf_Icerig = ICERIK.substring(index_ic[0], --index_ic[1]);
                
                String[] BOLUNENLER_UST = Saf_Icerig.split("<");
                
               /* for(int in = 0; in < BOLUNENLER_UST.length; in++ ){
                    int current_in = in;
                    current_in++;
                    Fonksiyon Fon = Fonksiyon.FonksiyonArama(BOLUNENLER_UST[in]);
                    for(int inx = 0; inx < Fon.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI(); inx++){
                        int Bolucu = ACTehliledici.MetinAxtarici(BOLUNENLER_UST[current_in], ',');
                        if(Bolucu != -1){
                            String[] IC_BOLUNENLER = BOLUNENLER_UST[current_in].split(",");
                            for(int inc = 0; inc < IC_BOLUNENLER.length; inc++){
                                Fonksiyon Ic_Fon = Fonksiyon.FonksiyonArama(IC_BOLUNENLER[inc]);
                                if(Ic_Fon != null){
                                    
                                }else{
                                    
                                }
                            }                            
                        }
                    }
                }
                */
                //while(true){
                    
                //}
                
                /*
                int[] index_ic = ACTehliledici.MultiAxtarici(ICERIK, ":","DEF");		
                String Saf_Icerig = ICERIK.substring(index_ic[0], --index_ic[1]);
                
                System.out.println("Paralanan>>>"+Saf_Icerig.substring(0, ACTehliledici.MetinAxtarici(Saf_Icerig, '<')));
                Fonksiyon Fon = Fonksiyon.FonksiyonArama(Saf_Icerig.substring(0, ACTehliledici.MetinAxtarici(Saf_Icerig, '<')));
                String af = Saf_Icerig.substring(1+ACTehliledici.MetinAxtarici(Saf_Icerig, '<'), Saf_Icerig.length());
                System.err.println(af);
                for(int i = 0; i < Fon.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI(); i++){
                    String QalanVeri = af;
                    String afd = af.substring(0, ACTehliledici.MetinAxtarici(af, '<'));
                    String op = af.substring(1+ACTehliledici.MetinAxtarici(af, '<'), af.length());
                    String[] Deyisgen = op.split(",");
                    System.out.println(""+op);
                    System.out.println("Fonksiyon DEYISGEN sAY "+i+" < "+afd);
                    
                    Fonksiyon Fon1 = Fonksiyon.FonksiyonArama(af.substring(0, ACTehliledici.MetinAxtarici(af, '<')));
                    for(int x = 0; x < Fon1.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI(); x++){
                        System.out.println("IKIf De "+x+" < "+Deyisgen[x]);
                        Deyisgen[x] = null;
                        
                    }
                    
                    
                }*/
                
                
                //String Dagitici = ICERIK;
                //System.out.println(">>>"+Dagitici+"<<<");
                // int[] index_ic = ACTehliledici.MultiAxtarici(ICERIK, ":","DEF");		
                
                // String BOLUNEN_DAGITICILAR[] = ICERIK.substring(index_ic[0], --index_ic[1]).split("<");
                // String BOLUNEN_DAGITICILAR_AYRICI[] = ACTehliledici.AyiriciYoxlayici(ICERIK);

                //String Saf_Icerig = ICERIK.substring(index_ic[0], index_ic[1]);
                
                //while(true){
                    //if(new Controller().TypeInputingStruct(Saf_Icerig.substring(0, ACTehliledici.MetinAxtarici(Saf_Icerig, '<')))){  
                    //}
                  //  Fonksiyon Fon = Fonksiyon.FonksiyonArama(Saf_Icerig.substring(0, ACTehliledici.MetinAxtarici(Saf_Icerig, '<')));
                    
                   // for(int i = 0; i < Fon.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI(); i++ ){
                   //     System.out.println("Deyisgen "+i);
                   // }
                            
               // }
                
                //for(String x : BOLUNEN_DAGITICILAR){
                //    System.out.println("<>>>"+x+"<<<>>");
                //}
                //for(int indexp = 0; indexp <= (BOLUNEN_DAGITICILAR.length/2); indexp++){
                //    System.out.println(BOLUNEN_DAGITICILAR[indexp]+"<"+BOLUNEN_DAGITICILAR[indexp+1]);
                //}
                
                /*
                for(String value : BOLUNEN_DAGITICILAR){
                    System.out.println(value);
                    
                    if(new Controller().TypeInputingStruct(value)){
                        String ValueType = new Controller().Type(value);
                        
                        if(ValueType.equals("Fonksiyon")){
                            Fonksiyon ValueFonksiyon = Fonksiyon.FonksiyonArama(value);
                            
                        }
                        
                        System.out.println(ValueType);
                    }else{
                        
                    }                    
                    //Burada value nin tipi bulunur ve daha sonra tipe gore davranis secilir eyer bir fonksiyon ise bu fonksiyonun girdi sayi alinir 
                    //daha sonra ki bolunenler ile control edilir ve hepsinin tipi kontrol edilir daha sonra 
                    //baska vir girdi almayan bir yapi yoksa bolunenler girdi olarak veriliyor 
                    
                    //verilen verinin girdisi varsa sayed girdi sayi alinir ve bu say sayesinde onde bulan ogeler alinir ve o ogeler de tek tek kontrol den gecer
                    //eger onlarda girdi yapisi yoksa sayed verilen girdi sayi ile eslesir diger verilerde girdi sayi varsa sayed onlarda tek tek fontrol edilerek alinir ve verilir
                    
                    //System.out.println(new Controller().Type(value));
                    //if(new Controller().Type(value)){
                      
                    //}
                }
                */
            }
        }
        try{
            //
            if(Genel_Yoxlayici_Indeksi != -1) {	
                //BURADA BIRDEN COX DAXIL ETMENIN AYRILARAQ TESDIQLENMESI EDILIR
                //System.out.println(ICERIK);
                String[] BOLUNENLER = null;
                
                if(Fonksiyon_Elave_Ediciler != -1){
                    if(Genel_Yoxlayici_Indeksi != -1){
                

                    int[] index_ic = ACTehliledici.MultiAxtarici(ICERIK, ":","DEF");		
                    String Saf_Icerig = ICERIK.substring(index_ic[0], --index_ic[1]);

                    BOLUNENLER = new String[]{Saf_Icerig};
                    
                    }
                }else{
                    BOLUNENLER = ACTehliledici.AyiriciYoxlayici(ICERIK);      
                }
              //
                for(int i = 0; i < BOLUNENLER.length; i++) {	
                    if(BOLUNENLER[i] != null){
                        //IcIndex = null;	
                        int Yoxlayici_1 = ACTehliledici.MetinAxtarici(BOLUNENLER[i], '\"');	
                        int Yoxlayici_2 = ACTehliledici.MetinAxtarici(BOLUNENLER[i], '#');	
                        //int Fayil_Ozel_Yoxlayici = ACTehliledici.MetinAxtarici(BOLUNENLER[i], ';');	
                        //System.out.println(" : "+BOLUNENLER[i]);	
                        if(Yoxlayici_1 != -1) {	
                            int[] IcIndex = ACTehliledici.MultiAxtarici(BOLUNENLER[i], "\"","DEF");	
                            int IcIlk = IcIndex[0];	
                            int IcSon = IcIndex[1];		

                            YAZDIRICI.YAZDIR((BOLUNENLER[i].substring(IcIlk, IcSon)));						
                        }else if(Yoxlayici_2 != -1 && Yoxlayici_1 == -1) {
                            //System.out.println("\n\n---TEST---\n\n");                
                            int Deyisdirici_Bidldirimi = ACTehliledici.MetinAxtarici(BOLUNENLER[i], '\'');					                 
                            if(Deyisdirici_Bidldirimi != -1) {
                                int[] IcIndex = ACTehliledici.MultiAxtarici(BOLUNENLER[i], "\'","DEF");
                                int IcIlk = IcIndex[0];
                                int IcSon = IcIndex[1];
                                String Deyisdiric = BOLUNENLER[i].substring(IcIlk, IcSon);
                                //System.out.println("sdsd"+Deyisdiric+BOLUNENLER[i].substring(++Yoxlayici_2, --IcIlk));
                                if(Fayil_Bildirim_Bayragi == false) {
                                    Fayil_Bildirim_Bayragi = true;
                                    if(Deyisdiric.equals("w")) {
                                        YAZDIRICI.YAZDIR(BOLUNENLER[i].substring(++Yoxlayici_2, --IcIlk), true, false);
										
									} else {
                                        //System.out.println("sdsd"+BOLUNENLER[i].substring(++Yoxlayici_2, --IcIlk));
                                        YAZDIRICI.YAZDIR(BOLUNENLER[i].substring(++Yoxlayici_2, --IcIlk), false, false);
										
									}
                                }else {
                                    Elaveler.YazdirSpesial("Bir Fayil Daxil OLunub Ikinci Fayil Daxil Edilmlesi IKI fayila Eyni ANda bir melumatin yazilmasi anlamina gelir ");
                                }
                            }else {	
                                if(Fayil_Bildirim_Bayragi == false) {
                                    Fayil_Bildirim_Bayragi = true;
                                    //System.out.println("sdsd"+BOLUNENLER[i].substring(++Yoxlayici_2));		
                                    YAZDIRICI.YAZDIR(BOLUNENLER[i].substring(++Yoxlayici_2), false, false);			
                                }else {			
                                    Elaveler.YazdirSpesial("Bir Fayil Daxil OLunub Ikinci Fayil Daxil Edilmlesi IKI fayila Eyni ANda bir melumatin yazilmasi anlamina gelir ");			
                                }			
                            }		
                        } else {		
                            //burada bir deyisgeni yoxlayaraq var olub olmadiqini tesbit etmek ve hemin deyisgeni oxuyaraq yazdir fonksiyonuna daxitl etmek gerekir 		
                            //Deyisgen test = new Deyisgen();		
                            //String Deyisgen = BOLUNENLER[i].replaceAll("\\s", "");		

                            if(Mod.equals("Fonksiyon")){
                                for (String string : BOLUNENLER) {
                                    if(string == null){
                                        break;
                                    }
                                }
                                String Fonksiyon_Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+(BOLUNENLER[i].replaceAll("\\s", "")));		
                                String Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(BOLUNENLER[i].replaceAll("\\s", ""));		
                                if(!Fonksiyon_Deysigen_Icerik.equals("") || !Deysigen_Icerik.equals("")) {		
                                    //System.out.println("\nDeyisgen Icerigi : "+Deysigen_Icerik);			
                                    //System.out.println("\nDeyisgen Adi : "+Fonksiyon_Deysigen_Icerik);	
                                    if(Deysigen_Icerik.equals("")){
                                        YAZDIRICI.YAZDIR(Fonksiyon_Deysigen_Icerik);			
                                    }
                                    if(Fonksiyon_Deysigen_Icerik.equals("")){
                                        YAZDIRICI.YAZDIR(Deysigen_Icerik);			
                                    }
                                }else {		
                                    fonksiyon = Tehliledici.ACTehliledici.ACYazimTehliledici(BOLUNENLER[i].replaceAll("\\s",""), "Fonksiyon");
                                    
                                    //SIMDILIK BURAYI ASKIYA ALIYORUZ GEREKIRSE GERI DONUSDURME OLUCAK

                                    if(fonksiyon != null){
                                        if(fonksiyon.getGERI_DONDURUCU_DURUMU()){
                                            String Geri_Dondurlen_Deyisgen_Icerigi = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+fonksiyon.getFONKISYON_GERI_DONDURULEN());
                                            if(!Geri_Dondurlen_Deyisgen_Icerigi.equals("")){
                                                YAZDIRICI.YAZDIR(Geri_Dondurlen_Deyisgen_Icerigi);
                                            }else {
                                                String Fonksiyon_Dondurucu_Icerigi = fonksiyon.getFONKISYON_GERI_DONDURULEN();

                                                if(ACTehliledici.MetinAxtarici(Fonksiyon_Dondurucu_Icerigi, "\"") != -1){

                                                    int[] IcIndex = ACTehliledici.MultiAxtarici(Fonksiyon_Dondurucu_Icerigi, "\"","DEF");	
                                                    int IcIlk = IcIndex[0];	
                                                    int IcSon = IcIndex[1];		

                                                    //System.out.println(">>>?"+s.subSequence(IcIlk, IcSon));
                                                    YAZDIRICI.YAZDIR(Fonksiyon_Dondurucu_Icerigi.substring(IcIlk, IcSon));
                                                }else{
                                                    YAZDIRICI.YAZDIR(Fonksiyon_Dondurucu_Icerigi);
                                                }
                                            }
                                        }
                                    }
                                    
                                    //System.out.println("null"+Tehliledici.ACT.ustglobalalici(BOLUNENLER[i]));			
                                    //System.out.println("BU BIR DEYSGENDIR : "+BOLUNENLER[i]);			
                                }
                            }else{
                                String Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(BOLUNENLER[i].replaceAll("\\s", ""));		
                                String SafBilinmeyenObje = ICERIK.replaceAll("\\s", "").substring(0, ICERIK.replaceAll("\\s", "").length()-1);
                                Elaveler.YazdirSpesial("Saf Bilinmeyen :> "+SafBilinmeyenObje);
								if(!Deysigen_Icerik.equals("")) {		
                                    //System.out.println("\nDeyisgen Icerigi : "+Deysigen_Icerik);			
                                    //System.out.println("\nDeyisgen Adi : "+Deyisgen);			
                                    YAZDIRICI.YAZDIR(Deysigen_Icerik);			
                                }else {		

                                    int DeyisgenDaxilEdici = ACTehliledici.MetinAxtarici(BOLUNENLER[i], '<');	

                                    if(DeyisgenDaxilEdici != -1){
                                        
                                        String TamfonksiyonYapisi = "";
                                        //+fonksiyon.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI());
                                        Fonksiyon tapilanFonksiyon = Fonksiyon.FonksiyonArama(BOLUNENLER[i].substring(0, DeyisgenDaxilEdici).replaceAll("\\s", ""));
                                        if(tapilanFonksiyon != null){
                                            for(int deyisgensayi = 0; deyisgensayi < tapilanFonksiyon.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI(); deyisgensayi++){
                                                TamfonksiyonYapisi += BOLUNENLER[i]; //","
                                                i++;
                                            }
                                        }else{ break; }
                                        i--;
                                        fonksiyon = Tehliledici.ACTehliledici.ACYazimTehliledici(TamfonksiyonYapisi.substring(0, TamfonksiyonYapisi.length()).replaceAll("\\s", ""), "Fonksiyon");
                                        if(fonksiyon != null){
                                            if(fonksiyon.getGERI_DONDURUCU_DURUMU()){
                                                String Geri_Dondurlen_Deyisgen_Icerigi = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+fonksiyon.getFONKISYON_GERI_DONDURULEN());
                                                if(!Geri_Dondurlen_Deyisgen_Icerigi.equals("")){
                                                    YAZDIRICI.YAZDIR(Geri_Dondurlen_Deyisgen_Icerigi);
                                                }else {
                                                    String Fonksiyon_Dondurucu_Icerigi = fonksiyon.getFONKISYON_GERI_DONDURULEN();
                                                    //System.out.println("DONDURLEN>>> "+Fonksiyon_Dondurucu_Icerigi);
                                                    if(ACTehliledici.MetinAxtarici(Fonksiyon_Dondurucu_Icerigi, "\"") != -1){
    
                                                        int[] IcIndex = ACTehliledici.MultiAxtarici(Fonksiyon_Dondurucu_Icerigi, "\"","DEF");	
                                                        int IcIlk = IcIndex[0];	
                                                        int IcSon = IcIndex[1];		
    
                                                        //System.out.println(">>>?"+s.subSequence(IcIlk, IcSon));
                                                        YAZDIRICI.YAZDIR(Fonksiyon_Dondurucu_Icerigi.substring(IcIlk, IcSon));
                                                    }else{
                                                        YAZDIRICI.YAZDIR(Fonksiyon_Dondurucu_Icerigi);
                                                    }
                                                }
                                            }
                                        }
                                    }else{
                                        Tehliledici.ACTehliledici.ACYazimTehliledici(BOLUNENLER[i].replaceAll("\\s",""), "");
                                        //System.out.println("null"+Tehliledici.ACT.ustglobalalici(BOLUNENLER[i]));			
                                        //System.out.println("BU BIR DEYSGENDIR : "+BOLUNENLER[i]);		
                                    }	
                                }
                            }		
                        }
                    }		
                }                
            }else if(Melumat_Bildirim_Indeksi != -1 && Melumat_Bildirim_Indeksi < Fonksiyon_Elave_Ediciler || Fonksiyon_Elave_Ediciler == -1) {	
                int[] Ic_Index = ACTehliledici.MultiAxtarici(ICERIK, "\"","USTGLOBALOZEL");
                int[] i = ACTehliledici.MultiAxtarici(ICERIK, ":","DEF");	
                int Ic_Ilk = Ic_Index[0];	
                int Ic_Son = Ic_Index[1];		
				Elaveler.YazdirSpesial(ICERIK);
                Elaveler.YazdirSpesial(Melumat_Bildirim_Indeksi);
				Elaveler.YazdirSpesial(Melumat_Bildirim_Indeksi);
				Elaveler.YazdirSpesial(Fonksiyon_Elave_Ediciler);
				Elaveler.YazdirSpesial(Fonksiyon_Elave_Ediciler);
				Elaveler.YazdirSpesial(Ic_Ilk+"<x\n"+Ic_Son+"<xs\n");
				Fonksiyon.getFonksiyonStatus();
                if(1+Ic_Son != i[1]){ 
					Deyisgen.ACDeyisgenlerStatus();
                    //YAZDIRICI.YAZDIR("<<<XETA-ERROR>>  M333 Function Dir>>"+ICERIK.charAt(Ic_Son)+"<< "+ICERIK);
               		
					//ANDROID GELISTIRILMESI ZAMANI ONARILAN VE GELISTIRILEN KISIM
					
					String Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1));	
					String Fonksiyon_Deysigen_Icerik = "";
					if(Mod.equals("Fonksiyon")){
						Fonksiyon_Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1));

                        //BURADA ILK ONCE DEYISKENMI OLDUGUNU KONTROL EDER DAHA SONRA FONKSIYONU ARAR 
                        if(!Deysigen_Icerik.equals("") || !Fonksiyon_Deysigen_Icerik.equals("")){

                            if(Fonksiyon_Deysigen_Icerik.equals("")){
                                YAZDIRICI.YAZDIR(Deysigen_Icerik);
                            }
                            if(Deysigen_Icerik.equals("")){
                                YAZDIRICI.YAZDIR(Fonksiyon_Deysigen_Icerik);
                            }
					}else{
					if(!Deysigen_Icerik.equals("")){
						YAZDIRICI.YAZDIR(Deysigen_Icerik);
					}else{
						String SafBilinmeyenObje = ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1);
                      	boolean X = Fonksiyon.FonksiyonVarlikYoxlayici(SafBilinmeyenObje);
						
						//Fonksiyon 
						fonksiyon = Tehliledici.ACTehliledici.ACYazimTehliledici(SafBilinmeyenObje.replaceAll("\\s", ""), "Fonksiyon");
						if(fonksiyon != null){
							if(fonksiyon.getGERI_DONDURUCU_DURUMU()){
								String Geri_Dondurlen_Deyisgen_Icerigi = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+fonksiyon.getFONKISYON_GERI_DONDURULEN());
								if(!Geri_Dondurlen_Deyisgen_Icerigi.equals("")){
									YAZDIRICI.YAZDIR(Geri_Dondurlen_Deyisgen_Icerigi);
								}else {
									String Fonksiyon_Dondurucu_Icerigi = fonksiyon.getFONKISYON_GERI_DONDURULEN();
									//System.out.println("DONDURLEN>>> "+Fonksiyon_Dondurucu_Icerigi);
									if(ACTehliledici.MetinAxtarici(Fonksiyon_Dondurucu_Icerigi, "\"") != -1){

										int[] IcIndex = ACTehliledici.MultiAxtarici(Fonksiyon_Dondurucu_Icerigi, "\"","DEF");	
										int IcIlk = IcIndex[0];	
										int IcSon = IcIndex[1];		

										//System.out.println(">>>?"+s.subSequence(IcIlk, IcSon));
										YAZDIRICI.YAZDIR(Fonksiyon_Dondurucu_Icerigi.substring(IcIlk, IcSon));
									}else{
										YAZDIRICI.YAZDIR(Fonksiyon_Dondurucu_Icerigi);
									}
								}
							}
						}
						}
					//////////
						}
					}
					
					//YENILENEN EKLENEN KISIM BITIS NOKTASI
				}else{	
                    YAZDIRICI.YAZDIR(ICERIK.substring(Ic_Ilk, Ic_Son-1));             
                }
                            
            } else {	
                if(Fayil_Bildirim_Bayragi == true) {
                    Elaveler.YazdirSpesial("XETA AcarSozleri YAZDIR <<< FAYIL BOS YAZDIR XETASI <<< MELUMAT DAXIL EDIN "+ICERIK); 
                } else{ /*System.out.println("BU BIR DEYISEGDNIR "+ICERIK); */ 
                    //String Deyisgen = ICERIK.replaceAll("\\s", "");
                    String Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1));	
                    /*
                    try{
                        //System.out.println(ICERIK.replaceAll("\\s", "").substring(0, ICERIK.replaceAll("\\s", "").length()-1));	
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                    */
                    if(!Deysigen_Icerik.equals("")) {		
                        //System.out.println("\nDeyisgen Icerigi : "+Deysigen_Icerik);			
                        //System.out.println("\nDeyisgen Adi : "+Deyisgen);			
                        YAZDIRICI.YAZDIR(Deysigen_Icerik);			
                    }else {		
                        String SafBilinmeyenObje = ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1);
                        String Deyisgen_Icerigi = Deyisgen.ACDeyisgenDondurucu(ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1));
                        
                        String Fonksiyon_Deysigen_Icerik = "";
                        if(Mod.equals("Fonksiyon")){
                            Fonksiyon_Deysigen_Icerik = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+ICERIK.replaceAll("\\s", "").substring(1, ICERIK.replaceAll("\\s", "").length()-1));
                        }

                        //BURADA ILK ONCE DEYISKENMI OLDUGUNU KONTROL EDER DAHA SONRA FONKSIYONU ARAR 
                        if(!Deyisgen_Icerigi.equals("") || !Fonksiyon_Deysigen_Icerik.equals("")){
                            
                            if(Fonksiyon_Deysigen_Icerik.equals("")){
                                YAZDIRICI.YAZDIR(Deysigen_Icerik);
                            }
                            if(Deysigen_Icerik.equals("")){
                                YAZDIRICI.YAZDIR(Fonksiyon_Deysigen_Icerik);
                            }
                        }else{
                            fonksiyon = Tehliledici.ACTehliledici.ACYazimTehliledici(SafBilinmeyenObje, "Fonksiyon");
                            if(fonksiyon != null){
                                if(fonksiyon.getGERI_DONDURUCU_DURUMU()){
                                    String DONEN = "";
                                    String Geri_Dondurulen_Deyisgen_Icerigi = Deyisgen.ACDeyisgenDondurucu(fonksiyon.getFONKSIYON_UID()+fonksiyon.getFONKISYON_GERI_DONDURULEN());
                                    if(!Geri_Dondurulen_Deyisgen_Icerigi.equals("")){
                                        YAZDIRICI.YAZDIR(Geri_Dondurulen_Deyisgen_Icerigi);
                                    }else{
                                        String s = fonksiyon.getFONKISYON_GERI_DONDURULEN();
                                                                                
                                        if(ACTehliledici.MetinAxtarici(s, "\"") != -1){

                                            
                                            int[] IcIndex = ACTehliledici.MultiAxtarici(s, "\"","DEF");	
                                            int IcIlk = IcIndex[0];	
                                            int IcSon = IcIndex[1];		

                                            //System.out.println(">>>?"+s.subSequence(IcIlk, IcSon));
                                            YAZDIRICI.YAZDIR(s.substring(IcIlk, IcSon));
                                            
                                        }else{
                                            YAZDIRICI.YAZDIR(s);

                                        }
                                    }
                                }else {
                                    //System.out.println(fonksiyon.getFONKISYON_GERI_DONDURULEN());

                                }
                            }
                            
                        }
                        //System.out.println("null"+Tehliledici.ACT.ustglobalalici(BOLUNENLER[i]));			
                        //System.out.println("BU BIR DEYSGENDIR : "+BOLUNENLER[i]);			
                    }		
                }	
                //BURADA DEYIGENIN TIPINI VE BAZI AYARLAR YAPILARAK OKUMA ISLEMI YAPILARAK GERI DONEREK OKUNANIN YAZILMA ISLEMI YAPILIR 	
            }		
            YAZDIRICI.Yazdir();	
            YAZDIRICI.dafult();

        }catch(Exception e){
            e.printStackTrace();
		
        }
    }
}
