package backend.resLoader;
/*
import static GUI.IDE.IDE.isUnix;
import static GUI.IDE.IDE.isWindows;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author Acer8
 */
/*
public class ResLoader {
    
    String sla = "\\";
    
    public ResLoader(){
        if (isWindows()) {
            sla = "\\";
        } else if (isUnix()) {
            sla = "/";
        }
    }
    //ICON LOAD
        //Compiler Button
        public Icon CompilerButton = new ImageIcon("res"+sla+"Icons"+sla+"Compiler_Button"+sla+"CompilerButton.png");
        public Icon CompilerButtonOn = new ImageIcon("res"+sla+"Icons"+sla+"Compiler_Button"+sla+"CompilerButtonOn.png");

        //Terminal Button
        public Icon TerimnalButton = new ImageIcon("res"+sla+"Icons"+sla+"Terminal_Button"+sla+"TerminalButton.png");
        public Icon TerimnalButtonOn = new ImageIcon("res"+sla+"Icons"+sla+"Terminal_Button"+sla+"TerminalButtonOn.png");
        
        //Terminal Clear Button
        public Icon TerminalClearButton = new ImageIcon("res"+sla+"Icons"+sla+"Terminal_Button"+sla+"Terminal_Clear_Button"+sla+"ClearButton.png");
        public Icon TerminalClearButtonOn = new ImageIcon("res"+sla+"Icons"+sla+"Terminal_Button"+sla+"Terminal_Clear_Button"+sla+"ClearButtonOn.png");
        
        //HelpKomekci Button
        public Icon HelpKomekciButton = new ImageIcon("res"+sla+"Icons"+sla+"Help_Button"+sla+"HelpButton_x32.png");
        
        //Close Button
        public Icon CloseButton = new ImageIcon("res"+sla+"Icons"+sla+"Close_Button"+sla+"CloseButton.png");
        
        //Back Button
        public Icon BackButton = new ImageIcon("res"+sla+"Icons"+sla+"Close_Button"+sla+"BackButton.png");

        
        public ImageIcon AcLogo =  new ImageIcon("res"+sla+"Icons"+sla+"AC_Logo"+sla+"AC Logo 4x transparant x225.PNG");  
}
*/
