import android.app.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import com.ACT.Android.*;


//import androidx.appcompat.app.AppCompatActivity;

public class mlkopq extends Activity {


    private TextView mLineNumberView;
    private ScrollView mScrollView;
    private EditText mEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mlkop);
}}
