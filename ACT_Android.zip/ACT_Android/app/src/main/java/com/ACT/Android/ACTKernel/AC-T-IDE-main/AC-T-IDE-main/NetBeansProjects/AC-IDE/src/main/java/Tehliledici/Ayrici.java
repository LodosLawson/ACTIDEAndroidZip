package Tehliledici;

import java.util.Scanner;

import ACTehlilediciBaglantilari.AcarSozler;
import Tehliledici.Tool.Fonksiyon;
import TestPack.*;

public class Ayrici extends Thread {
	
    String Melumat;
    
    public static boolean durum;
    public static boolean Controller = false;
    public static boolean Ozel_Durum;

    @Override
    public void run() { 	
        Elaveler.Yazdir("salasma");	
        Elaveler.Yazdir(Melumat);        
    }
    public Ayrici(){
    }
    //kontrol edilior eyer ac kod varsa o calisdiriliyor yksa sayet 
    //direk # code calisdirilacak
    
    public String MelumatTanimAyrici(String Melumat, String Mod, Fonksiyon fonksiyon){
        this.Melumat = Melumat;
        
        boolean Gelend_Deger = true;	
        boolean Ozel_Durum;
        
        int Tapilan_deger = 0;	

        String Setir = "";	
        String Setir_Plus = "";
        
        //ON OXUYUCU UCUN TANIMLANAN DEYISGENLER
        String Setir_on = "";
        String Setir_on_Plus = "";

        Scanner oxuyucu_on = new Scanner(Melumat);

        try{
            while(oxuyucu_on.hasNext()){
                Ozel_Durum = true;
                
                Setir = oxuyucu_on.nextLine();//.replaceAll("\\s", "");
                if(!Setir.replaceAll("\\s", "").equals("")){
					
                    try {			
                        if(Gelend_Deger == false){

                            Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir_Plus+="\n"+Setir, Melumat, Gelend_Deger, Mod, fonksiyon, true);
                            if(Gelend_Deger == true){
                                //ACTehliledici.ACYazimTehliledici(Setir, "Fonksiyon");
                                Setir_Plus = "";
                                //Tehliledici.Cesitler.AcarSozler.icerik_flag = false;
                            }else{
                                //Setir_Plus += "\n"+Setir;
                                Ozel_Durum = false;
                            }
                        }else{
                            Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir, Melumat, Gelend_Deger, Mod, fonksiyon, false);	
                            if(Gelend_Deger == true){
                                //ACTehliledici.ACYazimTehliledici(Setir, "Fonksiyon");                            
                                Setir_Plus = "";
								if(Mod.equals("")){
									Elaveler.YazdirSpesial("***>"+Mod+Setir);
									MathStructure.MegaMath(Setir);	
								}
                                //Tehliledici.Cesitler.AcarSozler.icerik_flag = false;

                                //Tapilan_deger = ACTehliledici.MetinAxtarici(Setir, '#');
                                //int Tapilan_diger_deyer = ACTehliledici.MetinAxtarici(Setir, ';');

                                //if(Tapilan_deger != -1 && Tapilan_diger_deyer != -1) {
                                        //index;			
                                        //boolean Gleen_Test = 			
                                  //  if(false == ACTehliledici.Isled((Setir))) {			
                                        //Elaveler.Yazdir("0");                   
                                    //}else {
                                        //Elaveler.Yazdir("1");
                                    //}
                                //}
                                
                            }else{
                                Setir_Plus += "\n"+Setir;
                                Ozel_Durum = false;

                            }
                        }
                    }catch(Exception e) {	
                        e.printStackTrace();
                        System.out.println("SONSUZ DONGU");
						Elaveler.YazdirSpesial("SONSUZ DONGU AYİRİCİ "+e);
                    }
                }
                //Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir_Plus, Melumat, false, Mod, fonksiyon);

                
                if(Ozel_Durum){
                    Setir_on_Plus += "\n"+Setir; 
                    //Ozel_Durum = true;
                }
                
            }
        }catch(Exception e){
            e.printStackTrace();
			Elaveler.YazdirSpesial("MelumatTanimAyirici XETA >>"+e);
        }
                //System.out.println("+>>+>"+Setir_on_Plus);

        return Setir_on_Plus;
    }
    public boolean MelumatAlici(String Melumat, String Mod, Fonksiyon fonksiyon) {
        this.Melumat = Melumat;
        
        boolean Gelend_Deger = true;	
        
        int Tapilan_deger = 0;	

        String Setir = "";	
        String Setir_Plus = "";
        
        //ON OXUYUCU UCUN TANIMLANAN DEYISGENLER
        String Setir_on = "";
        String Setir_on_Plus = "";

        Scanner oxuyucu_on = new Scanner(Melumat);

        try{
            while(oxuyucu_on.hasNext()){
                Setir = oxuyucu_on.nextLine();//.replaceAll("\\s", "");
                
               // new Tehliledici.Tool.ArithmeticLogic().ALU(Setir);
              
				
                try {			
                    if(Gelend_Deger == false){
                        Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir_Plus, Melumat, false, Mod, fonksiyon);
                        if(Gelend_Deger == true){
                            ACTehliledici.ACYazimTehliledici(Setir, "Fonksiyon");
                            Setir_Plus = "";
                            Tehliledici.Cesitler.AcarSozler.icerik_flag = false;
                        }else{
                            Setir_Plus += "\n"+Setir;
                        }
                    }else{
                        Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir, Melumat, true, Mod, fonksiyon);	
                        if(Gelend_Deger == true){
                            ACTehliledici.ACYazimTehliledici(Setir, "Fonksiyon");
                            Setir_Plus = "";
                            Tehliledici.Cesitler.AcarSozler.icerik_flag = false;

                            Tapilan_deger = ACTehliledici.MetinAxtarici(Setir, '#');
                            int Tapilan_diger_deyer = ACTehliledici.MetinAxtarici(Setir, ';');
            					
                            if(Tapilan_deger != -1 && Tapilan_diger_deyer != -1) {
                                    //index;			
                                    //boolean Gleen_Test = 			
                                if(false == ACTehliledici.Isled((Setir))) {			
                                    //Elaveler.Yazdir("0");                   
                                }else {
                                    //Elaveler.Yazdir("1");
                                }
                            }
                        }else{
                            Setir_Plus += "\n"+Setir;
                        }
                    }
                }catch(Exception e) {	
                    e.printStackTrace();
                    System.out.println("SONSUZ DONGU");
					Elaveler.YazdirSpesial("SONSUZ DONGU AYİRİCİ"+e);
                }
                //Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir_Plus, Melumat, false, Mod, fonksiyon);

                
                //if(){

                //}
                
            }
        }catch(Exception e){
            e.printStackTrace();
			Elaveler.YazdirSpesial("Xeta Ayirici >> 2 Algo"+e);
        }
       
        /*
        try {
            //ilk olarak satir satir alinarak ve indekselenerek            
            //ilk mi ve ya ilkten son mu oldugu kontrol ediliyor ve daha snra 		
            //# lan kisim alinarak ikinci fonksiyona veriliyr ve ondan gelen deger yani		                           
            //hata yok degeri kontrol edilerek //3 kod clalisdiriliyor 		

            while(oxuyucu_on.hasNext()) {
                Setir_on = oxuyucu_on.nextLine().replaceAll("\\s", "");
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        *//*
        Scanner oxuyucu = new Scanner(Melumat);	          
        try {	
            while(oxuyucu.hasNext()) {

                Setir = oxuyucu.nextLine().replaceAll("\\s", "");
                    
                try {			
                    if(Gelend_Deger == false){
                        Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir_Plus, Melumat, false, Mod, fonksiyon);
                        if(Gelend_Deger == true){
                            ACTehliledici.ACYazimTehliledici(Setir, "Fonksiyon");
                            Setir_Plus = "";
                            Tehliledici.Cesitler.AcarSozler.icerik_flag = false;
                        }else{
                            Setir_Plus += "\n"+Setir;
                        }
                    }else{
                        Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir, Melumat, true, Mod, fonksiyon);	
                        if(Gelend_Deger == true){
                            ACTehliledici.ACYazimTehliledici(Setir, "Fonksiyon");
                            Setir_Plus = "";
                            Tehliledici.Cesitler.AcarSozler.icerik_flag = false;

                            Tapilan_deger = ACTehliledici.MetinAxtarici(Setir, '#');
                            int Tapilan_diger_deyer = ACTehliledici.MetinAxtarici(Setir, ';');
            					
                            if(Tapilan_deger != -1 && Tapilan_diger_deyer != -1) {
                                    //index;			
                                    //boolean Gleen_Test = 			
                                if(false == ACTehliledici.Isled((Setir))) {			
                                    //Elaveler.Yazdir("0");                   
                                }else {
                                    //Elaveler.Yazdir("1");
                                }
                            }
                        }else{
                            Setir_Plus += "\n"+Setir;
                        }
                    }
                }catch(Exception e) {	
                    e.printStackTrace();
                    System.out.println("SONSUZ DONGU");
                }
                    /*
                    Setir = oxuyucu.nextLine();		
                    Tapilan_deger = ACTehliledici.MetinAxtarici(Setir, '#');
                    int Tapilan_diger_deyer = ACTehliledici.MetinAxtarici(Setir, ';');

                    //if(index >= 2){					
                    if(Tapilan_deger != -1 && Tapilan_diger_deyer != -1) {
                        //index;			
                        //boolean Gleen_Test = 			
                        if(false == ACTehliledici.Isled((Setir))) {			
                            //Elaveler.Yazdir("0");                   
                        }else {
                            //Elaveler.Yazdir("1");
                        }
                    }else {
                        //BUaraya AC devam Fonksiyonunu Cagirmali			
                        try {			
                            if(Gelend_Deger == false){
                                Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir_Plus, Melumat, false);
                                if(Gelend_Deger == true){
                                    ACTehliledici.ACYazimTehliledici(Setir);
                                    Setir_Plus = "";
                                }else{
                                    Setir_Plus += "\n"+Setir;
                                }
                            }else{
                                Gelend_Deger = ACTehliledici.ACYazimTehliledici(Setir, Melumat, true);	
                                if(Gelend_Deger == true){
                                    ACTehliledici.ACYazimTehliledici(Setir);
                                    Setir_Plus = "";
                                }else{
                                    Setir_Plus += "\n"+Setir;
                                }
                            }
                        }catch(Exception e) {	
                            System.out.println("SONSUZ DONGU");
                        }
                    }
                    
                    //}
            }
        } catch(Exception e) {	         
            System.out.println("SONSUZ DONGU");
        }	 */       	
        return Gelend_Deger;	
    }
    public static void TestFonksiyon() {
        //Burada AC Kod Oxuyucu Ve diger ACT Cagiricilari Var	
    }
}
