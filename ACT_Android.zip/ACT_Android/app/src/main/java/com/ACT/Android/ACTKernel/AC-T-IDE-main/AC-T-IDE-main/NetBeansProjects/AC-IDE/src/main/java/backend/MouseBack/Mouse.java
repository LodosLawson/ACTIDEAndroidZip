package backend.MouseBack;
/*
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

import GUI.IDE.IDE;

/**
 *
 * @author Acer8
 */
 /*
public class Mouse {
    
    public MouseAdapter TerimnalClearButtonEvent(String MOD, JButton OBJ){
        return new MouseAdapter() {
            //@Override
            @Override
            public void mouseEntered(MouseEvent e) {
                if(MOD.equals("TerminalClearButton")){
                    OBJ.setIcon(IDE.resLoader.TerminalClearButtonOn);
                }
            }
        
            //@Override
            @Override
            public void mouseExited(MouseEvent e) {
                if(MOD.equals("TerminalClearButton")){
                   OBJ.setIcon(IDE.resLoader.TerminalClearButton);
                }
            }
        };
    }

    public MouseAdapter TerimnalButtonEvent(String MOD, JButton OBJ){
        return new MouseAdapter() {
            //@Override
            @Override
            public void mouseEntered(MouseEvent e) {
                if(MOD.equals("TerminalButton")){
                    OBJ.setIcon(IDE.resLoader.TerimnalButtonOn);
                }
            }
        
            //@Override
            @Override
            public void mouseExited(MouseEvent e) {
                if(MOD.equals("TerminalButton")){
                   OBJ.setIcon(IDE.resLoader.TerimnalButton);
                }
            }
        };
    }

    public MouseAdapter CompilerButtonEvent(String MOD, JButton OBJ){
        return new MouseAdapter() {
            //@Override
            @Override
            public void mouseEntered(MouseEvent e) {
                if(MOD.equals("CompilerButton")){
                    OBJ.setIcon(IDE.resLoader.CompilerButtonOn);
                }
            }
        
            //@Override
            @Override
            public void mouseExited(MouseEvent e) {
                if(MOD.equals("CompilerButton")){
                   OBJ.setIcon(IDE.resLoader.CompilerButton);
                }
            }
        };
    }
}
*/
