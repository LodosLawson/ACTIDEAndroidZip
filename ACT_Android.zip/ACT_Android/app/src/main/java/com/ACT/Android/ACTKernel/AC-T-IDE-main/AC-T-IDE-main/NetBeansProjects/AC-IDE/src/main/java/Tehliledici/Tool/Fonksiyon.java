package Tehliledici.Tool;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import Tehliledici.ACT;
import Tehliledici.ACTehliledici;
import Tehliledici.Cesitler.AcarSozler;
import Tehliledici.Elaveler;

public class Fonksiyon {
    
    //String Values
    private String FONKSIYON_ISMI = "";
    private String FONKISYON_GERI_DONDURULEN = "";
    private String FONKSIYON_ICERIGI = "";
    
    //ArrayList Values
    private ArrayList<String> FONKSIYON_ICERIG_DEYIGSENLERI = new ArrayList<String>();
    private ArrayList<FonksiyonDeyisgenleri> FONKSIYON_DEYISGENLERI = new ArrayList<FonksiyonDeyisgenleri>();
    
    //Int values
    private int Fonksiyon_ID = 0;
    private int FONKSIYON_ICERIG_DEYISGENLERININ_SAYI = 0;
    private int FONKSIYON_UID = 0;

    private boolean GERI_DONDURUCU_DURUMU = false;
    
    public Fonksiyon(String FONKSIYON_ISMI, String FONKISYON_GERI_DONDURULEN, String FONKSIYON_ICERIGI, ArrayList FONKSIYON_ICERIG_DEYIGSENLERI, 
    ArrayList FONKSIYON_DEYISGENLERI, int FONKSIYON_ICERIG_DEYISGENLERININ_SAYI, int Fonksiyon_ID, int FONKSIYON_UID) {
        this.Fonksiyon_ID = Fonksiyon_ID; 
        this.FONKSIYON_ISMI = FONKSIYON_ISMI;
        this.FONKISYON_GERI_DONDURULEN = FONKISYON_GERI_DONDURULEN;
        this.FONKSIYON_ICERIGI = FONKSIYON_ICERIGI;
        this.FONKSIYON_ICERIG_DEYIGSENLERI = FONKSIYON_ICERIG_DEYIGSENLERI;
        this.FONKSIYON_ICERIG_DEYISGENLERININ_SAYI = FONKSIYON_ICERIG_DEYISGENLERININ_SAYI;
        this.FONKSIYON_DEYISGENLERI = FONKSIYON_DEYISGENLERI;
        this.FONKSIYON_UID = FONKSIYON_UID;
        //System.out.println("\n\n\n\n\n"+this.FONKSIYON_UID);
    }
    
    public static void getFonksiyonStatus(){
         for(Fonksiyon f : AcarSozler.FONKSIYONLAR){
            if(f != null){
				Elaveler.YazdirSpesial("Fonksiyon Ismi - "+f.getFONKSIYON_ISMI());
				Elaveler.YazdirSpesial("Fonksiyon ID - "+f.getFonksiyon_ID());
				Elaveler.YazdirSpesial("Fonksiyon UID - "+f.getFONKSIYON_UID());
				Elaveler.YazdirSpesial("Fonksiyon Deyisgenlerinin Sayi - "+f.getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI());
				Elaveler.YazdirSpesial("------------------------DEYISGENLER-------------------------------");
                for(FonksiyonDeyisgenleri fd : f.getFONKSIYON_DEYISGENLERI()){
					Elaveler.YazdirSpesial("Fonksiyon Deyisgen Ismi - "+fd.getDEYISGENISMI());
					Elaveler.YazdirSpesial("Fonksiyon Deyisgen Tip -"+fd.getDEYISGENTIPI());
					Elaveler.YazdirSpesial("Fonkisyon Deysigen Icerig - "+fd.getDEYISGENICERIGI());
                }
            }
        }
    }
    public String getFONKSIYON_ISMI() {
        return this.FONKSIYON_ISMI;
    }

    public String getFONKISYON_GERI_DONDURULEN() {
        return FONKISYON_GERI_DONDURULEN;
    }

    public String getFONKSIYON_ICERIGI() {
        return FONKSIYON_ICERIGI;
    }

    public ArrayList<String> getFONKSIYON_ICERIG_DEYIGSENLERI() {
        return FONKSIYON_ICERIG_DEYIGSENLERI;
    }

    public ArrayList<FonksiyonDeyisgenleri> getFONKSIYON_DEYISGENLERI(){
        return FONKSIYON_DEYISGENLERI;    
    }

    public int getFonksiyon_ID() {
        return Fonksiyon_ID;
    }

    public int getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI() {
        return FONKSIYON_ICERIG_DEYISGENLERININ_SAYI;
    }
    
    public int getFONKSIYON_UID(){
        return FONKSIYON_UID;
    }

    public boolean getGERI_DONDURUCU_DURUMU(){
        return GERI_DONDURUCU_DURUMU;
    }

    public void setGERI_DONDURUCU_DURUMU(boolean GERI_DONDURUCU_DURUMU_){
        GERI_DONDURUCU_DURUMU = GERI_DONDURUCU_DURUMU_;
    }
    public void setFONKISYON_GERI_DONDURULEN(String FONKISYON_GERI_DONDURULEN_){
        FONKISYON_GERI_DONDURULEN = FONKISYON_GERI_DONDURULEN_;
    }
    //static Class Function
    public static Fonksiyon FonksiyonArama(String Fonksiyon_ismi){
        for(int index = 1; index < Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC; index++) {
            if(Fonksiyon_ismi.equals(Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[index].getFONKSIYON_ISMI())){
                //System.out.println(Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[index].getFONKSIYON_ICERIGI());
                return Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[index];
            }

        }

        return null;
    }
    public static boolean FonksiyonVarlikYoxlayici(String Fonksiyon_Ismi){
        //System.out.println("Fonksiyon Ismi :> "+Fonksiyon_Ismi);
        for(int index = 1; index < Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC; index++) {
            if(Fonksiyon_Ismi.equals(Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[index].getFONKSIYON_ISMI())){
                return false;
            }
        } 
        return true;
    }
    public static boolean FonksiyonVarlikYoxlayici(String Fonksiyon_Ismi, boolean TRUE){
        //System.out.println("Fonksiyon Ismi :> "+Fonksiyon_Ismi);
        for(int index = 1; index < Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC; index++) {
            if(Fonksiyon_Ismi.equals(Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[index].getFONKSIYON_ISMI())){
                return true;
            }
        } 
        return false;
    }
    public static int FonksiyonUIDGeneraction(){
        Random rn = new Random();
        boolean UID_FLAG = false;
        int UID_RETURN = 0;
        while(true){
            int UID = rn.nextInt(5000)+1000;
            if(Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR.length != 0){
                for(Fonksiyon fonksiyon: Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR){
                    if(fonksiyon == null){
                        UID_FLAG = true;
                        break;
                    }
                    if(fonksiyon.getFONKSIYON_UID() == UID){
                        UID_FLAG = false;
                        break;
                    }else{
                        UID_FLAG = true;
                    }
                }
                if(UID_FLAG){
                    UID_RETURN = UID;
                    break;
                }
            } else{
                UID_RETURN = UID;
                break;
            }
        }

        return UID_RETURN;
    }
    public static int FonksiyonGeriDondurucuBulucu(int index){

        int GeriDondurulen = -1;
        int SonIndex = 0;

        Scanner Oxuyucu = new Scanner(Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[index].getFONKSIYON_ICERIGI());

        while(Oxuyucu.hasNext()){
            String OxunanSatir = Oxuyucu.nextLine();
            int Index = ACTehliledici.MetinAxtarici(OxunanSatir, '<');
            int GeciciSetirUzunluq = OxunanSatir.length();
            
            if(Index != -1){
                if(OxunanSatir.substring(0, Index).replaceAll("\\s", "").equals("")){
      
                    GeriDondurulen = (SonIndex+=(3+Index));
                    break;
                }
            }
            SonIndex += GeciciSetirUzunluq;
        }
        return GeriDondurulen;
    }
    public static boolean FonksiyonTanimlayici(String Setir_ICERIKI, String Mod, boolean Alinan_Deger, Fonksiyon fonksi, int Oturucu_Index, int Sonu_Index, 
                                                int FonksitonReturnValueDection, int FonksiyonEnteredValueDection, int FonksiyonIcerikAliciBaslaniqc, 
                                                    int FonksiyonIcerikAliciBitis, int Fonksiyon_Parse){
           
        String FONKSIYON_ISMI = "";
        ArrayList<String> DEYISGENLER = new ArrayList<String>();
        ArrayList<FonksiyonDeyisgenleri> FONKSIYONDEYISGENLERI = new ArrayList<FonksiyonDeyisgenleri>(); 
        String FONKSIYON_ISDENILEN_TYPE = "0"; //default 0
        String FONKSIYON_ICERIGI = "";
        int DEYISGEN_SAYI = 0;

        //DIF: 0< FONKSIYON ISMI > X,Y,Z {}
        
        if(FonksitonReturnValueDection != -1 && FonksiyonEnteredValueDection != -1) {
            if(FonksiyonIcerikAliciBaslaniqc != -1 && FonksiyonIcerikAliciBitis != -1){
                //Get Fonksiyon Melumatlar 
                
                FONKSIYON_ISMI = Setir_ICERIKI.substring(1+FonksitonReturnValueDection, FonksiyonEnteredValueDection).replaceAll("\\s", "");
                
                if(Fonksiyon.FonksiyonVarlikYoxlayici(FONKSIYON_ISMI)){
                    
                    Tehliledici.Cesitler.AcarSozler.icerik_flag = true;
                    for(String a:Setir_ICERIKI.substring(1+FonksiyonEnteredValueDection, FonksiyonIcerikAliciBaslaniqc).split(",")){
                        DEYISGENLER.add(a);
                        FONKSIYONDEYISGENLERI.add(new FonksiyonDeyisgenleri(a));
                    }
                    
                    FONKSIYON_ISDENILEN_TYPE = Setir_ICERIKI.substring(1+Fonksiyon_Parse, FonksitonReturnValueDection);
                    DEYISGEN_SAYI = DEYISGENLER.size();
                    FONKSIYON_ICERIGI = Setir_ICERIKI.substring(1+FonksiyonIcerikAliciBaslaniqc, FonksiyonIcerikAliciBitis);
                    
                    //System.out.println("fonksiyon ismi : "+FONKSIYON_ISMI);
                    //System.out.println("fonksiyon geri isdenilen deger : "+FONKSIYON_ISDENILEN_TYPE);
                    //System.out.println("fonksiyon deyisgenleri : "+DEYISGENLER.toString());
                    //System.out.println("fonksiyon deyisgen sayi : "+DEYISGEN_SAYI);
                    //System.out.println("fonksiyon icerigi : "+FONKSIYON_ICERIGI);
                    
                    Fonksiyon fonksiyon = new Fonksiyon(FONKSIYON_ISMI, FONKSIYON_ISDENILEN_TYPE, FONKSIYON_ICERIGI, DEYISGENLER, FONKSIYONDEYISGENLERI, DEYISGEN_SAYI, 1+ACT.Fonksiyonlar.size(), Fonksiyon.FonksiyonUIDGeneraction());
                    ACT.Fonksiyonlar.add(fonksiyon);
                    Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC] = fonksiyon;
                    Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC++;

                    //KEYWORD_AS[1+KEYWORD_AS.length] += fonksiyon.getFONKSIYON_ISMI();
                }else{
                    System.out.println("\nXETA");
                }
            }else { return false; }
        }else if (FonksitonReturnValueDection != -1) {
            //System.out.println("SDSDSDSDSDSDSD");
            if(FonksiyonIcerikAliciBaslaniqc != -1 && FonksiyonIcerikAliciBitis != -1){
                Tehliledici.Cesitler.AcarSozler.icerik_flag = true;
                FONKSIYON_ISMI = Setir_ICERIKI.substring(++FonksitonReturnValueDection, FonksiyonIcerikAliciBaslaniqc).replaceAll("\\s", "");
                FONKSIYON_ISDENILEN_TYPE = Setir_ICERIKI.substring(1+Fonksiyon_Parse, --FonksitonReturnValueDection);
                FONKSIYON_ICERIGI = Setir_ICERIKI.substring(1+FonksiyonIcerikAliciBaslaniqc, FonksiyonIcerikAliciBitis);

                Fonksiyon fonksiyon = new Fonksiyon(FONKSIYON_ISMI, FONKSIYON_ISDENILEN_TYPE, FONKSIYON_ICERIGI, DEYISGENLER, FONKSIYONDEYISGENLERI, DEYISGEN_SAYI, 1+ACT.Fonksiyonlar.size(),  Fonksiyon.FonksiyonUIDGeneraction());
                ACT.Fonksiyonlar.add(fonksiyon);
                
                Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC] = fonksiyon;
                Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC++;

            }else { return false;}
        }else if (FonksiyonEnteredValueDection != -1) {
            if(FonksiyonIcerikAliciBaslaniqc != -1 && FonksiyonIcerikAliciBitis != -1){
                Tehliledici.Cesitler.AcarSozler.icerik_flag = true;
                int parse = Elaveler.MetinAxtarici(Setir_ICERIKI, ':');

                for(String a:Setir_ICERIKI.substring(1+FonksiyonEnteredValueDection, FonksiyonIcerikAliciBaslaniqc).split(",")){
                    DEYISGENLER.add(a);
                    FONKSIYONDEYISGENLERI.add(new FonksiyonDeyisgenleri(a));
                }
                FONKSIYON_ISMI = Setir_ICERIKI.substring(1+parse, FonksiyonEnteredValueDection).replaceAll("\\s", "");
                DEYISGEN_SAYI = DEYISGENLER.size();
                FONKSIYON_ICERIGI = Setir_ICERIKI.substring(1+FonksiyonIcerikAliciBaslaniqc, FonksiyonIcerikAliciBitis);

                Fonksiyon fonksiyon = new Fonksiyon(FONKSIYON_ISMI, FONKSIYON_ISDENILEN_TYPE, FONKSIYON_ICERIGI, DEYISGENLER, FONKSIYONDEYISGENLERI, DEYISGEN_SAYI, 1+ACT.Fonksiyonlar.size(), Fonksiyon.FonksiyonUIDGeneraction());
                ACT.Fonksiyonlar.add(fonksiyon);
                Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC] = fonksiyon;
                Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC++;

            }else { return false; }
        }else if(FonksitonReturnValueDection == -1 && FonksiyonEnteredValueDection == -1){
            if(FonksiyonIcerikAliciBaslaniqc != -1 && FonksiyonIcerikAliciBitis != -1){
                Tehliledici.Cesitler.AcarSozler.icerik_flag = true;
                int parse = Elaveler.MetinAxtarici(Setir_ICERIKI, ':');
                FONKSIYON_ISMI = Setir_ICERIKI.substring(1+parse, FonksiyonIcerikAliciBaslaniqc).replaceAll("\\s", "");
                FONKSIYON_ICERIGI = Setir_ICERIKI.substring(1+FonksiyonIcerikAliciBaslaniqc, FonksiyonIcerikAliciBitis);

                Fonksiyon fonksiyon = new Fonksiyon(FONKSIYON_ISMI, FONKSIYON_ISDENILEN_TYPE, FONKSIYON_ICERIGI, DEYISGENLER, FONKSIYONDEYISGENLERI, DEYISGEN_SAYI, 1+ACT.Fonksiyonlar.size(),  Fonksiyon.FonksiyonUIDGeneraction());
                ACT.Fonksiyonlar.add(fonksiyon);
                Tehliledici.Cesitler.AcarSozler.FONKSIYONLAR[Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC] = fonksiyon;
                Tehliledici.Cesitler.AcarSozler.FONKSIYON_SAYAC++;

            }else { return false;}
        }
        return true;
    }

}
