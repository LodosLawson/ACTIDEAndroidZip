package TestPack;

import Tehliledici.Elaveler;
import java.util.ArrayList;

public class MathStructure {
    public static void main(String[] args){
        String Data = "(1+(2+3)+3+4+(56+6)*(5*(5+54)*23)*23)";
        MegaMath(Data);
    }
    //UL-
    public static ArrayList<int[]> Infixindex = new ArrayList<int[]>();
    public static void MegaMath(String Data){
        //=>
		Elaveler.YazdirSpesial("MegaMath");
        BracketStructureIndexer(0, Data, Data.split(""));
        //SHOW
		for(int i = 0; i < Infixindex.size(); i++){
			
			Elaveler.YazdirSpesial("MegaMath Algo>"+String.valueOf(Infixindex.get(i)[0])+"-"+String.valueOf(Infixindex.get(i)[1]));
		}
       /* Infixindex.forEach(x -> {
            System.out.println(""+x[0]+"-"+x[1]);
        });*/
    }
    //Test Git commit inner code...
    public static int BracketStructureIndexer(int gindex, String Data, String[] FINAL){
        //..Ar indexer-     
        String[] data = Data.substring(gindex).split("");
        //gindex--;
        for(String x : data){
            if(FINAL[gindex].equals("(")){
                //..Ar indexer-     
                int[] indexer = new int[2];
                //Ar[]
                indexer[0] = gindex;
                //BracketStructureIndexer->
                gindex = BracketStructureIndexer(++gindex, Data, FINAL);
                //Ar[]
                indexer[1] = gindex;
                //UL <= Ar[]
                Infixindex.add(indexer);
            }else if(FINAL[gindex].equals(")")){
                //<-BracketStructureIndexer
                return gindex;
            }
            //+1 index
            gindex++;
            
            //..Vr LIMIT-
            int LIMIT = Data.length();
            //..Vr INDEX-
            int INDEX = gindex;
            if(LIMIT == INDEX){ break; } 
        }
        
        //<=
        return gindex;
    }
    
    public static int F(String Data, int s, int e){
        String[] data = Data.split("");
        int index = 0;
        for(String x : data){
            index++;
            if(x.equals("(")){
                Elaveler.YazdirSpesial(Data.subSequence(index, 2+F(Data.substring(index), --index, ++index)));
            }else if(x.equals(")")){
                return index;
            }
        }
        return -1;
    }
  public static String Math(String Data){
      
        //String[] Amatst = Data.split("(");
      
        //String[] Amatbt = Data.split(")");
      
        //System.out.println(""+Amatst[0]);
      
        int matst = Elaveler.MetinAxtarici(Data, "(");
        int metbt = Elaveler.MetinAxtarici(Data, ")");            
      
        String[] a = Data.split("");
      
        //.
        int index = 0;
        int[][] indexer = new int[a.length][2];
        int indexerindex = 0;
        int extractionindex = 0; 
        boolean nextflag = true;
        boolean currentflag = false;
        
        //..
        int leftindex = 1;
        int rightindex = 1;
        
        for(String x : a){
            //((),(),(()))       
            if(x.equals("(")){               
                leftindex++;
                indexer[indexerindex][0] = index;
                indexerindex++;

                /*
                if(nextflag){
                    extractionindex = indexerindex;
                    indexer[indexerindex][0] = index;
                    indexerindex++;
                }else{
                    indexer[indexerindex][0] = index;
                    indexerindex++;
                    if(currentflag)
                        nextflag = true;
                    else
                        currentflag = true;
                }
                */
            }else if(x.equals(")")){
                int currentindex = leftindex-rightindex;
                rightindex++;
                indexer[currentindex][1] = index;
                indexerindex++;
                /*
                if(currentflag == false){
                    //extractionindex--;
                    indexer[extractionindex][1] = index;
                }
                
                if(nextflag){
                    indexerindex--;
                    indexer[indexerindex][1] = index;
                    nextflag = false;
                    //currentflag = false;
                }else{
                    indexerindex--;
                    indexer[indexerindex][1] = index;
                    currentflag = false;
                }   
                */
            }
            index++;
        }
      
        for(int i = 0; i < indexer.length; i++){
		  	Elaveler.YazdirSpesial(""+indexer[i][0]+"-"+indexer[i][1]);
		 	Elaveler.YazdirSpesial(Data.substring(indexer[i][0], 1+indexer[i][1]));
        }
        //System.out.println(""+a.length);
            
      
        return Data;
    }
}
