package Tehliledici;

import Tehliledici.Tool.Deyisgen;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

import ac.acSystemFayilari;
import com.ACT.Android.Tehliledici.ACTools.*;
import com.ACT.Android.Tehliledici.Tools.*;
//import GUI.IDE.IDE;

public class Elaveler {

    //INT BU DEYISGEN RUN EDILEN SAYI TUTAR VE HER DEFE PROGRAM YENILENDIGINDE VE YA CONSOL SILINERSE DEYISILER YENI SIFIRLANAR
    //AVTOMATIK COGALMA EKLMEK GEREKIR 

    //Tanimlanan Object Deyisgenleri
    private static Scanner isdifadeciden_Oxucu;

	/*public static void Yazdir(String toString, boolean p1)
	{
		// TODO: Implement this method
		
	}*/
	
    //Ekrana Yazdirmaq Ucun Yazilmis Methotlar
    //burada mod alarak yazdiran bir yazdir fonksiyonu yaradmak gerek ve mod yanlizca ozel kulanilan yukari nesnelere ulasmasi gerek 00
  //  protected static void Yazdir(int deyer){ if(ACTehliledici.AC_IDE_BILDIRISI == true) { System.out.printf(""+deyer); } else {/*Ozel Duruma Daxil Olunur / System.out.printf("AC-IDE :"+deyer);/ IDE.ConsolDaxilEdici(""+deyer); */} }
 	//  protected static void Yazdir(char deyer){  if(ACTehliledici.AC_IDE_BILDIRISI == true) { System.out.printf(""+deyer); } else {/*Ozel Duruma Daxil Olunur / System.out.printf("AC-IDE :"+deyer);/ IDE.ConsolDaxilEdici(""+deyer); */ } }
  //  public static void Yazdir(String deyer){  if(ACTehliledici.AC_IDE_BILDIRISI == true) { System.out.printf(""+deyer); } else {/*Ozel Duruma Daxil Olunur / System.out.printf("AC-IDE :"+deyer); / IDE.ConsolDaxilEdici(""+deyer); */} }
    public static void YazdirSpesial(Object Data){
		
		KeyTyps.XConsolDispleyOutPut("\n"+Data.toString());
		
	}
	public static void Yazdir(Object deyer){
		KeyTyps.OutPut("\n"+deyer);
	}
    public static void Yazdir(String Melumat, String Mod) {
    	KeyTyps.OutPut("\n"+Melumat);
		/*if(Mod.equals("Consol")) {
            if(ACTehliledici.AC_IDE_BILDIRISI == false){
                System.out.print(Melumat);
            }else{
                IDE.ConsolDaxilEdici(Melumat);
            }
            //Ozel Kulanilan Deyisegenin OBJESI
            //IDE.ConsolDaxilEdici(Melumat);
        }*/
    }
    
    //Isdifadeciden Oxuyan Methotlar 
    static String Isdifadeciden_Oxu() { isdifadeciden_Oxucu = new Scanner(System.in); String Gonderilen_String = isdifadeciden_Oxucu.nextLine(); return Gonderilen_String; }

    //Bu Method Bir Steir Icerisinden Isdenilen Karakteri Axtararaq O'nun Indexini Geri Gonderir
    public static int MetinAxtarici(String Metin, String Axtarilacaq_Deyer){ return Metin.lastIndexOf(Axtarilacaq_Deyer); }
    public static int MetinAxtarici(String Metin, char Axtarilacaq_Deyer){ return Metin.indexOf(Axtarilacaq_Deyer); }
   
    //EYNI KAREKTER INDEKSLIYEN FONKSIYON 
    public static int[] MultiAxtarici(String Melumat, String Axtarilan, String MOD) {
        int[] index = new int[3];
        int x = 0;
        for(int i = 0; i < Melumat.length(); i++) {
            if(x != 2) {
                if(String.valueOf((Melumat.charAt(i))).equals(Axtarilan)) {
                    if(Axtarilan.equals(":")){
                        if(x == 1){
                            i = Melumat.length();
                        }
                    }              
                    if(MOD.equals("USTGLOBALOZEL")){ 
                        if(Axtarilan.equals("\"")){
                            if(x == 1){
                                int y = Melumat.length();
                                i = (y-1);
                            }
                        }else if(Axtarilan.equals(")")){
                            if(x == 1){
                                int y = Melumat.length();
                                i = (y-1);
                            }
                        }
                    }
                    index[x] = i;
                    x++;
                }
            } else {
                break;
            }
        }
        if(x <= 1) {
            index[2] = -1;
        }
        index[0] += 1;
        return index;
    }
    public static boolean IC(String type) {
        //System.out.println(type);
        boolean Gonderilen_Bildirim = false;
        String[] num = new String[] {"0","1","2","3","4","5","6","7","8","9"};
        for(int i = 0; i < type.length(); i++) {
            boolean Xeta = false;
            for(int j = 0; j < num.length; j++) {
                if(String.valueOf(type.charAt(i)).equals(num[j])) {
                    Xeta = true;
                }
            }
            if(Xeta == false) {
                return Xeta;
            }else {
                Gonderilen_Bildirim = true;
            }
        }
    	return Gonderilen_Bildirim;
    }
    
    public static boolean isStringInt(String s){
        try{
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException ex){
            return false;
        }
    }

    //Dosya Islemleri Ucun Yazilan 
    //ONEMLI TANIMLAR BUNLAR COXALARSA AYRI BIR CLASS DA BUNLARIN DUZGUN BIR SEKILDE YAZILMASI GEREKIR 
    public static String[] AyiriciYoxlayici(String ICERIK){
        String[] BOLUNENLER = new String[10000];
        try{
            int x = 0;
            int o = 0;
            int index = 0;
            for(int i = 0; i < ICERIK.length(); i++){     
                int Yoxlayici = MetinAxtarici(ICERIK.substring(x, i), '\"');           
                    if(Yoxlayici != -1){
                        int[] IcIndex = MultiAxtarici(ICERIK.substring(x), "\"","DEF");	
                        o = ACTehliledici.MetinAxtarici(ICERIK, ":");	
                        if(String.valueOf(ICERIK.charAt(i)).equals(",")){
                            if(IcIndex[1]+x < i){
                                //BOLUNENLER[index] = ICERIK.substring((1-IcIndex[0]+x), (1+IcIndex[1]+x));  
                                //Yazdir("\n"+ICERIK.substring(IcIndex[0]+x, IcIndex[1]+x));

                                if(x==0){
                                    BOLUNENLER[index] = ICERIK.substring(((--IcIndex[0])+x), (1+IcIndex[1]+x));  
                                    index++;
                                //Yazdir("\n>&: "+ICERIK.substring(((--IcIndex[0])+x), (1+IcIndex[1]+x)));
                                }
                                else{
                                    BOLUNENLER[index] = ICERIK.substring((--IcIndex[0]+x), (1+IcIndex[1]+x));  
                                    //Yazdir("\n>&: "+ICERIK.substring((--IcIndex[0]+x), (1+IcIndex[1]+x)));
                                    index++;
                                }
                                //Yazdir("\n>+: "+i);
                                //Yazdir("\n>-: "+(IcIndex[1]+x));
                                x = i;
                                //if(IcIndex[1] < i){
                                //  Yazdir("\n>=:"+ICERIK.substring(IcIndex[0]+IcIndex[1]));
                                
                                // }
                                //Yazdir("\n>^: "+ICERIK.substring(IcIndex[0], IcIndex[1]));
                            }
                            if(IcIndex[0] == -1 || IcIndex[1] == -1){
                                Yazdir("\n<<<XETA>>> ");
                            }
                    }else if(1+IcIndex[1]+x == o){
                        BOLUNENLER[index] = ICERIK.substring((--IcIndex[0]+x), (1+IcIndex[1]+x));  
                        index++;
                        x = i;

                        //Yazdir("\n>&: "+ICERIK.substring((--IcIndex[0]+x), (1+IcIndex[1]+x)));
                        //Yazdir("\n"+ICERIK.substring(IcIndex[0]+x, IcIndex[1]+x));
                        //Yazdir("\n>\\: "+(IcIndex[1]+x));
                        //Yazdir("\n>*: "+o);
                        //break;
                    }
                }else{
                    o = ACTehliledici.MetinAxtarici(ICERIK, ":");	
                    if(x == 0){
                        if(String.valueOf(ICERIK.charAt(i)).equals(",")){
                            BOLUNENLER[index] = ICERIK.substring(++x,i);
                            index++;
                            x = i;
                            //Yazdir("\n>>>> Deyisgen tanjimi");
                        }else if(i == o){
                            BOLUNENLER[index] = ICERIK.substring(++x,i);
                            index++;
                            x = i;
                        }
                    }else{
                        if(String.valueOf(ICERIK.charAt(i)).equals(",")){
                            BOLUNENLER[index] = ICERIK.substring(++x,i);
                            index++;
                            x = i;
                            //Yazdir("\n>>>> Deyisgen tanjimi");
                        }else if(i == o){
                            BOLUNENLER[index] = ICERIK.substring(++x,i);
                            index++;
                            x = i;
                        }
                    }                
                }
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return BOLUNENLER;
    }
    //OZEL TANIMLARIN BITMESI
    public static void Dosya_yaz_davamli(String MELUMAT, String Dosya_Yolu_Dosya, boolean Durum) throws IOException {
           BufferedWriter Yazici = null;
           try { Yazici = new BufferedWriter(new FileWriter(Dosya_Yolu_Dosya, Durum)); } catch (IOException e) { Yazdir("\n PROBLEM VAR <<< Dosya_yaz.Elaveler XETA "); }
           Yazici.write(MELUMAT);   		     
           Yazici.close();
    }
    public static void Dosya_yaz(String MELUMAT, String Dosya_Yolu_Dosya) throws IOException {
    	BufferedWriter Yazici = null;
	try { Yazici = new BufferedWriter(new FileWriter(Dosya_Yolu_Dosya)); } catch (IOException e) { Yazdir("\n PROBLEM VAR <<< Dosya_yaz.Elaveler XETA "); }
    	Yazici.write(MELUMAT);   		     
	Yazici.close();
    }
    public static String Dosya_oxu(String Dosya_Yolu_Dosya) throws IOException {
        File Dosya_Ac	= new File(Dosya_Yolu_Dosya);
	FileReader Dosya_oxuyar = null;
		try { Dosya_oxuyar = new FileReader(Dosya_Ac); } catch (FileNotFoundException e1) { YazdirSpesial(e1); e1.printStackTrace(); } 
	char[] String_Donusdurucu = new char[(int) Dosya_Ac.length()];
	try { Dosya_oxuyar.read(String_Donusdurucu); Dosya_oxuyar.close(); } catch (IOException e ) { Yazdir("\n PROBLEM VAR <<< Dosya_oxu.Elaveler XETA "+e); }	
	String Geri_Dondurulecek = new String(String_Donusdurucu);
    	return Geri_Dondurulecek;
    }
    static boolean SystemFayilarininYoxlanilmasi(String dilin_tipi, String Dosya_Yolu, char sla) {
    	boolean gonderilecek_deyer = false;
    	if(dilin_tipi.equals("java")) {
            File dosya_javasc = new File(Dosya_Yolu+sla+"javasc");
    	    if (!dosya_javasc.exists()) {
    	    	if (dosya_javasc.mkdir()) {              
                    Yazdir("\nJava Kodlari Ucun Qovluq Yaradildi.");   	    	
                    gonderilecek_deyer = true; 	    	
                } else {  	        
                    Yazdir("/nQovluq Yaradildiqi Zaman Xeta Basverdi <<< DosyaYazici XETA");
    	        }
    	    }  	    
            File dosya_ac = new File(Dosya_Yolu+sla+"javasc"+sla+"ac");   	    
            if(!dosya_ac.exists()) {  	    
                if(dosya_ac.mkdir()) {   	    	
                    Yazdir("\nAC System Qovluqu Yaradildi.");  	    	
                    gonderilecek_deyer = true;
    	    	} else {   	    	
                    Yazdir("\nQovluq Yaradildiqi Zaman Xeta Basverdi <<< DosyaYazici XETA");
    	    	}
    	    }
    	    File ac_system_fayilari_java_class_1 = new File(Dosya_Yolu+sla+"javasc"+sla+"ac"+sla+"acElaveler.class");
    	    if(!ac_system_fayilari_java_class_1.exists()) {
    	    	PrintWriter writer = null;		
                try {		
                    writer = new PrintWriter(Dosya_Yolu+sla+"javasc"+sla+"acElaveler.java", "UTF-8");		
                } catch (FileNotFoundException e) { e.printStackTrace(); } catch (UnsupportedEncodingException e) { YazdirSpesial(e); e.printStackTrace(); }		
                //Ozel Method Yazilmasi lazimdir               
                writer.write(acSystemFayilari.SystemFayiliJavaClass2());    	    	
                writer.close();   	    	    	
                if(ACTehliledici.isWindows()) { 	    	
                    ACTehliledici.Terminal("javac acElaveler.java", Dosya_Yolu+sla+"javasc");     	    
                    ACTehliledici.Terminal("javac acElaveler.java -d .", Dosya_Yolu+sla+"javasc");
    	    	} else {	    	   
                    ACTehliledici.Terminal("javac acElaveler.java", Dosya_Yolu+sla+"javasc");
                    ACTehliledici.Terminal("javac -d ./ acElaveler.java", Dosya_Yolu+sla+"javasc");
    	    	}
    	    }   
    	    File ac_system_fayilari_java_class_2 = new File(Dosya_Yolu+sla+"javasc"+sla+"ac"+sla+"acGiris.class");
    	    if(!ac_system_fayilari_java_class_2.exists()) {
    	    	PrintWriter Fayila_Yaz = null;		
                try {		
                    Fayila_Yaz = new PrintWriter(Dosya_Yolu+sla+"javasc"+sla+"acGiris.java", "UTF-8");		
                } catch (FileNotFoundException e) { YazdirSpesial(e); e.printStackTrace(); } catch (UnsupportedEncodingException e) {YazdirSpesial(e); e.printStackTrace(); }		
                //Ozel Method Yazilmasi lazimdir	
                                System.out.println(">>>"+ACT.Dosya_Yolu);

                Fayila_Yaz.write(acSystemFayilari.SystemFayiliJavaClass1());		
                Fayila_Yaz.close();	
                if(ACTehliledici.isWindows()) {		
                    ACTehliledici.Terminal("javac acGiris.java", Dosya_Yolu+sla+"javasc");	    	    
                    ACTehliledici.Terminal("javac acGiris.java -d .", Dosya_Yolu+sla+"javasc");   	
                } else {	    	    
                    ACTehliledici.Terminal("javac acGiris.java", Dosya_Yolu+sla+"javasc");	    	
                    ACTehliledici.Terminal("javac -d ./ acGiris.java", Dosya_Yolu+sla+"javasc");    
                }
    	    }
    	} else if(dilin_tipi.contentEquals("c")) {       
            File dosya_csc = new File(Dosya_Yolu+"csc");
    	    if (!dosya_csc.exists()) { 	    
                if (dosya_csc.mkdir()) {   	    	
                    Yazdir("\nC Kodlari ucun Qovluq Yaradildi.");   	    	
                    gonderilecek_deyer = true;
    	        } else {        
                    Yazdir("/nQovluq Yaradildiqi Zaman Xeta Basverdi <<< DosyaYazici XETA");
    	        }
    	    }
    	    File dosya_ac_c_ozel_kitabxana = new File(Dosya_Yolu+"csc"+sla+"ac_c_ozel_kitabxana");
    	    if (!dosya_ac_c_ozel_kitabxana.exists()) {
    	    	if (dosya_ac_c_ozel_kitabxana.mkdir()) { 	    	
                    Yazdir("\nAC System Qovluqu Yaradildi."); 	    	
                    gonderilecek_deyer = true;   	       
                } else {    	        
                    Yazdir("/nQovluq Yaradildiqi Zaman Xeta Basverdi <<< DosyaYazici XETA");
    	        }
    	    }	
            //C UCUN YAZILMIS JAVA API SYSTEM YOXLANILMASI
            File dosya_java_c_api_oxuyucuint = new File(Dosya_Yolu+"csc"+sla+"acOxuycuInt.class");            
            if(!dosya_java_c_api_oxuyucuint.exists()) {    	          
                PrintWriter Fayila_Yaz = null;             
                try {                
                    Fayila_Yaz = new PrintWriter(Dosya_Yolu+"csc"+sla+"acOxuycuInt.java", "UTF-8");      
                } catch (FileNotFoundException e) { e.printStackTrace(); } catch (UnsupportedEncodingException e) { e.printStackTrace(); }            
                //Ozel Method Yazilmasi lazimdir
                Fayila_Yaz.write(ac.acSystemFayilari.SystemFayilariJavaCOxuyucuIntAPI());             
                Fayila_Yaz.close();             
                ACTehliledici.Terminal("javac acOxuycuInt.java", Dosya_Yolu+"csc");      	         
            }          
            File dosya_java_c_api_oxuyucustring = new File(Dosya_Yolu+"csc"+sla+"acOxuycuString.class");          
            if(!dosya_java_c_api_oxuyucustring.exists()) {                    
                PrintWriter Fayila_Yaz = null;                       
                try {		                
                    Fayila_Yaz = new PrintWriter(Dosya_Yolu+"csc"+sla+"acOxuycuString.java", "UTF-8"); 		            
                } catch (FileNotFoundException e) {YazdirSpesial(e); e.printStackTrace(); } catch (UnsupportedEncodingException e) {YazdirSpesial(e); e.printStackTrace(); } 		       
                //Ozel Method Yazilmasi lazimdir  		
                Fayila_Yaz.write(ac.acSystemFayilari.SystemFayilariJavaCOxuycuStriungAPI());  		
                Fayila_Yaz.close();		
                ACTehliledici.Terminal("javac acOxuycuString.java", Dosya_Yolu+"csc");      	        
            }  	            
            File ac_system_fayilari_c = new File(Dosya_Yolu+sla+"csc"+sla+"acos_technology.c");   	          
            if(!ac_system_fayilari_c.exists()) {	              
                gonderilecek_deyer = true;           	               
                PrintWriter Fayila_Yaz = null;		            
                try {		               
                    if(ACTehliledici.isUnix()) {						                  
                        Fayila_Yaz = new PrintWriter(Dosya_Yolu+sla+"csc"+sla+"ac_c_ozel_kitabxana"+sla+"acos_technology.c", "UTF-8");                                                              
                    } else if(ACTehliledici.isWindows()) {			                
                        Fayila_Yaz = new PrintWriter(Dosya_Yolu+sla+"csc"+sla+"acos_technology.c", "UTF-8");                 
                    }		              
                } catch (FileNotFoundException e) {YazdirSpesial(e); e.printStackTrace(); } catch (UnsupportedEncodingException e) {YazdirSpesial(e); e.printStackTrace(); }		           
                //Ozel Method Yazilmasi lazimdir		             
                if(ACTehliledici.isWindows()) {		             
                    Fayila_Yaz.write(ac.acSystemFayilari.SystemFayiliCWin());		                 
                    Fayila_Yaz.close();		            
                } else {		             
                    Fayila_Yaz.write(ac.acSystemFayilari.SystemFayiliCLi());		               
                    Fayila_Yaz.close();  	    			            
                }  	    
            }    	    
            File ac_system_fayilari_c_header = new File(Dosya_Yolu+sla+"csc"+sla+"acos_technology.h");
    	    if(!ac_system_fayilari_c_header.exists()) {	    	
                gonderilecek_deyer = true;
    	    	PrintWriter Fayila_Yaz = null;		
                try {		
                    if(ACTehliledici.isUnix()) {		
                        Fayila_Yaz = new PrintWriter(Dosya_Yolu+sla+"csc"+sla+"ac_c_ozel_kitabxana"+sla+"acos_technology.h", "UTF-8");			
                    } else if(ACTehliledici.isWindows()) {		
                        Fayila_Yaz = new PrintWriter(Dosya_Yolu+sla+"csc"+sla+"acos_technology.h", "UTF-8");		
                    }		
                } catch (FileNotFoundException e) { YazdirSpesial(e); e.printStackTrace(); } catch (UnsupportedEncodingException e) {YazdirSpesial(e); e.printStackTrace(); }	
                //Ozel Method Yazilmasi lazimdir
                if(ACTehliledici.isWindows()) {		
                    Fayila_Yaz.write(ac.acSystemFayilari.SystemFayiliCHeaderWin());
                    Fayila_Yaz.close();
                } else {
                    Fayila_Yaz.write(ac.acSystemFayilari.SystemFayileCHeaderLin());
                    Fayila_Yaz.close();	
                }
    	    }
    	}    	
    	return gonderilecek_deyer;
    }
    
    //SYSTEM ICERSINDEN SILINEN DOSYA VE FAYILAR VE QOVLUQLAR 
    static void UstGlobalDeyisgelkrinSilinmesi() {
        //UST GLOBAL DEYISGELERI SILER FONKSIYON OLARAQ YERLESDIRILECEK
        for(int sayac = 1; sayac < Deyisgen.UGL_Sayac; sayac++) {    		
            File a = new File(ACT.Dosya_Yolu+"DE/"+ACT.Ust_Global_List[sayac]);
            a.delete();
    	}
       // int x = 0; int y = 1;
       // for(int i = 0; i < 10; i++){
       //     Deyisgen.AC_Deyisgenler[i][x] = null;
       //     Deyisgen.AC_Deyisgenler[i][y] = null;
       // }
      
        
    }
    static void SystemFayilarininSilinmesi(String Dosya_Yolu, char sla) {
        if(ACTehliledici.isUnix()) {
            File ac_system_fayilari_c = new File(Dosya_Yolu+sla+"csc"+sla+"ac_c_ozel_kitabxana"+sla+"acos_technology.c");
            ac_system_fayilari_c.delete();	   	            
            File ac_system_fayilari_h = new File(Dosya_Yolu+sla+"csc"+sla+"ac_c_ozel_kitabxana"+sla+"acos_technology.h");	    
            ac_system_fayilari_h.delete();	
        }else if(ACTehliledici.isWindows()) {
            File ac_system_fayilari_c = new File(Dosya_Yolu+sla+"csc"+sla+"acos_technology.c");
            //ac_system_fayilari_c.delete();	                
            File ac_system_fayilari_h = new File(Dosya_Yolu+sla+"csc"+sla+"acos_technology.h");                                            
            //ac_system_fayilari_h.delete();	   
        }
	                   
        File silinecek_ac_system_fayilari_java_2 = new File(Dosya_Yolu+sla+"javasc"+sla+"acElaveler.java");
        silinecek_ac_system_fayilari_java_2.delete();
        File silinecek_ac_system_fayilari_java_1 = new File(Dosya_Yolu+sla+"javasc"+sla+"acGiris.java");
        silinecek_ac_system_fayilari_java_1.delete();
        File silinecek_ac_system_fayilari_java_class_1 = new File(Dosya_Yolu+sla+"javasc"+sla+"acElaveler.class");
        silinecek_ac_system_fayilari_java_class_1.delete();
        File silinecek_ac_system_fayilari_java_class_2 = new File(Dosya_Yolu+sla+"javasc"+sla+"acGiris.class");
        silinecek_ac_system_fayilari_java_class_2.delete();
        File silinecek_ac_system_fayilari_c_java_oxuyucuint_api = new File(Dosya_Yolu+sla+"csc"+sla+"acOxuycuInt.java");
        silinecek_ac_system_fayilari_c_java_oxuyucuint_api.delete(); 
        File silinecek_ac_system_fayilari_c_java_oxuyucuiString_api = new File(Dosya_Yolu+sla+"csc"+sla+"acOxuycuString.java");
        silinecek_ac_system_fayilari_c_java_oxuyucuiString_api.delete();   
    }
    public static void SystemFayillariSonSilinenler(boolean bayrag, String Dosya_Yolu, char sla) {
        if(bayrag == true) {
            //C UCUN YAZILMIS OLAN BIR JAVA API NIN CLASS FAYILINI SILER 
            File silinecek_ac_system_fayilari_c_java_oxuyucuint_api_class = new File(Dosya_Yolu+sla+"csc"+sla+"acOxuycuInt.class");
            silinecek_ac_system_fayilari_c_java_oxuyucuint_api_class.delete(); 
            File silinecek_ac_system_fayilari_c_java_oxuyucustring_api_class = new File(Dosya_Yolu+sla+"csc"+sla+"acOxuycuString.class");
            silinecek_ac_system_fayilari_c_java_oxuyucustring_api_class.delete(); 
            SystsemFayilariOUTFILEDELET(Dosya_Yolu, sla);
            UstGlobalDeyisgelkrinSilinmesi();
        }
    }
    public static void SystsemFayilariOUTFILEDELET(String Dosya_Yolu, char sla){
        File silincecek_ac_system_fayilari_outjc = new File(Dosya_Yolu+sla+"javacout.otpt");
        silincecek_ac_system_fayilari_outjc.delete();
        File silinecek_ac_system_fayilari_oturucu_ac  = new File(Dosya_Yolu+sla+"csc"+sla+"Oturucu.ac");
        silinecek_ac_system_fayilari_oturucu_ac.delete();
    }
}
