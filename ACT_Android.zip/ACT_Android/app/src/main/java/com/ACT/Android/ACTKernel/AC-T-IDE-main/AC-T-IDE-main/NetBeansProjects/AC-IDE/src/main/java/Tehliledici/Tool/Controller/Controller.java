package Tehliledici.Tool.Controller;

import Tehliledici.Tool.Deyisgen;
import Tehliledici.Tool.Error.Error;
import Tehliledici.Tool.Fonksiyon;

public class Controller {
    
    public String TypeValueControll(String Value){
        
        if(Deyisgen.ACDeyisgenVarligYoxlayici(Value)){
            return Deyisgen.ACDeyisgenDondurucu(Value);
        }else if(Fonksiyon.FonksiyonVarlikYoxlayici(Value)){
            return Fonksiyon.FonksiyonArama(Value).getFONKSIYON_ISMI();
        }
        
        return "";
    }
    
    public void ds(String value){
        
    }
    
    public boolean TypeInputingStruct(String obje){
        return Fonksiyon.FonksiyonVarlikYoxlayici(obje, true);
    }
    
    public String Type(String obje){
        
        if(Deyisgen.ACDeyisgenVarligYoxlayici(obje)){
            return "Desyigen";
        }else if(Deyisgen.ACFonksiyonDeyisgenVarligYoxlayici(obje)){
            return "FonksiyonDeysgen";
        }else if(Fonksiyon.FonksiyonVarlikYoxlayici(obje, true)){
            return "Fonksiyon";
        }else{   
            new Error().MakeError("VALUE", "ERROR TYPE", "0", obje, "Not DEF");
            return "NotDEF";
        }
    }
}
