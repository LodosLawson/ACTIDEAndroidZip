package backend;
/*
import backend.KeyboardBack.Keyboard;
import java.awt.Color;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.text.AbstractDocument;
import org.w3c.dom.Node;

/**
 *
 * @author mehemmed
 */
 /*
public class OzelJSCroll extends JScrollPane{
    private JTextPane PANEL;
    private Keyboard keyboard;
    //public static JTextPane[] jk = new JTextPane[100];
    //private static int Sayac = 0;

    public OzelJSCroll(Keyboard KeyBoard){
       PANEL = new JTextPane();
       this.keyboard = KeyBoard;
    }
    public JTextPane getPANEL() {
        return PANEL;
    }
    public void setPANEL(JTextPane PANELDAXILI) {
        PANEL = PANELDAXILI;
    }
    public void Yazdir(String Melumat){
       PANEL.setText(Melumat);
    }
    public void EKle(String qisamelumat){
        PANEL.setText(PANEL.getText()+qisamelumat);
    }
    public String MelumatAL(){
        return PANEL.getText();
    }
    public OzelJSCroll OzelJSCroll(){
        //PANEL.setStyle("-fx-background-color:#434547;");
        //this.PANEL.set
        //IDE.panelid[IDE.SAYACID] = IDE.SAYACID;
        LineNumberPanea lineNumber = new LineNumberPanea( PANEL );
        //lineNumber.setPreferredSize(99999);
        ((AbstractDocument) PANEL.getDocument()).setDocumentFilter(new CustomDocumentFilter(PANEL));
        this.setRowHeaderView( lineNumber );
        this.setViewportView(PANEL);
        //PANEL.addKeyListener(this.keyboard.IDEKeyboard(PANEL));
   
        return  this;
    }
    
}
*/
