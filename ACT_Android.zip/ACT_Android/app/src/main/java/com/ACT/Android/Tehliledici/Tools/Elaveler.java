package com.ACT.Android.Tehliledici.Tools;
import android.app.*;
import com.ACT.Android.*;
import com.ACT.Android.Run.*;
import com.ACT.Android.Tool.*;
import java.io.*;
import java.util.*;
import com.ACT.Android.Tehliledici.*;

public class Elaveler {
	
	public static String DefAcFileName;
	public static String DefAcFilePath;
	
	//private FileManager ElavelerFileManagerConnect = new FileManager(MainActivity.fm.getcontext());
	
	//XConsol OutPut Displey Function
	public static void XConsolDispleyOutPut(String Data){
		xconcolactivity.XConsolBuffer(Data);
	}
	//TextView OutPut Function
	public static void OutPut(String Data){
		
		ACTehliledici.GlobalOutPut += Data;
		
	}
	//File Read
	public static String ReadAcFile(){
		String Returcontext = null;
		File AcFile = new File(DefAcFilePath);
		System.out.println(DefAcFilePath);
		//Log.v("Error","\n"+MainActivity.fm.readFile(DefAcFilePath));
		
		return MainActivity.fm.readFile(MainActivity.fm.getdirfull(SecondActivity.SelectPosition),SecondActivity.SelectFile);
	}
	//Read Line by Line
	public static List<String> ReadLine(String Content){
		Scanner scanner = new Scanner(Content);
		
		if(Content != null || !Content.equals("")){
			List<String> ReList = ArrayList<String>;
			while (scanner.hasNextLine()) {
				String r = scanner.nextLine();
				ReList.add(r);
				//System.out.println(r);
			}
			scanner.close();
			return ReList;
		}else{
			System.out.println("tt");
			return null;
		}
	}
}
