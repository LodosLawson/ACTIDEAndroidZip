package com.ACT.Android;

import android.content.*;
import android.view.*;
import android.widget.*;
import com.ACT.Android.*;
import java.util.*;

class AdapertCus extends ArrayAdapter<String>
 {	
	
    public AdapertCus(Context context, List<String> items) {
        super(context, R.layout.my_item_layout, items);
    
	}

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
		ViewHolder holder;
		 
		if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            view = inflater.inflate(R.layout.my_item_layout, parent, false);
            holder = new ViewHolder();
            holder.text1 = view.findViewById(R.id.text1);
            holder.text2 = view.findViewById(R.id.text2);
			//holder.textselectfile = view.findViewById(R.id.selectedpath);
            holder.checkbox = view.findViewById(R.id.check);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
		
        //TextView text1 = view.findViewById(R.id.text1);
      //  TextView text2 = view.findViewById(R.id.text2);
		//CheckBox checkBox = (CheckBox) view.findViewById((R.id.check));
		
        String item = getItem(position);
		String path = MainActivity.fm.getdirfull(position);
        holder.text1.setText(item);
        holder.text2.setText(path);
		
		view.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					//adapter.toggleSelection(position);
					SecondActivity.SelectFile = getItem(position).toString();
					SecondActivity.SelwctFilePath = MainActivity.fm.getdirfull(position);
					SecondActivity.SelectPosition = position;

					
					SecondActivity.selectedpath.setText(SecondActivity.SelwctFilePath);
					Toast.makeText(getContext(), "ListView item clicked: " + getItem(position).toString(), Toast.LENGTH_SHORT).show();
				}
			});
		
		holder.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (isChecked) {
						// CheckBox seçili olduğunda yapılacak işlemler
						MainActivity.fm.getdelectedfileobj().addToList((position));
					} else {
						// CheckBox seçili değilken yapılacak işlemler
						MainActivity.fm.getdelectedfileobj().removeFromList((position));
					}
				}
			});
		
        return view;
    }
	
	static class ViewHolder {
		TextView text1;
		TextView text2;
		TextView textselectfile;
		CheckBox checkbox;
	}
	
}

