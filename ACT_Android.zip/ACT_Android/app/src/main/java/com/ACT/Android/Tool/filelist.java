package com.ACT.Android.Tool;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class filelist {

    public static List<String> getFiles(String directoryPath) {
        List<String> fileList = new ArrayList<String>();
        File directory = new File("MyFolder");
        File[] files = directory.listFiles();

        for (File file : files) {
            if (file.isFile()) {
                fileList.add(file.getName());
            } else if (file.isDirectory()) {
                fileList.addAll(getFiles(file.getAbsolutePath()));
            }
        }

        return fileList;
    }

}

