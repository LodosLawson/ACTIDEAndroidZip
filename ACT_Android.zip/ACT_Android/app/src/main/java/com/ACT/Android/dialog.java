package com.ACT.Android;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import com.ACT.Android.*;
import android.widget.*;

public class dialog extends DialogFragment{
	private EditText editTextFolderName;
    private EditText editTextFileName;
    private ExampleDialogListener listener;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialogcreatefile, null);

        builder.setView(view)
			.setTitle("Create AC Fild och Folder")
			.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {

				}
			})
			.setPositiveButton("ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					String username = editTextFolderName.getText().toString();
					String password = editTextFileName.getText().toString();
					listener.applyTexts(username, password);
					
					SecondActivity.uodate();
				}
			});

        editTextFolderName = view.findViewById(R.id.FolderName);
        editTextFileName = view.findViewById(R.id.FileName);

        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            listener = (ExampleDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
										 "must implement ExampleDialogListener");
        }
    }

    public interface ExampleDialogListener {
        void applyTexts(String username, String password);
    }
}
