package com.ACT.Android;

import android.content.*;
import java.io.*;
import java.util.*;
import android.widget.*;

public class FileManager {
    private static final String FOLDER_NAME = "MyFolder";
    private File folder;
	private List dirfol;
	private List dirful;
	private Context context;
	private delectedacfile DelectedFiles;
	
	public File getFolder(){
		return folder;
	}
	public List getlist(){
		return dirfol;
	}
	public List getpath(){
		return dirful;
	}
	public Context getcontext(){
		return this.context;
	}
	public String getdirfull(int point){
		
		return (String)dirful.get(point);
	}
	public delectedacfile getdelectedfileobj(){
		return DelectedFiles;
	}
    public FileManager(Context context) {
        folder = new File(context.getExternalFilesDir(null), FOLDER_NAME);
		this.context = context;
        if (!folder.exists()) {
            folder.mkdir();
        }
		DelectedFiles = new delectedacfile();
		dirfol = this.listAllFiles(folder);
		dirful = this.listAllfullFiles(folder);
    }

    public boolean saveFile(String pathName,String fileName, String fileContents) {
        try {
            File file = new File(pathName, fileName);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(fileContents.getBytes());
            fos.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String readFile(String pathName, String fileName) {
        try {
            File file = new File(pathName, fileName);
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();
            return new String(data, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
	
	
    public boolean deleteFile(String filedirochname) {
        File file = new File(filedirochname);
        return file.delete();
    }
	//public String[] listFiles() {
	public List<String> listAllFiles(File dir) {
		//File dir = folder;
		List<String> dirfol = new ArrayList<>();
	
		
		File[] files = dir.listFiles();

		if (files != null && files.length >= 0) {
			for (File file : files) {
				
				if (file.isDirectory()) {
					// Alt klasör ise, listeleme işlemi rekürsif olarak devam eder.
					//dirfol.add("Folder:"+file);
					dirfol.addAll(listAllFiles(file));
				} else {
					if(file.getName().contains(".ac")){
						// Dosya ise, dosya adını listeye ekle.
						dirfol.add(file.getName());
					
					}
				}
			}
		}
		return dirfol;
	//}
	
	}
	public List<String> listAllfullFiles(File dir) {
		//File dir = folder;
		
		List<String> dirful = new ArrayList<>();

		File[] files = dir.listFiles();

		if (files != null && files.length >= 0) {
			for (File file : files) {
				if (file.isDirectory()) {
					// Alt klasör ise, listeleme işlemi rekürsif olarak devam eder.
					//dirful.add("Folder:"+file);
					dirful.addAll(listAllfullFiles(file));
					
				} else {
					if(file.getName().contains(".ac")){
						// Dosya ise, dosya adını listeye ekle.
						dirful.add(file.getParent()+"/");
					
					}
				}
			}
		}
		return dirful;
		//}

	}
	
	public boolean createSubFolder(String folderName) {
		File subFolder = new File(folder, folderName);
		return subFolder.mkdir();
	}
	public boolean createFile(String fileName) {
		try {
			File file = new File(folder, fileName+".ac");
			return file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	

	public class delectedacfile {
		private ArrayList<Integer> myList;

		public delectedacfile() {
			this.myList = new ArrayList<Integer>();
		}

		public int getlissizd(){
			return this.myList.size();
		}
		public void addToList(int value) {
			this.myList.add(value);
		}
		public boolean removeFromList(int value) {
			return this.myList.remove(Integer.valueOf(value));
		}
		public Integer getitem(int position){
			return this.myList.get(position);
		}
	}
}

