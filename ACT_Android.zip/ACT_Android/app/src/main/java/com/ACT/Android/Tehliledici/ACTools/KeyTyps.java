package com.ACT.Android.Tehliledici.ACTools;
import com.ACT.Android.Tehliledici.Tools.*;
import android.system.*;

public class KeyTyps extends Elaveler{
	
	public KeyTyps(){
		
		
	}
	public static boolean TypeDetect(String Data){
		try{
			if(Data.contains("def")){
				
				try{
					int DefKeyStartİndex = Data.indexOf("def");
					int DefKeyEndİndex = DefKeyStartİndex + "def".length()-1;			
					int MovOperatorİndex = Data.indexOf("=");
					int MagicEndİndex = -1;
					int DataİnStartİndex = -1;
					int DataİnEndİndex = -1;
				}catch(Exception e){
					
				}
				
				//if(()){
					
				//}
				/*
				if(((Data.substring(s, Data.length()).contains(":")) == (
						Data.substring(s, Data.length()).contains("\"")  && 
							Data.substring(Data.substring(s, Data.length()).indexOf("\"")+1, Data.length()).contains("\"") 
								)) ){
					
						OutPut("TRUE");
				}*/
				
				/*
				if((Data.substring(s, Data.length()).contains(":") ? (Data.substring(s, Data.length()).contains("\"") && 
						Data.substring(Data.substring(s, Data.length()).indexOf("\"")+1).contains("\"")) : 
							Data.substring(s, Data.length()).contains(":")) == true){
					OutPut("TRUE");
				}
				/*if((Data.substring(s,Data.length()).contains(":")) ? (Data.substring(s, Data.length()).contains("\"") ? a = true: false ==
					Data.substring(Data.substring(s, Data.length()).indexOf("\"")+1, Data.length()).contains("\"") ? a2 = true : false) ? 
					   (Data.substring(s, Data.length()).indexOf("\"")+1 < Data.substring(s,Data.length()).indexOf(":") ==
							Data.substring(Data.substring(s, Data.length()).indexOf("\"")+1, 
								Data.length()).indexOf("\"")+1 < Data.substring(s,Data.length()).indexOf(":")) :
				   					(a != a2) ? false : 
										Data.substring(s,Data.length()).contains(":") == (a != a2 ) ? true : false : false){
								
								OutPut("\na"+a);
								OutPut("\na2"+a2);
								OutPut("\nTRUE\n");
					
				}*/
				return true;
			}
		}catch(Exception e){
			OutPut("TypeDetect Data Error Null:"+e);
		}
		return false;
	}
	public class Data{
		
		private String name;
		private String typename;
		private String dataname;
		private String data;
		private String location;
		private String value;
		private String description;
		
		public Data(){
			
		}
	}
}
