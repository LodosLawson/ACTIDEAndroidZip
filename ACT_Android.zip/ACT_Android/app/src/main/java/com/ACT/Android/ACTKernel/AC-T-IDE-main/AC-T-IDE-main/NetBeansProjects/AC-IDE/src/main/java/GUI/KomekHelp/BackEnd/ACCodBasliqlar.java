package GUI.KomekHelp.BackEnd;

import Tehliledici.Elaveler;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ACCodBasliqlar {
    
    //String[] ACCodBaslqilari = {"USTGLOBAL","BASLANQIC", "YAZDIR", "reqem", "herif", "DIF", "AC CODE", "MODON - MODOF", "SAXLA", "TEHLIL", "HELP"};

    //ArrayList
        ArrayList<String> ACCodBaslqilari = new ArrayList<>();
        ArrayList<HKItem> HKI = new ArrayList<>();
    
    //String 
        //FILES
            String ACHK;
            
    public ACCodBasliqlar(String ACHK) {
        this.ACHK = ACHK;
        Update();
    }
    
    public void Update(){
        ACCodBaslqilari.removeAll(ACCodBaslqilari);
        HKI.removeAll(HKI);
        
        ACCodBaslqilari.add("USTGLOBAL"); ACCodBaslqilari.add("BASLANQIC"); ACCodBaslqilari.add("YAZDIR"); ACCodBaslqilari.add("reqem"); ACCodBaslqilari.add("herif");
        ACCodBaslqilari.add("DIF"); ACCodBaslqilari.add("AC CODE"); ACCodBaslqilari.add("MODON"); ACCodBaslqilari.add("SAXLA"); ACCodBaslqilari.add("TEHLIL"); ACCodBaslqilari.add("HELP");

        
        HKI.add(new HKItem("USTGLOBAL", "<USTGLOBAL JAVA,C: \n SON AC>", "<html>Burada Bir Deyisgen tanimi ede bilesiniz bu deyisgen hem java hem C hemdeki "+
                                                                            "AC Programlama Dilerinde Isdiafde oluna biliner.</html>"));  //index 1
        HKI.add(new HKItem("BASLANQIC", "<BASLANQIC Programing Leanguage: File Name; \n SON AC>", "<html>Burada bir programlama dili tanimi ede bilersiniz"+
                                                                                                    "Bu programlama dili hal hazirda Java, ve C Dilerini desdekleyir</html>"));  //index 2
        HKI.add(new HKItem("YAZDIR", "YAZDIR::", "<html>bu keyword sayesinde ekrana her hansisa bir yazi yaza bilersiniz ve ya YAZDIR icersinde # isdiafde "+
                                                    "ederek melumati ferqli bir yere yazdira bilersiniz. bu yerlerden biri ise Fayildir" + 
                                                        "ve melumati fayila yazarken melumat ardicil yazilmasi ucun #Fayilin Adi sonuna 'w' elave etmek gerekdir. </html>"));  //index 3
        HKI.add(new HKItem("REQEM", "reqem Deyisgen Adi = 1;", "<html>bu keyword sayeisnde reqem tanimi ede bilersiniz.</html>"));  //index 4
        HKI.add(new HKItem("HERIF", "herif Deyisgen Adi = \"Data\"", "<html>Bu keyword sayesinde herif tanimi ede bilseiniz.</html>"));  //index 4
        HKI.add(new HKItem("DIF", "DIF:", ""));  //index 4
        HKI.add(new HKItem("AC CODE", "AC CODE", ""));  //index 5
        HKI.add(new HKItem("MODON - MODOF", "", ""));  //index 6
        HKI.add(new HKItem("SAXLA", "SAXLA", ""));  //index 7
        HKI.add(new HKItem("TEHLIL", "TEHLIL", ""));  //index 8
        HKI.add(new HKItem("HELP", "HELP", ""));  //index 9
        
        
        //HKI.add(new HKItem("-", "----------------------------------------------------------------------------------", ""));  //index 9
        
        
        try{
            String File = Elaveler.Dosya_oxu(ACHK);
            
            Scanner oxuyucu = new Scanner(File);
            //System.out.println(Elaveler.Dosya_oxu("src\\main\\java\\GUI\\KomekHelp\\BackEnd\\PersonelSaveHelpKomekFile.achk"));
            if(!File.equals("")){
                while(oxuyucu.hasNext()){
                    String[] oxunan = oxuyucu.nextLine().split("GGT5690-23KO");
                    HKI.add(new HKItem(oxunan[0], oxunan[1], oxunan[2]));  //index 9
                    ACCodBaslqilari.add(oxunan[0]);
                    //System.out.println(oxunan[0]+oxunan[1]+oxunan[2]);
                    //System.out.println(oxunan[0]);

                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public ArrayList getACCodBaslqilari() {
        return ACCodBaslqilari;
    }

    public void setACCodBaslqilari(ArrayList ACCodBaslqilari) {
        this.ACCodBaslqilari = ACCodBaslqilari;
    }
    
    public String getACCodBaslqilariElement(int index){
        return ACCodBaslqilari.get(index);
    }
    
    public boolean Equals(String[] Item){
        this.Update();
		
        /*if (!ACCodBaslqilari.stream().noneMatch(x -> (x.equals(Item[0])))) {
            System.out.println("GUI.KomekHelp.BackEnd.ACCodBasliqlar.Equals()");
            return false;
        }*/
        
        return true;
        /*
        boolean Gonderilen = true;
        try{
            Scanner oxuyucu = new Scanner(Elaveler.Dosya_oxu("src\\main\\java\\GUI\\KomekHelp\\BackEnd\\PersonelSaveHelpKomekFile.achk"));
            while(oxuyucu.hasNext()){
                //System.out.print(oxuyucu.nextLine());

                String[] oxunan = oxuyucu.nextLine().split("GGT5690-23KO");
                //System.out.println(Item[0] + "---" + oxunan[0]);
                String x = Item[0];
                String y = oxunan[0];

                if(Item[0].equals(y)) {
                    System.out.print(Item[0]+" -- "+oxunan[0]);
                    Gonderilen = false;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return Gonderilen;
        (
        */
    }
    
    public boolean DeleteElement(String[] Item){
        String TO = "";
        boolean Gonderilen = false;
        try{
            Scanner oxuyucu = new Scanner(Elaveler.Dosya_oxu(ACHK));
            //System.out.println(Elaveler.Dosya_oxu("src\\main\\java\\GUI\\KomekHelp\\BackEnd\\PersonelSaveHelpKomekFile.achk"));
            while(oxuyucu.hasNext()){
                String[] oxunan = oxuyucu.nextLine().split("GGT5690-23KO");
                if(Item[0].equals(oxunan[0]) && Item[1].equals(oxunan[1]) && Item[2].equals(oxunan[2]) ){
                    Gonderilen = true;
                }else{
                    TO += (oxunan[0]+"GGT5690-23KO"+oxunan[1]+"GGT5690-23KO"+oxunan[2]+"\n");
                }

            }
            Elaveler.Dosya_yaz(TO, ACHK);
        }catch(IOException e){
            e.printStackTrace();
        }
        return Gonderilen;
    }
    
    public HKItem getHKItem(int index){
        return HKI.get(index);
    }
    
}
