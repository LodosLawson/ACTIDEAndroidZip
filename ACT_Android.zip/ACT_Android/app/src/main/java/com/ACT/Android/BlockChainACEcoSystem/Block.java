package com.ACT.Android.BlockChainACEcoSystem;

// Blok sınıfı
import java.nio.charset.*;
import java.security.*;
import com.ACT.Android.*;

public class Block
 {
    private int index;
    private String data;
    private String previousHash;
    private String hash;

    public Block(int index, String data, String previousHash) {
        this.index = index;
        this.data = data;
        this.previousHash = previousHash;
        this.hash = calculateHash();
    }

	public void setIndex(int index)
	{
		this.index = index;
	}

	public int getİndex()
	{
		return index;
	}

	public void setData(String data)
	{
		this.data = data;
	}

	public String getData()
	{
		return data;
	}

	public void setPreviousHash(String previousHash)
	{
		this.previousHash = previousHash;
	}

	public String getPreviousHash()
	{
		return previousHash;
	}

	public void setHash(String hash)
	{
		this.hash = hash;
	}

	public String getHash()
	{
		return hash;
	}

    public String calculateHash() {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String rawData = index + data + previousHash;
            byte[] hashBytes = digest.digest(rawData.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return null;
    }
	public boolean isValid() {
        String recalculatedHash = calculateHash();

        if (!hash.equals(recalculatedHash)) {
            return false;
        }

        if (index == 0) {
            return true;
        }

        Block previousBlock = MainActivity.blockchain.getPreviousBlock(index);
        return previousBlock.getHash().equals(previousHash);
    }
    // Getter ve Setter metotları buraya ekleyebilirsiniz
    // ...
}


