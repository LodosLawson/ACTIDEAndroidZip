package com.ACT.Android;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class chtgpt extends Activity {

	private Button showPopupBtn, closePopupBtn;
    private PopupWindow popupWindow;
    private LinearLayout popupLayout;
    private int xDelta, yDelta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatgpt);
/*
        showPopupBtn = findViewById(R.id.chatgptButton1);

        // Inflate the popup_layout.xml
        popupLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.importfiles, null);

        // Initialize the popup window
        popupWindow = new PopupWindow(popupLayout, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);

        // Add touch listener to the popup window
        popupLayout.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							// Get the current touch location of the popup window
							int[] location = new int[2];
							popupLayout.getLocationOnScreen(location);
							int x = location[0];
							int y = location[1];

							// Save the initial touch point of the popup window
							xDelta = (int) (event.getRawX() - x);
							yDelta = (int) (event.getRawY() - y);
							break;
						case MotionEvent.ACTION_MOVE:
							// Get the screen size
							Display display = getWindowManager().getDefaultDisplay();
							Point size = new Point();
							display.getSize(size);
							int screenWidth = size.x;
							int screenHeight = size.y;

							// Calculate the new position of the popup window
							int newX = (int) event.getRawX() - xDelta;
							int newY = (int) event.getRawY() - yDelta;

							// Restrict the popup window's position within the screen
							if (newX < 0) newX = 0;
							if (newY < 0) newY = 0;
							if (newX > screenWidth - popupWindow.getWidth()) newX = screenWidth - popupWindow.getWidth();
							if (newY > screenHeight - popupWindow.getHeight()) newY = screenHeight - popupWindow.getHeight();

							// Update the position of the popup window
							popupWindow.update(newX, newY, -1, -1);
							break;
					}
					return true;
				}
			});

        // Add click listener to the button that shows the popup window
        showPopupBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Show the popup window
					popupWindow.showAsDropDown(v, 0, 0);
				}
			});
/*
        // Add click listener to the button inside the popup window that closes the popup window
        closePopupBtn = popupLayout.findViewById(R.id.close_button);
        closePopupBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Dismiss the popup window
					popupWindow.dismiss();
				}
			});*/
    }
}
