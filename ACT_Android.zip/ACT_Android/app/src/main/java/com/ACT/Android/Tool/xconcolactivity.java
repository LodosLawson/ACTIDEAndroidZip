package com.ACT.Android.Tool;

import android.app.*;
import android.os.*;
import com.ACT.Android.*;
import android.widget.*;
import android.view.*;

public class xconcolactivity extends Activity
{

	public static String XCBufferData;
	public static EditText XConsolOutPutDispleyObject;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xconsol);
		
		XConsolOutPutDispleyObject = findViewById(R.id.XConsolDispley);
		XConsolOutPutDispleyObject.setText(XCBufferData);
		
		final Button XConsooButoonClear = findViewById(R.id.ClearBuffer);
		XConsooButoonClear.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				XCBufferData = "";
				recreate();
			}
		});
	}
 	
	public static void XConsolBuffer(String Data){
		XCBufferData += Data;
	}
	
}
