package Tehliledici.Tool.Error;

import java.util.ArrayList;

public class Error {
    
    private static final ArrayList<ErrorType> errortype = new ArrayList<ErrorType>();
    
    public Error(){
        //Tehliledici.ACTehliledici.DEFAULT.Defaultor(errortype, "ArrayList");
    }
    public void ErrorTypeDefault(){
        errortype.clear();
    }
    public void ErrorYazdir(int ErrorIndex){
        ErrorType error = errortype.get(ErrorIndex);
        error.ErrorYazdir("["+"<"+error.getErrortype()+">"+"("+error.getErrorname()+")"+"\""+error.getErrordescription()+"\""+":LINE>"+error.getErrorline()+"{"+error.getErrorvalue()+"}"+"]");
    }
    public void MakeError(String ErrorType, String ErrorName, String ErrorLine, String ErrorValue, String ErrorDescription ){
        Error.errortype.add(new ErrorType(ErrorType, ErrorName, ErrorLine, ErrorValue, ErrorDescription, errortype.size()));
        ErrorShow(ErrorName);
    }
    public ArrayList<ErrorType> getErrorTypeList(){ return Error.errortype; }
    public void ErrorShow(String ErrorName){
        /*Error.errortype.stream().filter(error -> (ErrorName.equals(error.getErrorname()))).forEachOrdered(error -> {
            this.ErrorYazdir(error.getErrorID());
        });*/
		//Test Error Problem Test
		this.ErrorYazdir(0);
    }
    
}
