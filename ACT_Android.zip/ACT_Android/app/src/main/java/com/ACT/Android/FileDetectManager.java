package com.ACT.Android;
import android.app.*;
import android.os.*;

public class FileDetectManager extends Activity
{

	@Override
	public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState, persistentState);
		setContentView(R.layout.filedetectmanager);
	}
	
}
