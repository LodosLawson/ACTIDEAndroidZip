package Tehliledici;

import java.io.*;
import java.util.Date;
import java.util.Scanner;

/*import javax.swing.JFileChooser;
import javax.swing.JFrame;

import GUI.IDE.IDE;
*/
import ac.acSystemFayilari;
import Tehliledici.Cesitler.AcarSozler;
import Tehliledici.Tool.Deyisgen;
import Tehliledici.Tool.Fonksiyon;
import Tehliledici.Tool.Error.Error;
import Tehliledici.Tool.FonksiyonDeyisgenleri;
//import backend.Translater;

import java.util.concurrent.TimeUnit;
import com.ACT.Android.Tehliledici.*;

public class ACTehliledici extends Elaveler{
        
    //AC-IDE OZEL BILDIRIM LERI
    public static boolean AC_IDE_BILDIRISI = true;  //GELISDIRICI DURUMUNDA FALSE IDE DURUMUNDA TRUE OLMASI GEREK 
    public static String IDE_DOSYAYOLU = "";
    public static String IDE_DOSYAADI = "";
    
    //OZEL VEZIYET
    private static boolean VARSAYILAN_VEZIYET = true; //NORMAL DURUM VE GELISDIRICI DURUM ARASINDA DEYISIME YARDIMCI OLUR 

    //Linuxs
    private static boolean Linux_ORTAMI_UCUN = true;
	
    //Windows 
    private static String Windows_ORTAMI_GONDERDIYI_DEYER = "";
    
    //MetinTehliledici si icersinde isdifade olunan deyisgenler
    static int Dosya_Basliqlarini_Sayaci = 0;
	
    //MetinIcAlici
    public static boolean PROBLEM_BAYRAGI = false;
    public static boolean Gonderilen_Deyer = false;
    public static boolean Problem_MetinIcAlici = false;

    //MetinTemizle
    static String Temizlenen_iceri;
    static boolean Temizleme_Bayragi = false;
    private static String Temizlenen_bayir;
	
    //JAVA VE C BILDIRIM DEYISGENLERI
    public static boolean JAVAERRORNOTFI = false;
    public static boolean CERRORNOTFI = false;
    //DosyaOxuyucu
    private static String SAFACKOD = "";
	
    //DosyaYazici si icersinde isdifade olunan deyisgenler
    static boolean BILDIRIS_BAYRAGI_C = true;
    static boolean BILDIRIS_BAYRAGI_JAVA = true;
	
    //Yardimci Toolar Ve onlarin Object tanimlamasi
    private static ACT act = new ACT();
    private static Ayrici ayrici = new Ayrici();
    
    //BasliqYoxlayici Deyisgenleri
    //private boolean bayrag_my = true;
	
    //USTGLOBAL DEYISGENLERI 
    public static boolean ustglobal_bayrag = true;		
    //public static String OXUNAN_MELUMAT;
    //public static String SAXLAYICI;
    
    //Isled Ozel Deyisenler
    static boolean Baslad = false;
    
    //Single Isledimde IStiafde OLunmayan BIr Ozeligdir 
    private static int Dosya_Adlarini_Sayaci = 0;

    //AC DILININ DEYISGENLERI
    private static boolean AC_Yzim_Tehliledici_Ucun_Bayrag = true;
	
    //AC PROGRAMLAMA DILINDE ISDIFADE OLUNACAQ AC TEREFINDEN YAZILAN JAVA KITBXANA LARI
    //private static String ELAVE_EDILECEK_AC_KITABXANALARI = "import ac.acGiris;\n";

    //GLOBAL DEYISGENLER
	
    //ONEMLI BAYRAG DEYISGENLERI
    static boolean dosya_bayrag = false; 
    static int dosya_baslanqic = 0;
    private static boolean Bayrag = true;

    //Deyisgennler
    private static int Dongu = 0;
		
    //STRING DEYISGEN
    static String dosya_MELUMAT;
		
    //private static String DOSYA_ADI = "";			
    private static String  OS = System.getProperty("os.name").toLowerCase();

    //Object 
    private static File DOSYA_ACIR;

    //String Array 
    private static String[] Dosya_Adlari = new String[10000];
    private static String[] Dosya_Adlari_Isled = new String[10000];
		
    //int array 
		
    //int 
	
    public static String vaxt() {
        Date Vaxt = new Date();	
        //IDE.ConsolBasliqDaxilEdici(Vaxt.toString());
        Yazdir("\n----------------------------------------------------\n["+Vaxt.toString()+"]", "Consol");
        return "["+Vaxt.toString()+"]";
    }    	

    public ACTehliledici(String AcDosyaYolu, String AcDosyaAdi) {
    	//ACTehliledici nin conustructuru
		//AcFayilAlici();
        DefDeyisenlerAyar();
        //BU AYARLAR DEFAULT OLARAQ HER CAGIRILMADA YAZILMALIDIRLAR BUNLAR UYCUN BIR FONKSIYON YARADAMAQ VE ILK BASA DAXIL ETMEK LAZIMDIR 	
        /*dosya_MELUMAT = "";	
		 Temizlenen_bayir = "";	
		 dosya_bayrag = false; 	
		 Dosya_Basliqlarini_Sayaci = 0;	
		 dosya_baslanqic = 0;	
		 BILDIRIS_BAYRAGI_JAVA = true;	
		 BILDIRIS_BAYRAGI_C = true;	
		 Dosya_Adlari = new String[10000];	
		 Dosya_Adlari_Isled = new String[10000];	
		 Dongu = 0;	
		 Bayrag = false;	
		 PROBLEM_BAYRAGI = false;	
		 Gonderilen_Deyer = false;	
		 Problem_MetinIcAlici = false;	
		 Temizlenen_iceri = "";	
		 Temizleme_Bayragi = false;	
		 */	
        //vaxt();     	
        /*	
		 * BURADA OZEL BIR FONKSIYONLA AC FAYILININ YERINI ALMAQ VE DIZINI ONA GORE TERTIF ETMEK GEREKIR 
		 */	        	
        //Yazdir("Secilen Dosya Cox guman ki Bosdur :"+act.DOSYA_ADI+"\nDosya Yolu :"+act.Dosya_Yolu+"\n");      
        //try { DosyalarinGosderilmesi(); } catch (IOException e) { e.printStackTrace(); } catch (InterruptedException e) { e.printStackTrace(); }    
        if(AC_IDE_BILDIRISI == false) {
            if(Linux_ORTAMI_UCUN == true && VARSAYILAN_VEZIYET == false) {
                DosyaYolu();
                Yazdir("\nAC Fayilinin Adini Daxil Edin :"); 	    	
                //DEYISIGLIK A DA a 	    	
                act.DOSYA_ADI = Isdifadeciden_Oxu(); Yazdir("\n");	    	
                act.DOSYA_ADI+=".ac";                
            } else if(VARSAYILAN_VEZIYET == true){
				// AcFayilAlici();                
            } else {	    		
                DosyaYolu();
                act.DOSYA_ADI = Windows_ORTAMI_GONDERDIYI_DEYER;	    		                
                File fayil = new File(act.DOSYA_ADI); 
                ACT.Dosya_Yolu = fayil.getAbsoluteFile().getParent()+ACT.sla;                
            }                             
        } else {
            act.DOSYA_ADI = AcDosyaAdi;          
            ACT.Dosya_Yolu = AcDosyaYolu;
        }                        	        
        boolean gelen_rapor = DosyaOxuyucu();    	           	               
    	if(gelen_rapor == true) {	    	
            if(Bayrag == true) { 	
                MetinIcAlici();
                //Burada Saf AC kodunu Alinmasi Uycun DIger Elave DIlern Silinmesi Ve ONLARIN		
                //AC Ayiriiya daxil edilmesi gerekr 		
                String Temizlenen = (Temizlenen_bayir+=Temizlenen_iceri);		
                //Yazdir("\n\nTemizlenen : "+"\n"+Temizlenen);
                //Yazdir("\nCixis :\n");	

                //		       
                String Oxudulan = "";
                Scanner oxuyucu = new Scanner(Temizlenen);
                while(oxuyucu.hasNext()){
                    String Line = oxuyucu.nextLine();
                    for(int index = 0; index < Line.length(); index++){
                        String x = String.valueOf(Line.charAt(index));
                        if(!x.equals("")){
                            Oxudulan += Line.substring(index)+"\n";
                            break;
                        }
                    }
                }
                String geridondurulen01 = ayrici.MelumatTanimAyrici(Oxudulan+"\n\nAC-0099898UIOKL-89", "", null);

                Elaveler.YazdirSpesial("234>>"+geridondurulen01);

                boolean bayrag677 = ayrici.MelumatAlici(geridondurulen01, "", null);	

                //for(Fonksiyon f : AcarSozler.FONKSIYONLAR){
                //    if(f != null){
                //      System.out.println("\nFonksiyon Ismi : "+f.getFONKSIYON_ISMI());
                //      System.out.println("\nFOnksiyon Icerigi : "+f.getFONKSIYON_ICERIGI());
                //  }else{
                //      //System.out.print();
                //  } 
                //}
                //if(bayrag677){
				//ayrici.Fonksiyonyoxlayici(Temizlenen);
                //}
                //if(bayrag677 == true){		
				//  if(Baslad == true) {		
				//Isled();			
				// } else {		
				//    Yazdir("\nBir Problem Var 'AC fayili icersinde bir programlama dili yazilib ve bir xeta buraxilib' <<< Isled XETA");			
				//}		
                //}		
                //ayirici.MelumatAlici(Temizlenen);	
                //		    			
                //if(AC_Yzim_Tehliledici_Ucun_Bayrag == true) {
				//ACYazimTehliledici();		    
                //} else {		    				
                //}		       	
                //buradaki sorun budur saxla deyisegni yanliz ustglobal cagirildigi amna isleyir bunu deyismek lazimdir	        
                //buradaki sounu gidermek icin 		
                //BU HISE AC FAYILININ AYIRILMIS HISSESINI GERI QAYTARIR
                if(act.DURUM == false){	        
                    try { Dosya_yaz(SAFACKOD, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }else{	        
                    try { Dosya_yaz(act.SAXLAYICI, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }		
            } else {	 
                String Oxudulan = "";
                Scanner oxuyucu = new Scanner(SAFACKOD);
                while(oxuyucu.hasNext()){
                    String Line = oxuyucu.nextLine();
                    for(int index = 0; index < Line.length(); index++){
                        String x = String.valueOf(Line.charAt(index));
                        if(!x.equals("")){
                            Oxudulan += Line.substring(index)+"\n";
                            break;
                        }
                    }
                }                
                String geridondurulen01 = ayrici.MelumatTanimAyrici(Oxudulan+"\n\nAC-0099898UIOKL-89", "", null);

                boolean bayrag677 = ayrici.MelumatAlici(geridondurulen01, "", null);	

                //if(bayrag677 == true){		
				//  if(Baslad == true) {		
				//Isled();			
				// } else {		
				//}		
                //}		
                //if(AC_Yzim_Tehliledici_Ucun_Bayrag == true) {
				//ACYazimTehliledici();		    
                //} else {		                  
                //}
                //buradaki sorun budur saxla deyisegni yanliz ustglobal cagirildigi amna isleyir bunu deyismek lazimdir	        
                //buradaki sounu gidermek icin 		
                //BU HISE AC FAYILININ AYIRILMIS HISSESINI GERI QAYTARIR
                if(act.DURUM == false){	        
                    try { Dosya_yaz(SAFACKOD, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }else{	        
                    try { Dosya_yaz(SAFACKOD, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }		
            }  	
        } else {   	
            if(Bayrag == true) {   	
                Yazdir("\n Metin ic alici icin bir kod yoxdur ve ya Bir Problem <<< MetinIcAlici XETA ");     		
            } else {   	
                Yazdir("\nBu \""+act.DOSYA_ADI+"\" <<< ac Fayili Sizin Fayilarin arasinda Tapilmadi... Main XETA");    		
            }   	
        }          	   	
        Yazdir("\n\n----------------------------\n AC Compiler V3.0");	
        //ayrici.start();

        IDE_DOSYAADI = "";              
        IDE_DOSYAYOLU = "";	

		// DefDeyisgenlerStopAyar();
    }

   /* public static void DefDeyisgenlerStopAyar(){
        IDE.RUNFLAG = false;
    }*/
    public static void DefDeyisenlerAyar() {
        
        dosya_MELUMAT = "";		
        Temizlenen_bayir = "";	
        dosya_bayrag = false; 	
        Dosya_Basliqlarini_Sayaci = 0;	
        dosya_baslanqic = 0;	
        BILDIRIS_BAYRAGI_JAVA = true;	
        BILDIRIS_BAYRAGI_C = true;	
        Dosya_Adlari = new String[10000];		
        Dosya_Adlari_Isled = new String[10000];	        
        Dongu = 0;		
        Bayrag = false;		       
        PROBLEM_BAYRAGI = false;
        Gonderilen_Deyer = false;	
        Problem_MetinIcAlici = false;	
        Temizlenen_iceri = "";	
        Temizleme_Bayragi = false;
        ustglobal_bayrag = true;           
        JAVAERRORNOTFI = false;
        CERRORNOTFI = false;
        SAFACKOD = "";
        act = new ACT();
        ayrici = new Ayrici();
        Deyisgen.deyigendefault();
        AcarSozler.acarsozlerdefault();
        
        //TEST
        new Error().ErrorTypeDefault();
        
        //IDE.RUNFLAG = true;
		
		//Android Global Deyisgenler
		com.ACT.Android.Tehliledici.ACTehliledici.GlobalOutPut = "";
    }
    
    public static boolean isWindows() {return (OS.indexOf("win") >= 0);}
    public static boolean isMac() {return (OS.indexOf("mac") >= 0);}
    public static boolean isUnix() {return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") > 0 );}
    public static boolean isSolaris() {return (OS.indexOf("sunos") >= 0);}	

    //DUZGUN ISLEYIR TERMINAL BAGLANTI	
    //WINDOWS UYCUN ELAVE EDILMIS V3 FONKSIYONU 
/*
    static void OpenTerminal(String Input, String CompilerFile) {	
            try{          	
                File OUTFILE = new File(ACT.Dosya_Yolu+"javacout.otpt");
               //test 	        
                JFrame f= new JFrame();  	
                 if(Input.equals("Java")) {	
                        if(!JAVAERRORNOTFI){
                                Runtime r = Runtime.getRuntime();
                                r.exec("cmd.exe /c start java "+CompilerFile+"",null, new File(ACT.Dosya_Yolu+"javasc"));
                                while(true){
                                        if(OUTFILE.exists()){       
                                                TimeUnit.SECONDS.sleep(2);
                                                Yazdir(Dosya_oxu(ACT.Dosya_Yolu+"javacout.otpt").replaceFirst("\n", ""), "Consol");
                                                SystsemFayilariOUTFILEDELET(ACT.Dosya_Yolu, ACT.sla);  
                                                break;
                                        }
                                }

                                //Runtime.getRuntime().exec("cmd.exe /c cd "+ACT.Dosya_Yolu+"javasc"+" & start cmd.exe "+" cd "+ACT.Dosya_Yolu+"javasc"+" \"java "+CompilerFile+"\"");	   	    
                                //Runtime.getRuntime().exec("cmd.exe /c cd "+ACT.Dosya_Yolu+"javasc" );
                                //System.out.println("cmd.exe /c cd "+ACT.Dosya_Yolu+"javasc & start cmd.exe /k "+CompilerFile+"");
                                //Runtime.getRuntime().exec("cmd.exe /c cd "+ACT.Dosya_Yolu+"javasc & start cmd.exe /k "+CompilerFile+"");
                                //JOptionPane.showMessageDialog(f,"AC Tehliledici Icersinde Basqa Dil Compiler Olunduqu Uycun AC Tehliledici Dayandi.");  
                        }
                }else if(Input.equals("C")){
                    if(!CERRORNOTFI){
                        Runtime r = Runtime.getRuntime();
                        r.exec("cmd.exe /c start "+CompilerFile+".exe",null, new File(ACT.Dosya_Yolu+"csc"));
                        while(true){
                                if(OUTFILE.exists()){
                                        TimeUnit.SECONDS.sleep(2);
                                        Yazdir(Dosya_oxu(ACT.Dosya_Yolu+"javacout.otpt").replaceFirst("\n", ""), "Consol");
                                        SystsemFayilariOUTFILEDELET(ACT.Dosya_Yolu, ACT.sla);
                                        break;
                                }
                        }
                        //Runtime.getRuntime().exec("cmd.exe /c cd "+ACT.Dosya_Yolu+"\""+"CSC"+"\" & start cmd.exe /k \""+CompilerFile+".exe\"");
                        //JOptionPane.showMessageDialog(f,"AC Tehliledici Icersinde Basqa Dil Compiler Olunduqu Uycun AC Tehliledici Dayandi.");           	   	    
                    }
                }	    
            } 
            catch (Exception e) { 
                System.out.println("Xeta Basverdi <<<<< XETA >>>>> OpenTerminal"); 
                e.printStackTrace();         
            } 	
        }
		*/
	//ELAVE EDILEN WINDOWS OZEL TERMINAL KOD CALISIDIREICI VE DERLEYICI 		
        static void Terminal(String Emeliyat_Emri, String Islenecek_Qovluq) {		        
            Process Emeliyat = null;		    
            try {	    
                Emeliyat = Runtime.getRuntime().exec(Emeliyat_Emri, null, new File(Islenecek_Qovluq));	
                BufferedReader Oxuyucu = new BufferedReader(new InputStreamReader(Emeliyat.getInputStream()));	        
                String Setir = "";	        
                while((Setir = Oxuyucu.readLine()) != null) {	                       	        
                    if(Setir.equals("-")) {	        
                        Yazdir("\ninput lazimdir\n");	    	        
                        //Emeliyat = Runtime.getRuntime().exec("2");		        	        	
                        Oxuyucu = new BufferedReader(new InputStreamReader(Emeliyat.getInputStream()));	        				        	
                    }	        			        
                    Yazdir(Setir,"Consol");	        
                }	       
            } catch (IOException e) {	
                Yazdir("\nBIR PROBLEM VAR... <<< XETA Terminal");		
            }
	}
	///
	static void JavaOzelTerminal(String Emeliyat_Emri) {
            Process Emeliyat = null; try { Emeliyat = Runtime.getRuntime().exec(Emeliyat_Emri); }
		catch (IOException e) {Elaveler.YazdirSpesial(e);	Yazdir("BIR PROBLEMK VAR... ??\"ISLEDME ZAMANI\"?? <<<< XETA TERMINAL COozelTerminal"); e.printStackTrace(); }
            BufferedReader Oxuyucu = new BufferedReader(new InputStreamReader(Emeliyat.getInputStream()));
            String Oxunan = null;
            try { while((Oxunan = Oxuyucu.readLine()) != null) { Yazdir(Oxunan); } 
            } catch (IOException e1) { Elaveler.YazdirSpesial(e1); Yazdir("BIR PROBLEMK VAR... ??\"OXUMA ZAMANI\"?? <<<< XETA TERMINAL COozelTerminal"); e1.printStackTrace(); }
	}
	//ASAQIDAKI STANDAR TERMINAL METODUNAN FERQI C UC7UN YAZILMASIDIR BU HISSEDE UC EDED TERMINAL METODU VAR
	static void COzelTerminal(String Emeliyat_Emri) {
            Process Emeliyat = null; try { Emeliyat = Runtime.getRuntime().exec(Emeliyat_Emri); }
		catch (IOException e) {Elaveler.YazdirSpesial(e);	Yazdir("BIR PROBLEMK VAR... ??\"ISLEDME ZAMANI\"?? <<<< XETA TERMINAL COozelTerminal"); e.printStackTrace(); }
	    BufferedReader Oxuyucu = new BufferedReader(new InputStreamReader(Emeliyat.getInputStream()));
	    String Oxunan = null;
	    try { while((Oxunan = Oxuyucu.readLine()) != null) { Yazdir(Oxunan); } 	
		} catch (IOException e1) { Elaveler.YazdirSpesial(e1); Yazdir("BIR PROBLEMK VAR... ??\"OXUMA ZAMANI\"?? <<<< XETA TERMINAL COozelTerminal"); e1.printStackTrace(); }
	}
	static void Terminal(String Emeliyat_Emri) {	
        Process Emeliyat = null;	
        try {        	
            Emeliyat = Runtime.getRuntime().exec(Emeliyat_Emri);		        	           
            BufferedReader Oxuyucu = new BufferedReader(new InputStreamReader(Emeliyat.getInputStream()));        	                            
            String Setir = "";                        
            while((Setir = Oxuyucu.readLine()) != null) { Yazdir(Setir); } 
        } catch (IOException e) { Elaveler.YazdirSpesial(e); e.printStackTrace(); }
    }   
	
    //Terminal Methodu Sonlandi //
	
    //DUZGUN ISLEYIR | AC Tehlil edicinin oldugu yerdeki ac ve diger dosyalarin gosderen
    /*static String DosyalarinGosderilmesi() throws IOException, InterruptedException {	
        if (isWindows()) { IDE.ConsolBasliqDaxilEdici(vaxt()+Translater.Translater("- Windows Operating System"," - Windwos Emeliyat Systemi"));
        Yazdir("Windwos Emeliyat Systemi.\n----------------------------------------------------", "Consol"); Linux_ORTAMI_UCUN = false; /*Windows_ORTAMI_GONDERDIYI_DEYER = Fayilsec();*//* }
        else if (isMac()) { IDE.ConsolBasliqDaxilEdici(vaxt()+Translater.Translater("- Mac Operating System"," - Mac Emeliyat Systemi"));
             Yazdir("Mac Emeliyat Systemi.\n----------------------------------------------------", "Consol");    Terminal("ls"); }
        else if (isUnix()) { IDE.ConsolBasliqDaxilEdici(vaxt()+Translater.Translater("- Linux Operating System"," - Linux Emeliyat Systemi"));
            Yazdir("Linux Emeliyat Systemi.\n----------------------------------------------------", "Consol"); ACT.sla = '/'; Terminal("ls"); }
        else if (isSolaris()) { Yazdir("Solaris Emeliyat Systemi.\n----------------------------------------------------", "Consol"); }
        else { Yazdir("Sizin Emeliyat Systemi Duzgun Bir System Deyil...\n----------------------------------------------------", "Consol"); }
        return Windows_ORTAMI_GONDERDIYI_DEYER;
    }
	*/
	/*
    public static String Fayilsec() {
    	String Gonderilen = "";
   	JFileChooser FayilarAcVeSec = new JFileChooser("\\C:"); 
    	int returnValue = FayilarAcVeSec.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = FayilarAcVeSec.getSelectedFile();
            Gonderilen = selectedFile.getName();
        } else {
            Yazdir("\nBir Problem Var <<< Fayilsec XETA");
        }     
        return Gonderilen;
    }
    */
    //AC Tehlil edicinin harda oldugunu gosderer
    static String DosyaYolu() {
        String Dosya_Yolunu_Saxlayan = System.getProperty("user.dir");
        Dosya_Yolunu_Saxlayan += "/";
        String toplanan_netice = "";
        int Baslanqic = 0;
	
        int Son	= 0;
        if(isWindows()) {
            for(int Dongu = 0; Dongu <= Dosya_Yolunu_Saxlayan.length(); Dongu++) {
                Baslanqic = MetinAxtarici(Dosya_Yolunu_Saxlayan, '/');
                if(Baslanqic != -1) {
                    String Tutucu_Bir = Dosya_Yolunu_Saxlayan.substring(++Baslanqic, Dosya_Yolunu_Saxlayan.length());		
                    Dosya_Yolunu_Saxlayan = Tutucu_Bir;
                    Son = MetinAxtarici(Tutucu_Bir, '/');
                    if(Son != -1) {
                        String Tutucu_Iki = Tutucu_Bir.substring(0, Son);	
                        toplanan_netice += ("//"+Tutucu_Iki);
                    }
                }
            }
            ACT.Dosya_Yolu = toplanan_netice;
        } else { toplanan_netice = Dosya_Yolunu_Saxlayan; ACT.Dosya_Yolu = toplanan_netice; }	
        return toplanan_netice;
    }
    
    
    //Terminal Yonlendiriciler
    static void DosyaTehliledici(String Dosya_Adi, String Islenecek_Qovluq) { Terminal(Dosya_Adi, Islenecek_Qovluq); }
    static void DosyaBasladici(String Dosya_Adi_Uzantisiz, String Islenecek_Qovluq) { Terminal(Dosya_Adi_Uzantisiz, Islenecek_Qovluq); }
    /*
    public static void AcFayilAlici() {
    	//birtane okuyucu ve direk Dizin Olarak ALmasi gerek buna aslinda boyle yapa bilir menual olarak clisdirib sonra avto rejime sala biliriz 
    	//OLay sudur yer oarakl proje farkli yerden calsiidirilsin ve duzgun islesin     	    	
        String Gonderilen = "";
    	JFileChooser FayilarAcVeSec = new JFileChooser("\\C:");    	 
    	int returnValue = FayilarAcVeSec.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {        
            File selectedFile = FayilarAcVeSec.getSelectedFile();        
            ACT.Dosya_Yolu = selectedFile.getParent()+'/';        
            //act.Dosya_Yolu =selectedFile.getParent()+'/';       
            //Yazdir(""+selectedFile.getPath());        
            act.DOSYA_ADI = selectedFile.getName();        	
        } else {        
            Yazdir("\nBir Problem Var <<< Fayilsec XETA");
        }             
    }
    */
    //Merkezi Basliq Methodu MAIN:fgdg
	
    @SuppressWarnings("deprecation")
	/*
    public static void main(String[] args) throws InterruptedException {
        //AcFayilAlici();
        DefDeyisenlerAyar();
        //BU AYARLAR DEFAULT OLARAQ HER CAGIRILMADA YAZILMALIDIRLAR BUNLAR UYCUN BIR FONKSIYON YARADAMAQ VE ILK BASA DAXIL ETMEK LAZIMDIR 	
        /*dosya_MELUMAT = "";	
        Temizlenen_bayir = "";	
        dosya_bayrag = false; 	
        Dosya_Basliqlarini_Sayaci = 0;	
        dosya_baslanqic = 0;	
        BILDIRIS_BAYRAGI_JAVA = true;	
        BILDIRIS_BAYRAGI_C = true;	
        Dosya_Adlari = new String[10000];	
        Dosya_Adlari_Isled = new String[10000];	
        Dongu = 0;	
        Bayrag = false;	
        PROBLEM_BAYRAGI = false;	
        Gonderilen_Deyer = false;	
        Problem_MetinIcAlici = false;	
        Temizlenen_iceri = "";	
        Temizleme_Bayragi = false;	
        */	
        //vaxt();     	
        /*	
        * BURADA OZEL BIR FONKSIYONLA AC FAYILININ YERINI ALMAQ VE DIZINI ONA GORE TERTIF ETMEK GEREKIR 
        */	        	
        //Yazdir("Secilen Dosya Cox guman ki Bosdur :"+act.DOSYA_ADI+"\nDosya Yolu :"+act.Dosya_Yolu+"\n");      
        //try { DosyalarinGosderilmesi(); } catch (IOException e) { e.printStackTrace(); } catch (InterruptedException e) { e.printStackTrace(); }    
      /*  if(AC_IDE_BILDIRISI == false) {
            if(Linux_ORTAMI_UCUN == true && VARSAYILAN_VEZIYET == false) {
                DosyaYolu();
                Yazdir("\nAC Fayilinin Adini Daxil Edin :"); 	    	
                //DEYISIGLIK A DA a 	    	
                act.DOSYA_ADI = Isdifadeciden_Oxu(); Yazdir("\n");	    	
                act.DOSYA_ADI+=".ac";                
            } else if(VARSAYILAN_VEZIYET == true){
               // AcFayilAlici();                
            } else {	    		
                DosyaYolu();
                act.DOSYA_ADI = Windows_ORTAMI_GONDERDIYI_DEYER;	    		                
                File fayil = new File(act.DOSYA_ADI); 
                ACT.Dosya_Yolu = fayil.getAbsoluteFile().getParent()+ACT.sla;                
            }                             
        } else {
            act.DOSYA_ADI = IDE_DOSYAADI;          
            ACT.Dosya_Yolu = IDE_DOSYAYOLU;
        }                        	        
        boolean gelen_rapor = DosyaOxuyucu();    	           	               
    	if(gelen_rapor == true) {	    	
            if(Bayrag == true) { 	
                MetinIcAlici();
                //Burada Saf AC kodunu Alinmasi Uycun DIger Elave DIlern Silinmesi Ve ONLARIN		
                //AC Ayiriiya daxil edilmesi gerekr 		
                String Temizlenen = (Temizlenen_bayir+=Temizlenen_iceri);		
                //Yazdir("\n\nTemizlenen : "+"\n"+Temizlenen);
                //Yazdir("\nCixis :\n");	
            
                //		       
                String Oxudulan = "";
                Scanner oxuyucu = new Scanner(Temizlenen);
                while(oxuyucu.hasNext()){
                    String Line = oxuyucu.nextLine();
                    for(int index = 0; index < Line.length(); index++){
                        String x = String.valueOf(Line.charAt(index));
                        if(!x.equals("")){
                            Oxudulan += Line.substring(index)+"\n";
                            break;
                        }
                    }
                }
                String geridondurulen01 = ayrici.MelumatTanimAyrici(Oxudulan+"\n\nAC-0099898UIOKL-89", "", null);
                
                System.out.println("234>>"+geridondurulen01);
                
                boolean bayrag677 = ayrici.MelumatAlici(geridondurulen01, "", null);	
                
                //for(Fonksiyon f : AcarSozler.FONKSIYONLAR){
                //    if(f != null){
                //      System.out.println("\nFonksiyon Ismi : "+f.getFONKSIYON_ISMI());
                //      System.out.println("\nFOnksiyon Icerigi : "+f.getFONKSIYON_ICERIGI());
                //  }else{
                //      //System.out.print();
                //  } 
                //}
                //if(bayrag677){
                    //ayrici.Fonksiyonyoxlayici(Temizlenen);
                //}
                //if(bayrag677 == true){		
                  //  if(Baslad == true) {		
                        //Isled();			
                   // } else {		
                    //    Yazdir("\nBir Problem Var 'AC fayili icersinde bir programlama dili yazilib ve bir xeta buraxilib' <<< Isled XETA");			
                    //}		
                //}		
                //ayirici.MelumatAlici(Temizlenen);	
                //		    			
                //if(AC_Yzim_Tehliledici_Ucun_Bayrag == true) {
                    //ACYazimTehliledici();		    
                //} else {		    				
                //}		       	
                //buradaki sorun budur saxla deyisegni yanliz ustglobal cagirildigi amna isleyir bunu deyismek lazimdir	        
                //buradaki sounu gidermek icin 		
                //BU HISE AC FAYILININ AYIRILMIS HISSESINI GERI QAYTARIR
                if(act.DURUM == false){	        
                    try { Dosya_yaz(SAFACKOD, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }else{	        
                    try { Dosya_yaz(act.SAXLAYICI, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }		
            } else {	 
                String Oxudulan = "";
                Scanner oxuyucu = new Scanner(SAFACKOD);
                while(oxuyucu.hasNext()){
                    String Line = oxuyucu.nextLine();
                    for(int index = 0; index < Line.length(); index++){
                        String x = String.valueOf(Line.charAt(index));
                        if(!x.equals("")){
                            Oxudulan += Line.substring(index)+"\n";
                            break;
                        }
                    }
                }                
                String geridondurulen01 = ayrici.MelumatTanimAyrici(Oxudulan+"\n\nAC-0099898UIOKL-89", "", null);
                
                boolean bayrag677 = ayrici.MelumatAlici(geridondurulen01, "", null);	

                //if(bayrag677 == true){		
                  //  if(Baslad == true) {		
                        //Isled();			
                   // } else {		
                    //}		
                //}		
                //if(AC_Yzim_Tehliledici_Ucun_Bayrag == true) {
                    //ACYazimTehliledici();		    
                //} else {		                  
                //}
                //buradaki sorun budur saxla deyisegni yanliz ustglobal cagirildigi amna isleyir bunu deyismek lazimdir	        
                //buradaki sounu gidermek icin 		
                //BU HISE AC FAYILININ AYIRILMIS HISSESINI GERI QAYTARIR
                if(act.DURUM == false){	        
                    try { Dosya_yaz(SAFACKOD, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }else{	        
                    try { Dosya_yaz(SAFACKOD, ACT.Dosya_Yolu+act.DOSYA_ADI ); } catch (IOException e) {}	            
                    //BU HISE PROGRAMIN SONLANDIQDAN SONRA SILINMESI GEREKEN FAYILARI SILER	            
                    SystemFayillariSonSilinenler(true, ACT.Dosya_Yolu, ACT.sla);	            
                }		
            }  	
        } else {   	
            if(Bayrag == true) {   	
                Yazdir("\n Metin ic alici icin bir kod yoxdur ve ya Bir Problem <<< MetinIcAlici XETA ");     		
            } else {   	
                Yazdir("\nBu \""+act.DOSYA_ADI+"\" <<< ac Fayili Sizin Fayilarin arasinda Tapilmadi... Main XETA");    		
            }   	
        }          	   	
        Yazdir("\n\n\"ACTehliledici V3.0\" \n--------------------------\nwww.mehemmedac.ga");	
        //ayrici.start();
        
        IDE_DOSYAADI = "";              
        IDE_DOSYAYOLU = "";	

       // DefDeyisgenlerStopAyar();
    }
	*/
    //DUZGUN ISLEYIR | METININ DOLU OLUB OLMADIGINI YOXLAYARAQ TEHLILIN BOLUNMASINI YONLENDIRIR
    static boolean Tehliledici_(String MELUMAT, String DOSYA_BUTUN_ICERISI) {
    	boolean ozelbayrag = false;
    	if (!MELUMAT.equals("")) {
            YazdirSpesial("\nBOS-DEYIL <<< Tehliledici_\n---------------------------------------------------------");
            ozelbayrag = MetinTehliledici(MELUMAT, DOSYA_BUTUN_ICERISI); 
    	} else { 
            YazdirSpesial("\nBOSDUR <<< Tehliledici_");
    	} 	
    	return ozelbayrag;
    }
	
    //Isled FOnksiyon Algoritmasi SInda Yenilenme OLunmalidir 
    //BU yenilenme  Isled FA yi Kopyalamaya Ehdiyac Duyur...
    public static boolean Isled(String Single_Setir) {
        String MELUMAT = "";	
        String Tapilan_Deyer = "";	
        int Tapilan_Deyerin_Indexi;
        boolean Gerigonderilen_Deyer = false;			
        try {	
            //BURADAN	
            //LineNumberReader Setir_Oxuyuc = new LineNumberReader(new InputStreamReader(new FileInputStream(act.DOSYA_ADI), "UTF-8"));         
            //while (((MELUMAT = Setir_Oxuyuc.readLine()) != null) && Setir_Oxuyuc.getLineNumber() <= 1000000){	
            //BBURAYA QEDER WHILE SILINEREK YERINE SINGLE ALIM GELECEY 	
            MELUMAT = Single_Setir;	
            Tapilan_Deyerin_Indexi = MetinAxtarici(MELUMAT, '#');        
            if(Tapilan_Deyerin_Indexi != -1) {        
                Tapilan_Deyer = Character.toString(MELUMAT.charAt(Tapilan_Deyerin_Indexi));        	
                if(Tapilan_Deyer.equals("#")) {        	
                    int son = MetinAxtarici(MELUMAT, ';');        	
                    if(son != -1) {            	
                        Dosya_Adlarini_Sayaci++;            		
                        Gerigonderilen_Deyer = true;        		
                        String Oturucu = MELUMAT.substring(++Tapilan_Deyerin_Indexi, son);        		
                        Dosya_Adlari_Isled[1] = Oturucu;	//single and multi error <Dosya_Adlarini_Sayaci>        		
                    }else{		
                        return Gerigonderilen_Deyer;		
                    }        	
                }        	
            }        		
            
        //}    	
        if(Gerigonderilen_Deyer == true) {
            for(int Dongu = 1; Dongu <= Dosya_Adlari.length; Dongu++ ) {	    
                if(Dosya_Adlari[Dongu] != null) {
                    for(int Ic_Dongu = 1; Ic_Dongu <= Dosya_Adlari_Isled.length; Ic_Dongu++) {	        
                        if(Dosya_Adlari_Isled[Ic_Dongu] != null) {	        					        	
                            if(Dosya_Adlari[Dongu].equals(Dosya_Adlari_Isled[Ic_Dongu])) {	        	                                
                                int Uzanti = MetinAxtarici(Dosya_Adlari_Isled[Ic_Dongu], '.');	        		
                                String Uzanti_Tutucu = Dosya_Adlari_Isled[Ic_Dongu].substring(++Uzanti);	        		
                                if(Uzanti_Tutucu.equals("java")) {	        		
                                    if(isUnix()) {	        		
                                        String Dosya_Adi_Uzantisiz = Dosya_Adlari_Isled[Ic_Dongu].substring(0, --Uzanti);		        		
                                        DosyaBasladici("java "+Dosya_Adi_Uzantisiz, act.Dosya_Yolu+"javasc");//./javasc default	        			
                                    }else if(isWindows()){	        		
                                        Yazdir("birdefe");	        			
                                        String Dosya_Adi_Uzantisiz = Dosya_Adlari_Isled[Ic_Dongu].substring(0, --Uzanti);	        			
                                        Yazdir("Iki defe Isleyib Islamedigini Yoxlar \n");	        			
                                      //  OpenTerminal("Java", Dosya_Adi_Uzantisiz);	        			
                                    }     								        		
                                } else if(Uzanti_Tutucu.equals("c")) {	        		
                                    String Dosya_Adi_Uzantisiz = Dosya_Adlari_Isled[Ic_Dongu].substring(0, --Uzanti);	        		
                                    if(isUnix()) {	        		
                                        DosyaBasladici("./"+Dosya_Adi_Uzantisiz, act.Dosya_Yolu+"./csc");///./csc default	        			
                                    } else if(isWindows()) {	        		
                                      //  OpenTerminal("C", Dosya_Adi_Uzantisiz);	        			
                                    } else {	        		
                                        Yazdir("\nIsletim Systeminde Bir Problem Var");	        			                                  
                                    }	        		
                                } else {        		
                                    Yazdir("\n PROBLEM Daxil olunan Uzanti Yanlisdir : "+Uzanti); Yazdir(" <<< Isled XETA");     		
                                }      		
                            }    	
                        } else { break; }       	
                    }        
                }        
                else { break; }	        
            }       
        }       
        //Setir_Oxuyuc.close();     
        } catch (/*FileNotFoundException e*/ Exception e) {       
            Elaveler.YazdirSpesial("\nFayil Tapilmadi... <<< MetinTehliledici XETA.");        
        } /*catch (/*IOException e Exception e) { 
            System.err.println("\nFayil Tapilmadi... <<< MetinTehliledici XETA."); 
            }*/		
        return Gonderilen_Deyer;	
    }
     
    public static boolean DosyaYazici(String DOSYA_ADI, String DOSYAYA_YAZILACAQ) {
    	boolean PROBLEM_BAYRAGI = false;
    	
    	int Uzanti = MetinAxtarici(DOSYA_ADI, '.');
    	String Cixti_Yoxlayici = DOSYA_ADI.substring(0, Uzanti);
    	String Dosya_Uzantisi = DOSYA_ADI.substring(++Uzanti);
    	
    	if(Dosya_Uzantisi.equals("java")) {	    		
                    SystemFayilarininYoxlanilmasi("java", ACT.Dosya_Yolu, ACT.sla);    	    	
                    File Temizlenen_classlar = new File(ACT.Dosya_Yolu+ACT.sla+"javasc"+ACT.sla+Cixti_Yoxlayici+".class");    	
                    if(Temizlenen_classlar.delete()) { }    	               	
                    File DOSYA = new File(ACT.Dosya_Yolu+ACT.sla+"javasc"+ACT.sla+DOSYA_ADI);    	
                    try {    	
                        DOSYA.createNewFile();    		
                        try(BufferedWriter Yazici = new BufferedWriter(new FileWriter(DOSYA))){    		
                            String ELAVE_EDILECEK_AC_KITABXANALARI = "import ac.acGiris.*;\nimport ac.acElaveler.*;\n";    		
                            //+ "import ac.acElaveler;";    		
                            Yazici.write((ELAVE_EDILECEK_AC_KITABXANALARI+DOSYAYA_YAZILACAQ));    		
                            Yazici.close();    		
                            if(BILDIRIS_BAYRAGI_JAVA == true) { Yazdir("\nJAVA : Ugurla .java fayilina yazildi"); }    		
                            DosyaTehliledici("javac "+DOSYA_ADI, ACT.Dosya_Yolu+"javasc");///javac default    		
                            File doysa_java_class = new File(ACT.Dosya_Yolu+ACT.sla+"javasc"+ACT.sla+Cixti_Yoxlayici+".class");    		
                            if(!doysa_java_class.exists()) {    		
                                Yazdir("\nJAVA : Tehlili zamani <<< DosyaYazici.DosyaTehliledici PROBLEM VAR");    
                                JAVAERRORNOTFI = true;
                            } else {    		
                                Yazdir("\nJAVA : Ugurla Tehlil Edildi.");    			
                            }    		
                            BILDIRIS_BAYRAGI_JAVA = false;    		
                        }/* catch (IOException e) {   		
                            Yazdir("\nPROBLEM VAR");   		
                        } 		*/
                    } catch(IOException e) {   
						Elaveler.YazdirSpesial(e);
                        Yazdir("\nDosya Yaradilarken Xeta Bas Verdi <<< DosyaYazici XETA");   		
                    }            	
            } else if(Dosya_Uzantisi.equals("c")) {// C DOSYA YAZICI VE TEHLIL EDICI ICERSINDEKI DEYISIKLIK SEBEBI WINDOWS ICERSINDEKI STANDART AYARLARDIR 	
                SystemFayilarininYoxlanilmasi("c", ACT.Dosya_Yolu, ACT.sla);	   	    
                File Temizlenen_cprogramlari = new File(ACT.Dosya_Yolu+ACT.sla+"csc"+ACT.sla+Cixti_Yoxlayici);	    
                if(Temizlenen_cprogramlari.delete()) { } 	               
                File DOSYA = new File(ACT.Dosya_Yolu+"csc"+ACT.sla+DOSYA_ADI);	    
                try {	    
                    DOSYA.createNewFile();	    	
                    try(BufferedWriter br = new BufferedWriter(new FileWriter(DOSYA))){  		
                        if(BILDIRIS_BAYRAGI_C == true) { Yazdir("\nC		: Ugurla .c fayilina yazildi"); }	    	
                        String ELAVE_EDILECEK_AC_C_KITABXANASI = acSystemFayilari.SystemFayileriCInPackage(isWindows());	    	
                        br.write(ELAVE_EDILECEK_AC_C_KITABXANASI+DOSYAYA_YAZILACAQ);	    	
                        br.close();	    	
                        String Tutucu = DOSYA_ADI.substring(0, --Uzanti);		    	
                        /*	    	
                        * Windows icersinde DosyaTehliledici problem cixarir Problem N:00078 //Proglem P:"GCC WINDWOS ICERSIDNE YOXDU"	    	
                        * Yeni Widnows Problemi N:00067 Bu problem widnows icerisinde c nin system() fonksiyonunun Isdifade elemir 	    
                        */	    	
                        if(isWindows() == true) {	    	
                            //BURADA DUZELIS OLMALIDIR C HEADER FAYILARINI ISLEDMEK UCUN C FAYILARINI
                            //C NIN OLDUQU YERE ELAVE ET
                       
                            DosyaTehliledici("gcc -o "+Tutucu+" "+DOSYA_ADI+" "+" acos_technology.c", ACT.Dosya_Yolu+"csc");
                            File doysa_C_exe = new File(ACT.Dosya_Yolu+ACT.sla+"csc"+ACT.sla+Cixti_Yoxlayici+".exe ");
                            if(!doysa_C_exe.exists()) {
                                Yazdir("\nC : Tehlili zamani <<< DosyaYazici.DosyaTehliledici PROBLEM VAR");
                                CERRORNOTFI = true;
                            } else {
                                Yazdir("\nC : Ugurla Tehlil Edildi.");
                            }
                        }else {
                            DosyaTehliledici("gcc -o "+Tutucu+" "+DOSYA_ADI+" "+"./ac_c_ozel_kitabxana"+ACT.sla+"acos_technology.c", ACT.Dosya_Yolu+"csc");
                            File doysa_java_class = new File(ACT.Dosya_Yolu+ACT.sla+"csc"+ACT.sla+Cixti_Yoxlayici);
                            if(!doysa_java_class.exists()) {
                                Yazdir("\nC : Tehlili zamani <<< DosyaYazici.DosyaTehliledici PROBLEM VAR");
                            } else {
                                Yazdir("\nC : Ugurla Tehlil Edildi.");
                            }	    		
                        }	    	
                        BILDIRIS_BAYRAGI_C = false;	    	
                    }/* catch (IOException e) {            
                        Yazdir("\nPROBLEM VAR");	    	
                    }	    	*/
                } catch(IOException e) {	    
					Elaveler.YazdirSpesial(e);
                    Yazdir("\nDosya Yaradilarken Xeta Bas Verdi <<< DosyaYazici XETA");	    	
                }  	
            } else { Yazdir("\nDuzgun Fayil Uzantisi Yazin. <<< DosyaYazici XETA	: PROBLEM	: "+Dosya_Uzantisi); PROBLEM_BAYRAGI = true; }    
        SystemFayilarininSilinmesi(ACT.Dosya_Yolu, ACT.sla);	
        return PROBLEM_BAYRAGI;
    }
   
  	//DUZGUN ISLEYIR | ILK ISLEYEN METHODUR TEHLIL EDICINI CAGIRIR
    static boolean DosyaOxuyucu(){
        String      OXUNAN_MELUMAT;
        char[]      OXUYUCU_VE_TUTUCU;
        boolean     XETA = false;
        boolean     Xeta = false;
        FileReader  DOSYA_OXU;
        try{
            DOSYA_ACIR          = new File(ACT.Dosya_Yolu+act.DOSYA_ADI);///act.dosyaadi default
            DOSYA_OXU           = new FileReader(DOSYA_ACIR);
            OXUYUCU_VE_TUTUCU   = new char[(int)DOSYA_ACIR.length()];	
            //.ac Fayilini varligi yoxlandiqdan sonra Oxuma islemi heyata kecir
            try { DOSYA_OXU.read(OXUYUCU_VE_TUTUCU); } catch(IOException e) { e.printStackTrace(); XETA = true; }
            OXUNAN_MELUMAT = new String(OXUYUCU_VE_TUTUCU);
            //AKTARIM YEDEK ALMA 
            SAFACKOD = OXUNAN_MELUMAT;
            //\
            Xeta = Tehliledici_(OXUNAN_MELUMAT, OXUNAN_MELUMAT);   
            DOSYA_OXU.close();
        } catch(Exception e) {	if(XETA == true ) {Elaveler.YazdirSpesial(e); Yazdir("\nFayilnan Bagli Bir Problem Var <<< DosyaOxuyucu XETA"); } }
        return 	Xeta;
    }      
  //TAM OLARAQ DUZGUNLUK YOXLANISI OLUNMAYIB AMA METIN ISLEMEDE ISDIFADE OLUNACAQ <<< MELUMAT
    static boolean MetinTehliledici(String MELUMAT, String DOSYA_BUTUN_ICERISI) {      	
        String	Tapilan_Deyer;   	
        int 	Tapilan_Deyerin_Indexi, Tapilan_Deyerin_Indexi_iki;     
        try { 	
            LineNumberReader Setir_Oxuyuc = new LineNumberReader(new InputStreamReader(new FileInputStream(ACT.Dosya_Yolu+act.DOSYA_ADI), "UTF-8")); ///act.dosyaadi default       
            while (((MELUMAT = Setir_Oxuyuc.readLine()) != null) && Setir_Oxuyuc.getLineNumber() <= 10001){   	
                Gonderilen_Deyer = true;       	
                Tapilan_Deyerin_Indexi = MetinAxtarici(MELUMAT, '<');       	
                Tapilan_Deyerin_Indexi_iki = MetinAxtarici(MELUMAT, '>');             
                if(Tapilan_Deyerin_Indexi != -1 || Tapilan_Deyerin_Indexi_iki != -1) {	        
                    AC_Yzim_Tehliledici_Ucun_Bayrag = false;	        
                }	        		        
                if(ustglobal_bayrag = true) {	    
                    if(Tapilan_Deyerin_Indexi != -1){	            
                        boolean ustglobal_ucun_gelen_deyer = act.UstglobalYoxlayici(MELUMAT, Tapilan_Deyerin_Indexi);		        
                        if(ustglobal_ucun_gelen_deyer == true) {		        
                            ustglobal_bayrag = false;		        
                        }	        	             
                    }	        
                }	        		                      
               // Yazdir("\n>>>"+MELUMAT);        
    
                if(Tapilan_Deyerin_Indexi != -1) {	        
                    int index_oturucu = Tapilan_Deyerin_Indexi;	
                  // String tutucu = MELUMAT;
                    //Yazdir("\n>>>"+tutucu);        

                    boolean gelen_deyer = BasliqYoxlayici(MELUMAT, ++index_oturucu);	        
                    if(gelen_deyer == true) {	        
                        Tapilan_Deyer = Character.toString(MELUMAT.charAt(Tapilan_Deyerin_Indexi));	        	
                        if(Tapilan_Deyer.equals("<")) {	            	
                            Dosya_Basliqlarini_Sayaci++;		        
                            String Oturucu = YazimYoxlayicisi(MELUMAT, 1);		        
                            Dosya_Adlari[Dosya_Basliqlarini_Sayaci] = Oturucu;        						        
                            Gonderilen_Deyer = true;		        
                            Bayrag = true;
                        }
                    } 
                }  	 
            }
            Setir_Oxuyuc.close();
        } catch (FileNotFoundException e) {
            Elaveler.YazdirSpesial("\nFayil Tapilmadi...	<<< MetinTehliledici XETA."+e);
        } catch (IOException e) {       
            Elaveler.YazdirSpesial("\nFayil Tapilmadi...	<<< MetinTehliledici XETA."+e); 
        } catch (Exception e){
			Elaveler.YazdirSpesial(e);
            e.printStackTrace();
        }
        return Gonderilen_Deyer;
    }
    
    //DUZGU ISLEYIR | VE BIR .ac UZANTI DOSYASI ICERSINDE JAVA VE YA C CODU YAZILIB YAZILMADIGINI YOXLAYARAQ ONLARI TEHLIL EDER
    public static String MetinIcAlici() {
    	Baslad = true;

    	File    Dosya_Acici;
    	FileReader  Fayili_Oxuycu; 
    	char[] Stringe_Donusduruc;
    	
    	String GERI_DONDURULEN = "";
    	String MELUMAT_TUTUCU  = "";
    	String Tapilan_Deyer_Baslanqic;
    	String Tapilan_Deyer_Son;
    	
    	if(Dongu != Dosya_Basliqlarini_Sayaci) {
	        if(dosya_bayrag == false) {
                try {
                    //dosyaadi
                    Dosya_Acici	= new File(ACT.Dosya_Yolu+ACT.sla+act.DOSYA_ADI);///act.dosyaadi default
                    Fayili_Oxuycu = new FileReader(Dosya_Acici); 
                    Stringe_Donusduruc = new char[(int) Dosya_Acici.length()];
					
                    try { Fayili_Oxuycu.read(Stringe_Donusduruc); Fayili_Oxuycu.close(); } catch (IOException e ) { Elaveler.YazdirSpesial(e); e.printStackTrace();  Yazdir("\nPROBLEM VAR"); }	
						    		
                    MELUMAT_TUTUCU = new String(Stringe_Donusduruc);
							    		
                    int Tapilan_Deyerler_Baslanqic = MetinAxtarici(MELUMAT_TUTUCU, '<'); 
                    int Tapilan_Deyerler_Son = MetinAxtarici(MELUMAT_TUTUCU, '>'); 
                    int index_oturucu_basliq = Tapilan_Deyerler_Baslanqic;
                            
                    boolean gelen_deyer_baslanqicucun = BasliqYoxlayici(MELUMAT_TUTUCU, ++index_oturucu_basliq);
                    if(gelen_deyer_baslanqicucun == true) {
                        //Algoritmayi bura yaza bilersiniz ve ya metodu bura yaza bilersiniz 
	    		        Tapilan_Deyerler_Son = MetinSonuYoxlayici(MELUMAT_TUTUCU);	    
                        try {
                            Temizlenen_iceri = act.MetinTemizleyici(MELUMAT_TUTUCU, --Tapilan_Deyerler_Baslanqic, Tapilan_Deyerler_Son);
                        } catch(Exception e) {
							Elaveler.YazdirSpesial(e);
                            Yazdir("\nProgram Icersinde AC Kod yazilmayib...");
                        }   
                        if(Tapilan_Deyerler_Baslanqic != -1 && Tapilan_Deyerler_Son != -1) {
                            Tapilan_Deyer_Baslanqic = Character.toString(MELUMAT_TUTUCU.charAt(Tapilan_Deyerler_Baslanqic));
			                Tapilan_Deyer_Son = Character.toString(MELUMAT_TUTUCU.charAt(Tapilan_Deyerler_Son));
                            if(Tapilan_Deyer_Baslanqic.equals("<") || Tapilan_Deyer_Son.equals(">")) { 
                                ++Dongu;			    			
                                GERI_DONDURULEN = MELUMAT_TUTUCU.substring(++Tapilan_Deyerler_Baslanqic, 2+Tapilan_Deyerler_Son); 				    				
                                int Axtarici_Basliq = MetinAxtarici(GERI_DONDURULEN, ':');
                                int Axtarici_Son = MetinAxtarici(GERI_DONDURULEN, ';');    				
                                String Oturucu = null;
                                try { Oturucu = GERI_DONDURULEN.substring(2+Axtarici_Basliq, Axtarici_Son); } catch(Exception e) { Elaveler.YazdirSpesial(e); Problem_MetinIcAlici = true; }
	   			                if(Problem_MetinIcAlici != true) {
                                    if(Dosya_Adlari[Dongu].equals(Oturucu)) {
                                        int Oturulecek_Metin_Sonu = MetinSonuYoxlayici(GERI_DONDURULEN);
                                            Oturulecek_Metin_Sonu -= 6;
                                        String Oturulecek_Metin = GERI_DONDURULEN.substring(++Axtarici_Son, Oturulecek_Metin_Sonu);
				                    	PROBLEM_BAYRAGI = DosyaYazici(Dosya_Adlari[Dongu], Oturulecek_Metin);	
                                    }			    				
				                    if(PROBLEM_BAYRAGI == false) {
		  			                    dosya_baslanqic = Tapilan_Deyerler_Son;
                                        dosya_MELUMAT = Temizlenen_iceri;						    			
                                        dosya_bayrag = true;	    			
                                        MetinIcAlici();			
                                    } else {				    	
                                        Yazdir("\nBir Problem Var <<< MetinIcAlici Birinci bolum XETA");				    	
                                    }  				   
                                }				
                            } else {
                                GERI_DONDURULEN = "\nYAZI SEHFI"; Yazdir("Yazim Sehfi Var <<< MetinIcAlici XETA");				
                            }
                        } else {			
                            Yazdir("\nYazim Sehfi <<< MetinIcAlici XETA");
                        } 	    		
                    } else {	    				
                        Temizlenen_bayir = MELUMAT_TUTUCU.substring(0, Tapilan_Deyerler_Baslanqic);	    				                                                             
                        dosya_MELUMAT = MELUMAT_TUTUCU.substring(++Tapilan_Deyerler_Baslanqic);	    		
                        dosya_bayrag = true;	    		
                        MetinIcAlici();	    		
                    }		
                } catch (FileNotFoundException e1) { e1.printStackTrace(); Elaveler.YazdirSpesial(e1); Yazdir("\nPROBLEM VAR"); }    		    	
            } else {	                	    	
                int Tapilan_Deyerler_Baslanqic	= MetinAxtarici(dosya_MELUMAT, '<'); 	    	
                int Tapilan_Deyerler_Son		= MetinAxtarici(dosya_MELUMAT, '>'); 	    	
                int index_oturucu_basliq = Tapilan_Deyerler_Baslanqic;	    	                	    	
                boolean gelen_deyer_baslanqicucun = BasliqYoxlayici(dosya_MELUMAT, ++index_oturucu_basliq );   		
                if(gelen_deyer_baslanqicucun == true) {		
                    //Algoritmayi bura yaza bilersiniz ve ya metodu bura yaza bilersiniz  		
                    Tapilan_Deyerler_Son = MetinSonuYoxlayici(dosya_MELUMAT);   		
                    Temizlenen_iceri = act.MetinTemizleyici(dosya_MELUMAT, --index_oturucu_basliq, Tapilan_Deyerler_Son);		    
                    if(Tapilan_Deyerler_Baslanqic != -1 && Tapilan_Deyerler_Son != -1) {		    					    
                        Tapilan_Deyer_Baslanqic	= Character.toString(dosya_MELUMAT.charAt(Tapilan_Deyerler_Baslanqic));		    	
                        Tapilan_Deyer_Son		= Character.toString(dosya_MELUMAT.charAt(Tapilan_Deyerler_Son));		    	
                        if(Tapilan_Deyer_Baslanqic.equals("<") || Tapilan_Deyer_Son.equals(">")) { 		    	
                            ++Dongu;		    	
                            try {		    	
                                GERI_DONDURULEN = dosya_MELUMAT.substring(++Tapilan_Deyerler_Baslanqic, 2+Tapilan_Deyerler_Son);		    						    		
                            } catch(StringIndexOutOfBoundsException e) {	
								Elaveler.YazdirSpesial(e);
                                Yazdir("\nProblem Tehliledici Sonlandirildi <<< MetinIcAlici XETA ");		    		
                                System.exit(0);		    		
                            }		    	
                            int Axtarici_Basliq = MetinAxtarici(GERI_DONDURULEN, ':');		    	
                            int Axtarici_Son = MetinAxtarici(GERI_DONDURULEN, ';');		    						    	
                            String Oturucu = "bosdur";		    	
                            try {		    	
                                Oturucu = GERI_DONDURULEN.substring(2+Axtarici_Basliq, Axtarici_Son);		    		
                            } catch(Exception e) { Elaveler.YazdirSpesial(e); Problem_MetinIcAlici = true; }		    	
                            if(Problem_MetinIcAlici != true) {			    
                                try {				
                                    if(Dosya_Adlari[Dongu].equals(Oturucu)) {
                                        int Oturulecek_Metin_Sonu = MetinSonuYoxlayici(GERI_DONDURULEN);				    	
                                        Oturulecek_Metin_Sonu -= 6;				    	
                                        String Oturulecek_Metin = GERI_DONDURULEN.substring(1+Axtarici_Son, Oturulecek_Metin_Sonu);				    	
                                        PROBLEM_BAYRAGI = DosyaYazici(Dosya_Adlari[Dongu], Oturulecek_Metin);				    	
                                    }			    	
                                } catch(Exception e){Elaveler.YazdirSpesial(e); Yazdir("\nDosya adlarinda problem var <<< MetinIcAlici XETA"+"\nPROBLEM : "+Oturucu); }			    	
                                if(PROBLEM_BAYRAGI == false) {				
                                    dosya_baslanqic = Tapilan_Deyerler_Son;
                                    dosya_MELUMAT = Temizlenen_iceri;				    
                                    MetinIcAlici();			    	
                                } else {			    	
                                    Yazdir("\nBir Problem Var <<< MetinIcAlici Ikinci bolum XETA");			    	
                                }
                            } else {
                                int Temizlene_Deyer_Saxlayici = Temizlenen_iceri.length();
                                dosya_MELUMAT = Temizlenen_iceri.substring(++Tapilan_Deyerler_Baslanqic, Temizlene_Deyer_Saxlayici);			    	
                                MetinIcAlici();			    	
                            }		    	
                        } else {		    	
                            GERI_DONDURULEN = "\nYAZI SEHFI"; Yazdir("Yazim Sehfi Var <<< MetinIcAlici XETA");		    	
                        }		    	
                    } else {		    
                        Yazdir("\nYazim Sehfi <<< MetinIcAlici XETA");		    	
                    }			    
                } else {		
                    Temizlenen_bayir += dosya_MELUMAT.substring(0, ++index_oturucu_basliq);
                    dosya_MELUMAT = dosya_MELUMAT.substring(1+Tapilan_Deyerler_Baslanqic);
                    MetinIcAlici();
                }	
            }
        }	
        return "";
    }
    
    public static boolean BasliqYoxlayici(String MELUMAT, int Basliq) {
        boolean Gonderilecek_deyer = false;    	int Son = MetinAxtarici(MELUMAT, ':');
        if(Son <= Basliq){

        }else{    
            if(Son != -1) {
                String Yoxlayici = MELUMAT.substring(Basliq, Son);
            if(Yoxlayici.equals("BASLANQIC JAVA")) {
                Gonderilecek_deyer = true;
            } else if(Yoxlayici.equals("BASLANQIC C")) {
                Gonderilecek_deyer = true;
            }
            } else {
                Gonderilecek_deyer = false;
            }
        }
    	return Gonderilecek_deyer;
    }
    
    public static int MetinSonuYoxlayici(String Metin) {
 
    	//Integer Deyisgenler
    	int Dondurulen = 0;
    	int Tapilan_Deyerin_Indexi;
    	int Toplanan_Deyer = 0;
    	int DONUS_lIMITI = 0;
    	
    	//Boolean Deyisgenler
    	boolean bayrag = true;
    	
    	//Dongu
    	while(bayrag == true) {
            ++DONUS_lIMITI;
            Tapilan_Deyerin_Indexi = MetinAxtarici(Metin, '>');
            if(Tapilan_Deyerin_Indexi != -1) {
    		int deyer_tutucu = Tapilan_Deyerin_Indexi;
    		deyer_tutucu-=6;
    		String Yoxlayici;
    		if(deyer_tutucu <= 6 ) {
                    Yoxlayici = "XETA";
    		} else {
                    Yoxlayici = Metin.substring(deyer_tutucu, Tapilan_Deyerin_Indexi);    		
    		}
    		if(Yoxlayici.equals("SON AC")) {
                    Dondurulen += ((Tapilan_Deyerin_Indexi += Toplanan_Deyer));
    			break;
                } else {
                    ++Dondurulen;
                    Toplanan_Deyer += Tapilan_Deyerin_Indexi;
                    Metin = Metin.substring(++Tapilan_Deyerin_Indexi);
    		}
            } else {   
                }
            if(DONUS_lIMITI == 1000000000) {
                Yazdir("\nProblem Sonsuz Dongu <<< MetinSonuYoxlayici XETA");
                break;
            }
    	} 	
    	return Dondurulen;
    }
    
	//DUZGUN ISLEYIR |
    public static String YazimYoxlayicisi(String MELUMAT_TUTUCU, int Axtarilacaq_Soz_Basliq) {
        int SON = MetinAxtarici(MELUMAT_TUTUCU, ':'); String Basliq = MELUMAT_TUTUCU.substring(Axtarilacaq_Soz_Basliq, SON);
        //if(SON <= Axtarilacaq_Soz_Basliq){Yazdir("\nBALCADIR"+SON+":"+Axtarilacaq_Soz_Basliq);}else{Yazdir("\nBOYUKDUR"+SON+":"+Axtarilacaq_Soz_Basliq);}
    	String Gonderilecek = "";
     	if(Basliq.equals("BASLANQIC JAVA")) {
     		int Dosya_Adi_Son = MetinAxtarici(MELUMAT_TUTUCU, ';'); String JAVA_DOSYA_ADI = MELUMAT_TUTUCU.substring(2+SON, Dosya_Adi_Son);
            if(Dosya_Adi_Son != -1) {
    		//DOSYA_ADI BASQA BIR METHODA GONDERILECEK DUZGUN ISLEYIRE |
    		Gonderilecek = JAVA_DOSYA_ADI;
            } else { Yazdir("\nJava Dosya Adini Vererken Sonuna ';' QOYMAQI UNUTMAYIN <<< Yazim_Yoxlayicisi XETA\n"); }
    	} else if(Basliq.equals("BASLANQIC C")) {
            if(isWindows()) {
                     
                //Yazdir("\n\n<<<XETA>> WiNDOWS ISLETIM SYSTEMINDE C CEKIRDEK \nSORUNU YUZUNDEN HATA VERDI LUTFEN WINDOWS SYSTEMINDE C TANIMI YAPMAYINIZ\n\n");     
                //Yazdir("\n\n<<<XETA>> WiNDOWS ISLETIM SYSTEMINDE C CEKIRDEK \nSORUNU YUZUNDEN HATA VERDI LUTFEN WINDOWS SYSTEMINDE C TANIMI YAPMAYINIZ\n\n");
                //Bu sorunu Dogru bir yerde vermek gerek
                //once gcc nin lup olmadigini kotrol edib daha sonra bayrag iyle buraya yonlendirmek gerek ve sorun yoksa duzgun sorun varsa 
                //yukardaki hata bildirisin ekrana versin 
                //bu hata java icin de gecerlidir
                
                int Dosya_Adi_Son = MetinAxtarici(MELUMAT_TUTUCU, ';'); String JAVA_DOSYA_ADI = MELUMAT_TUTUCU.substring(2+SON, Dosya_Adi_Son);
                if(Dosya_Adi_Son != -1) {
                    //DOSYA_ADI BASQA BIR METHODA GONDERILECEK DUZGUN ISLEYIRE |
                    Gonderilecek = JAVA_DOSYA_ADI;
	    	}
                
            } else {
                int Dosya_Adi_Son = MetinAxtarici(MELUMAT_TUTUCU, ';'); String JAVA_DOSYA_ADI = MELUMAT_TUTUCU.substring(2+SON, Dosya_Adi_Son);
	    	if(Dosya_Adi_Son != -1) {
                    //DOSYA_ADI BASQA BIR METHODA GONDERILECEK DUZGUN ISLEYIRE |
                    Gonderilecek = JAVA_DOSYA_ADI;
	    	} else { Yazdir("\nC Dosya Adini Vererken Sonuna ';' QOYMAQI UNUTMAYIN <<< Yazim_Yoxlayicisi XETA\n"); }
            }
    	} else { Yazdir("\nYazim Sehfi Var <<< Yazim_Yoxlayicisi XETA\n");}
     	return Gonderilecek;
    }
    
    public static boolean ACYazimTehliledici(String AC_Def_Setir, String TPP_MELUMAT, boolean Alinan_Deger, String Mod, Fonksiyon fonksiyon, boolean TYT){
        boolean Gonderilen_Deger = true;
         
        String[] KEYWORD_AS = AcarSozler.KEYWORD_AS;
        //new String[] {"TEST", "PUBLIC", "POP", "JAZZ", "CODE", 
        // "HELLOINSTAGRAM;)", "YES", "YAZDIR"};
	     	
        //Yazdir("as:"+Target_Hedef[0]);
        //Yazdir("\nTARGETE?>:"+Target_Hedef[0]);
        //Yazdir("\nTPP?>: "+TPP_MELUMAT);
        //Yazdir("\nAC_DEF?>: "+AC_Def_Setir);
        int i, s;
        if(Alinan_Deger == true){
            String[] Target_Hedef = AC_Def_Setir.split(":");
                    //for(String x : Target_Hedef){ System.out.println("T>>"+x); }
                    
                    for(i = 0; i < Target_Hedef.length; i++){
                        for(s = 0; s < KEYWORD_AS.length; s++){            
                            if(Target_Hedef[i].equals(KEYWORD_AS[s])){
                                switch(Target_Hedef[i]) {
                                    case "DIF":
                                        //AcarSozler.AS_reqem(AC_Def_Setir.substring(4));
                                        //Ayrici.Ozel_Durum = false;
                                        return AcarSozler.AS_DIF(AC_Def_Setir, Mod, Alinan_Deger, fonksiyon);
                                    default:
                                        return true;
                                }
                            }
                        }
                    }
        }else{
            return AcarSozler.AS_DIF(AC_Def_Setir, Mod, Alinan_Deger, fonksiyon);
        }
        return true;
    }
    
    //BU IKI FONKSIYON ORTAK CALISIR VE AYRICI CLASINA ULASILIR
    public static boolean ACYazimTehliledici(String AC_Def_Setir, String TPP_MELUMAT, boolean Alinan_Deger, String Mod, Fonksiyon fonksiyon) {
		
        boolean Gonderilen_Deger = true;
         
        String[] KEYWORD_AS = AcarSozler.KEYWORD_AS;
        //new String[] {"TEST", "PUBLIC", "POP", "JAZZ", "CODE", 
        // "HELLOINSTAGRAM;)", "YES", "YAZDIR"};
	     	
        //Yazdir("as:"+Target_Hedef[0]);
        //Yazdir("\nTARGETE?>:"+Target_Hedef[0]);
        //Yazdir("\nTPP?>: "+TPP_MELUMAT);
        //Yazdir("\nAC_DEF?>: "+AC_Def_Setir);
        int i, s;
 
            if(Alinan_Deger == true){
                String[] Target_Hedef = AC_Def_Setir.split(":");
                //System.out.println(">>>>"+AC_Def_Setir);
                for(i = 0; i < Target_Hedef.length; i++){
                    for(s = 0; s < KEYWORD_AS.length; s++){            
                        if(Target_Hedef[i].equals(KEYWORD_AS[s])){
                            switch(Target_Hedef[i]) {
                                case "YAZDIR":                    
                                    AcarSozler.AS_YAZDIR(AC_Def_Setir, Mod, fonksiyon);
                                    break;
                                case "PRINT":                    
                                    AcarSozler.AS_YAZDIR(AC_Def_Setir, Mod, fonksiyon);
                                    break;
                                case "DIF":
                                    //ayrici.Ozel_Durum = false;
                                    //AcarSozler.AS_reqem(AC_Def_Setir.substring(4));
                                    return AcarSozler.AS_DIF(AC_Def_Setir, Mod, Alinan_Deger, fonksiyon);
                                case "herif":
                                    AcarSozler.AS_herif(AC_Def_Setir);
                                default:
                                    return true;
                            }                 
                        } else{              
                            String GT = TestFUNC(Target_Hedef[i], KEYWORD_AS[s], 0);                 
                            if(GT.equals(KEYWORD_AS[s])){		                 	                    
                                //BURADA OZEL BIR CLASS VE YA BIR FONKSIYON CAGRILARAQ YOXLAMA ISLEMI EDILE BIULER 	                  
                                //MENCE BIR KLAS YARADILARAQ KEY WORD CLASSI OLUN                        
                                switch(GT) {			                       
                                    case "YAZDIR":				                          
                                        AcarSozler.AS_YAZDIR(AC_Def_Setir, Mod, fonksiyon);	
                                        break;
                                    case "PRINT":                    
                                        AcarSozler.AS_YAZDIR(AC_Def_Setir, Mod, fonksiyon);
                                        break;
                                    case "DIF":
                                        //ayrici.Ozel_Durum = false;
                                        return AcarSozler.AS_DIF(AC_Def_Setir, Mod, Alinan_Deger, fonksiyon);
                                    case "herif":
                                        AcarSozler.AS_herif(AC_Def_Setir);
                                    default:
                                        return true;
                                }			                          			                     
                            }			                    
                        }		                
                    }		           
                }
            }else {
                //ayrici.Ozel_Durum = false;
                return AcarSozler.AS_DIF(AC_Def_Setir, Mod, Alinan_Deger, fonksiyon);
            }
        
        return Gonderilen_Deger;
    }
    
    //Beginning == Baslqnic
    //TopGlobal == UstGlobal
    
    //Burasi AC Fonksiyon Cagiri tanima bolumudur ve bu bolum sayesinde cagiri yapilan fonksiyonlarin varligi kontrol edilerek
    // var olan fonksiyonlar cagiriliyor daha sonra diger islemler yapilmaya calisiliyor
    //bu fonksiyon sayesinde fonksiyon ismi fonksiyon degiskenleri ve fonksiyon bilgileri kolaylikla alinarak kontrol yapila biliniyor
    //
    public static Fonksiyon ACYazimTehliledici(String AC_Def_Setir, String Mod) {
        //METIN DUZENLEYICI 
        /*
        BU YAPI ICERSINE BIR FONKSION TANIMALYICI EKLMEK GEREKLI VE BAZI DEYISIKLERI FARKLI SEKILDE YAZMAK GEREKLI
        */
        String MI = AC_Def_Setir.replaceAll("\\s", "");
        //System.out.println("FONKSIYON SATRI>>"+AC_Def_Setir);
        int Fonksiyon_Deyisgen_Verici = MetinAxtarici(MI, '<');

        if(Fonksiyon_Deyisgen_Verici != -1){
            for(int i = 1; i < AcarSozler.FONKSIYONLAR.length; i++){
                if(AcarSozler.FONKSIYONLAR[i] == null){
                    break;
                }
                if(MI.substring(0, Fonksiyon_Deyisgen_Verici).equals(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ISMI())){
                    String[] Verilen_Deyisgenler = MI.substring(1+Fonksiyon_Deyisgen_Verici).split(",",AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI());   //"," 
                    for(String x1 : Verilen_Deyisgenler){
                        Elaveler.YazdirSpesial(x1);
                    }
                    if(Verilen_Deyisgenler.length > AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI()){
                        //System.out.println("XETA FONKSIYON DEYISGENLERI");
                    }else if(Verilen_Deyisgenler.length == AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI()){
                        for(int x = 0; x < AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIG_DEYISGENLERININ_SAYI(); x++){
                            boolean fonksiyonvarligyoxlayicidurumu = false;
                            boolean fonksiyondondurucuyoxlayicidurumu = false;
                            String verilenfonksiyongeridondurlendegeri = "null";
                            
                            for(int fi = 1; fi < AcarSozler.FONKSIYONLAR.length; fi++){
                                //fonksiyonvarligyoxlayicidurumu = false;
                                //fonksiyondondurucuyoxlayicidurumu = false;
                                //verilenfonksiyongeridondurlendegeri = "null";
                                if(AcarSozler.FONKSIYONLAR[fi] == null || Verilen_Deyisgenler[x] == null){ break; }
                               // System.out.print("\nISDENILEN FONKSIYON >>>"+Verilen_Deyisgenler[x]);//
                                //System.out.print("\nTAPILAN FONKSIYON >>>"+AcarSozler.FONKSIYONLAR[fi].getFONKSIYON_ISMI()+"<<");//
                                int Fonksiyon_Deyisgen_Verici_Ic = MetinAxtarici(Verilen_Deyisgenler[x], '<');
//                                System.out.print("\nISDENILEN FONKSIYON >>>"+Verilen_Deyisgenler[x].substring(0, Fonksiyon_Deyisgen_Verici_Ic));//
  //                              System.out.print("\nTAPILAN FONKSIYON >>>"+AcarSozler.FONKSIYONLAR[fi].getFONKSIYON_ISMI()+"<<");//
                              
                                if(Fonksiyon_Deyisgen_Verici_Ic != -1){
                                    if(Verilen_Deyisgenler[x].substring(0, Fonksiyon_Deyisgen_Verici_Ic).equals(AcarSozler.FONKSIYONLAR[fi].getFONKSIYON_ISMI())){//substring(0, MetinAxtarici(Verilen_Deyisgenler[x], '<')).
                                        Fonksiyon donenfonksiyon = ACYazimTehliledici(Verilen_Deyisgenler[x], "Fonksiyon");
                                        if(donenfonksiyon != null){
                                            fonksiyonvarligyoxlayicidurumu = true;
                                            if(AcarSozler.FONKSIYONLAR[fi].getGERI_DONDURUCU_DURUMU()){
                                                int dondurulenfonksiyongerimelumatyoxlayici = ACTehliledici.MetinAxtarici(donenfonksiyon.getFONKISYON_GERI_DONDURULEN(), '\"');
                                               // System.out.println(">>D"+Verilen_Deyisgenler[x]);
                                                if(dondurulenfonksiyongerimelumatyoxlayici == -1){
                                                    //verilenfonksiyongeridondurlendegeri = donenfonksiyon.getFONKISYON_GERI_DONDURULEN();
    //                                              Verilen_Deyisgenler[x] = donenfonksiyon.getFONKISYON_GERI_DONDURULEN();
                                                    Verilen_Deyisgenler[x] = Deyisgen.ACDeyisgenDondurucu(donenfonksiyon.getFONKSIYON_UID()+donenfonksiyon.getFONKISYON_GERI_DONDURULEN());

                                                    //System.out.println(">"+Deyisgen.ACDeyisgenDondurucu(donenfonksiyon.getFONKSIYON_UID()+donenfonksiyon.getFONKISYON_GERI_DONDURULEN()));   
                                                    //System.out.println(">>"+donenfonksiyon.getFONKSIYON_UID());
                                                    //System.out.println(">>"+donenfonksiyon.getFONKISYON_GERI_DONDURULEN());
                                                }else{
                                                    Verilen_Deyisgenler[x] = donenfonksiyon.getFONKISYON_GERI_DONDURULEN();
                                                }
                                            //fonksiyondondurucuyoxlayicidurumu = AcarSozler.FONKSIYONLAR[fi].getGERI_DONDURUCU_DURUMU();
                                              

                                            }
                                        }
                                    }

                                }else{
                                    if(Verilen_Deyisgenler[x].equals(AcarSozler.FONKSIYONLAR[fi].getFONKSIYON_ISMI())){//substring(0, MetinAxtarici(Verilen_Deyisgenler[x], '<')).
                                        Fonksiyon donenfonksiyon = ACYazimTehliledici(Verilen_Deyisgenler[x], "Fonksiyon");
                                        if(donenfonksiyon != null){
                                            fonksiyonvarligyoxlayicidurumu = true;
                                            if(AcarSozler.FONKSIYONLAR[fi].getGERI_DONDURUCU_DURUMU()){
                                                //fonksiyondondurucuyoxlayicidurumu = AcarSozler.FONKSIYONLAR[fi].getGERI_DONDURUCU_DURUMU();
                                                //verilenfonksiyongeridondurlendegeri = donenfonksiyon.getFONKISYON_GERI_DONDURULEN();
                                                Verilen_Deyisgenler[x] = donenfonksiyon.getFONKISYON_GERI_DONDURULEN();
                                                //System.out.println(">>"+Deyisgen.ACDeyisgenDondurucu(donenfonksiyon.getFONKSIYON_UID()+donenfonksiyon.getFONKISYON_GERI_DONDURULEN()));
                                               //System.out.println(">>"+donenfonksiyon.getFONKSIYON_UID());
                                            }
                                        }
                                    }
                                }
                            }
                            if(fonksiyonvarligyoxlayicidurumu){
                                //if(fonksiyondondurucuyoxlayicidurumu){
                         
                                AcarSozler.FONKSIYONLAR[i].getFONKSIYON_DEYISGENLERI().get(x).DeyisgenTanimi(Verilen_Deyisgenler[x], AcarSozler.FONKSIYONLAR[i]);
                                //System.out.println("AcarSozler.FONKSIYONLAR[i].getFONKSIYON_DEYISGENLERI().get(x)>>"+AcarSozler.FONKSIYONLAR[i].getFONKSIYON_DEYISGENLERI().get(x).getDEYISGENICERIGI());

                               // }  System.out.println("verilenfonksiyongeridondurlendegeri>>"+verilenfonksiyongeridondurlendegeri);
                                  
                            }else{
   //                             Fonksiyon.getFonksiyonStatus();
 //                               Deyisgen.ACDeyisgenlerStatus();
                                //System.out.println(">>D"+Verilen_Deyisgenler[x]);
                                //System.out.println(">>FD"+AcarSozler.FONKSIYONLAR[i].getFONKSIYON_DEYISGENLERI().get(x).getDEYISGENISMI());
                                AcarSozler.FONKSIYONLAR[i].getFONKSIYON_DEYISGENLERI().get(x).DeyisgenTanimi(Verilen_Deyisgenler[x], AcarSozler.FONKSIYONLAR[i]);
                                   
                            }
                            //FonksiyonDeyisgenleri fonksiyondeyisgenleri = new FonksiyonDeyisgenleri();
                            //AcarSozler.FONKSIYONLAR[i]
                        }
                    }
                    //for(String x:AC_Def_Setir.substring(1+Fonksiyon_Deyisgen_verici).split(",")){
                      //  System.out.println(x);
                    //}

                    try{
                        String Fonksiyon_ICERIGI = "";
                        if(Mod.equals("Fonksiyon")){
                           
                            int Fonksiyon_Geri_Dondurucu_Baslanqic = Fonksiyon.FonksiyonGeriDondurucuBulucu(i); //MetinAxtarici(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI(), '<');
                            if(Fonksiyon_Geri_Dondurucu_Baslanqic != -1){
                                int Fonksiyon_Geri_Dondurucu_Bitis = MetinAxtarici(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(Fonksiyon_Geri_Dondurucu_Baslanqic, AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().length()), ';');
                                if(Fonksiyon_Geri_Dondurucu_Bitis != -1){

                                    Fonksiyon_ICERIGI = AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(0, Fonksiyon_Geri_Dondurucu_Baslanqic);
                                    AcarSozler.FONKSIYONLAR[i].setGERI_DONDURUCU_DURUMU(true);
                                    AcarSozler.FONKSIYONLAR[i].setFONKISYON_GERI_DONDURULEN(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(Fonksiyon_Geri_Dondurucu_Baslanqic, Fonksiyon_Geri_Dondurucu_Baslanqic+Fonksiyon_Geri_Dondurucu_Bitis));
                                }else{
                                    Fonksiyon_ICERIGI = AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(0, Fonksiyon_Geri_Dondurucu_Baslanqic);
                                    AcarSozler.FONKSIYONLAR[i].setGERI_DONDURUCU_DURUMU(true);
                                }
                            }else{
                                Fonksiyon_ICERIGI = AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI();
                            }
                        }
                        ayrici.MelumatAlici(Fonksiyon_ICERIGI, Mod, AcarSozler.FONKSIYONLAR[i]);
                        return AcarSozler.FONKSIYONLAR[i];
                    }catch(Exception e){
                        e.printStackTrace();
                        Elaveler.YazdirSpesial("SONSUZ DONGU<11"+e);
                    }
                }
            }
        }else{       
            for(int i = 1; i < AcarSozler.FONKSIYON_SAYAC; i++){
                //System.out.println(MI+"<VERILEN : VAR OLAN:>"+AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ISMI());
                if(MI.equals(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ISMI())){
                    //System.out.println("Tekli");
                    try{
                        String Fonksiyon_ICERIGI = "";
                        if(Mod.equals("Fonksiyon")){
                            //int Fonksiyon_Geri_Dondurucuv_Baslanqic = MetinAxtarici(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI(), '<');

                            int Fonksiyon_Geri_Dondurucu_Baslanqic = Fonksiyon.FonksiyonGeriDondurucuBulucu(i); //MetinAxtarici(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI(), '<');
                            //System.out.println("FONKSIYON BILGISI>>"+AcarSozler.FONKSIYONLAR[i].getFONKISYON_GERI_DONDURULEN());
                            if(Fonksiyon_Geri_Dondurucu_Baslanqic != -1){
                                
                                int Fonksiyon_Geri_Dondurucu_Bitis = MetinAxtarici(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(Fonksiyon_Geri_Dondurucu_Baslanqic, AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().length()), ';');
                                
                                if(Fonksiyon_Geri_Dondurucu_Bitis != -1){
                                    Fonksiyon_ICERIGI = AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(0, Fonksiyon_Geri_Dondurucu_Baslanqic-1);
                                    //System.out.println(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(++Fonksiyon_Geri_Dondurucu_Baslanqic, Fonksiyon_Geri_Dondurucu_Baslanqic+(1+Fonksiyon_Geri_Dondurucu_Bitis)));
                                    AcarSozler.FONKSIYONLAR[i].setGERI_DONDURUCU_DURUMU(true);
                                    AcarSozler.FONKSIYONLAR[i].setFONKISYON_GERI_DONDURULEN(AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(Fonksiyon_Geri_Dondurucu_Baslanqic, Fonksiyon_Geri_Dondurucu_Baslanqic+Fonksiyon_Geri_Dondurucu_Bitis));
                                }else{
                                    Fonksiyon_ICERIGI = AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI().substring(0, Fonksiyon_Geri_Dondurucu_Baslanqic);
                                    AcarSozler.FONKSIYONLAR[i].setGERI_DONDURUCU_DURUMU(true);
                                }
                      
                            }else{
                                Fonksiyon_ICERIGI = AcarSozler.FONKSIYONLAR[i].getFONKSIYON_ICERIGI();
                            }
                        }
                        ayrici.MelumatAlici(Fonksiyon_ICERIGI, Mod, AcarSozler.FONKSIYONLAR[i]);
                        return AcarSozler.FONKSIYONLAR[i];
                    }catch(Exception e){
                        e.printStackTrace();
                        Elaveler.YazdirSpesial("SONSUZ DONGU<12"+e);
                    }
                }
            }
        }
        return null;
    }
    
    public static String TestFUNC(String a, String b, int n){	   
        for(n = 0; n <= a.length(); n++){	
            String ED = a.substring(n, a.length());		          
            if(n != a.length()){		          
                if(ED.equals(b)){		             
                    return ED;			                 
                } else{             
                }		             
            } else {         
                //return "ERR";
            }
        }
        return "";
    }

    ///
    
    /*
     * 
     */

    //BURASI ACTEHLILEDICI JAVA FAYILININ YANLIZ private YAZILAN FONKSIYONLARI VE YA DA METHODLARININ BASLANQICIDIR
    
    //BURDA ACTEHLILEDICI JAVA FAYILININ YANLIZ private YAZILAN FONKSIYONLARININ VE YA DA METHODLARININ SONUDUR


}

